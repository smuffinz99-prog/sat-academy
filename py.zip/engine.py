"""Learning engine: storage, mastery, scheduling, spaced repetition.

Everything that decides *what to study* lives here. The HTTP layer in
server.py only translates requests into calls on Engine.
"""
import datetime as dt
import json
import os
import sqlite3
import threading

from content import CONTENT
from content.curriculum import (MASTERY_REVIEW_DAYS, MISTAKE_INTERVALS,
                                MISTAKE_CATEGORIES, SEQUENCE)
from content.short import SHORT

Q = CONTENT["questions"]
LESSONS = CONTENT["lessons"]
BY_UNIT = CONTENT["by_unit"]
WORKED = CONTENT["worked"]

LEVELS = ["beginner", "developing", "proficient", "mastered"]
LEVEL_LABEL = {"beginner": "Beginner", "developing": "Developing",
               "proficient": "Proficient", "mastered": "Mastered"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question_id TEXT NOT NULL, unit TEXT NOT NULL, difficulty INTEGER,
    selected TEXT, correct INTEGER, assisted INTEGER DEFAULT 0,
    context TEXT, session_id INTEGER, day TEXT, answered_at TEXT);
CREATE INDEX IF NOT EXISTS idx_attempts_unit ON attempts(unit);
CREATE INDEX IF NOT EXISTS idx_attempts_q ON attempts(question_id);
CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    day TEXT, focus_unit TEXT, kind TEXT, reason TEXT,
    plan TEXT, state TEXT, status TEXT, completed_day TEXT, summary TEXT);
CREATE TABLE IF NOT EXISTS mistakes (
    question_id TEXT PRIMARY KEY, unit TEXT, selected TEXT, category TEXT,
    unsure INTEGER DEFAULT 0, times_wrong INTEGER DEFAULT 0,
    times_reviewed INTEGER DEFAULT 0, stage INTEGER DEFAULT 0,
    due_day TEXT, first_day TEXT, last_day TEXT);
CREATE TABLE IF NOT EXISTS unit_progress (
    unit TEXT PRIMARY KEY, introduced_day TEXT, sections TEXT DEFAULT '[]',
    lesson_done INTEGER DEFAULT 0, mastered_day TEXT,
    review_stage INTEGER DEFAULT 0, last_practiced_day TEXT);
CREATE TABLE IF NOT EXISTS tutor_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT, thread_id TEXT, role TEXT,
    content TEXT, created_at TEXT);
"""

USER_TABLES = ["meta", "attempts", "sessions", "mistakes", "unit_progress", "tutor_messages"]
MASTERCLASS_SECTIONS = ["video", "attack", "rules", "examples", "traps",
                        "guided", "independent", "mastery", "cheatsheet"]
CORE_SECTIONS = set(MASTERCLASS_SECTIONS) - {"mastery"}
# Section names used by the first version of the app.
OLD_SECTIONS = {"what": "video", "testing": "video", "recognise": "video", "method": "attack", "revision": "cheatsheet"}


def norm_sections(raw):
    out = []
    for s in json.loads(raw or "[]"):
        s = OLD_SECTIONS.get(s, s)
        if s in MASTERCLASS_SECTIONS and s not in out:
            out.append(s)
    return out


def parse_day(s):
    return dt.date.fromisoformat(s)


def add_days(day, n):
    return (parse_day(day) + dt.timedelta(days=n)).isoformat()


def days_between(a, b):
    return (parse_day(b) - parse_day(a)).days


def now_iso():
    return dt.datetime.now().isoformat(timespec="seconds")


def public_question(qid):
    """Question without answer or explanations (shown before submitting)."""
    q = Q[qid]
    les = LESSONS[q["unit"]]
    return {"id": qid, "unit": q["unit"], "unitTitle": les["title"],
            "moduleTitle": les["moduleTitle"], "skill": q["skill"],
            "difficulty": q["difficulty"], "passage": q["passage"],
            "question": q["question"], "choices": q["choices"], "data": q["data"],
            "hint": q["hint"] or _default_hint(q["unit"])}


def _default_hint(unit):
    m = LESSONS[unit]["method"]
    return "Method: " + " → ".join(_strip_md(s).split(".")[0] for s in m[:3])


def _strip_md(s):
    return s.replace("**", "").replace("*", "")


def full_question(qid):
    q = Q[qid]
    d = public_question(qid)
    d.update({"answer": q["answer"], "explanation": q["explanation"], "why": q["why"],
              "tip": q["tip"] or LESSONS[q["unit"]]["short"],
              "concept": LESSONS[q["unit"]]["concept"], "vocab": q["vocab"]})
    return d


def default_category(unit):
    if unit == "WIC":
        return "vocabulary"
    if unit[0] in "BF" and unit[1:].isdigit():
        return "knowledge"
    return "reasoning"


class Engine:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        self.db_path = os.path.join(data_dir, "study.db")
        self.lock = threading.RLock()
        self.db = sqlite3.connect(self.db_path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        # In the browser version (Pyodide) the database is one file that gets saved to the
        # browser after each change, so it must not leave changes in a separate WAL file.
        self.db.execute("PRAGMA journal_mode=%s" % ("DELETE" if os.environ.get("SAT_WEB") else "WAL"))
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript(SCHEMA)
        self.db.commit()

    # ------------------------------------------------------------ helpers
    def q(self, sql, args=()):
        return self.db.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        return self.db.execute(sql, args).fetchone()

    def meta_get(self, key, default=None):
        r = self.one("SELECT value FROM meta WHERE key=?", (key,))
        return json.loads(r["value"]) if r else default

    def meta_set(self, key, value):
        self.db.execute("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                        (key, json.dumps(value)))

    def progress(self, unit):
        r = self.one("SELECT * FROM unit_progress WHERE unit=?", (unit,))
        if not r:
            self.db.execute("INSERT INTO unit_progress(unit) VALUES(?)", (unit,))
            r = self.one("SELECT * FROM unit_progress WHERE unit=?", (unit,))
        return r

    def daily_backup(self, today):
        """Keep a rolling copy of the database, once per calendar day."""
        bdir = os.path.join(self.data_dir, "backups")
        os.makedirs(bdir, exist_ok=True)
        target = os.path.join(bdir, "study-%s.db" % today)
        if os.path.exists(target):
            return
        with self.lock:
            self.db.commit()
            dst = sqlite3.connect(target)
            self.db.backup(dst)
            dst.close()
        files = sorted(f for f in os.listdir(bdir) if f.startswith("study-") and f.endswith(".db"))
        for f in files[:-14]:
            os.remove(os.path.join(bdir, f))

    # ------------------------------------------------------------ mastery
    def unit_stats(self, unit, today):
        rows = self.q("SELECT question_id, difficulty, correct, assisted, day FROM attempts "
                      "WHERE unit=? ORDER BY id", (unit,))
        unassisted = [r for r in rows if not r["assisted"]]
        recent = unassisted[-10:]
        medhard = [r for r in unassisted if r["difficulty"] >= 2][-8:]
        # Qualifying hard sample: first attempt at a hard question, or a repeat
        # at least 7 days after the previous attempt (a genuine retention test).
        last_seen, hard_sample = {}, []
        for r in rows:
            prev = last_seen.get(r["question_id"])
            if r["difficulty"] == 3 and not r["assisted"]:
                if prev is None or days_between(prev, r["day"]) >= 7:
                    hard_sample.append(r)
            last_seen[r["question_id"]] = r["day"]
        hard_sample = hard_sample[-10:]

        def acc(rs):
            return sum(r["correct"] for r in rs) / len(rs) if rs else 0.0

        if len(hard_sample) >= 8 and acc(hard_sample) >= 0.9:
            level = "mastered"
        elif len(medhard) >= 6 and acc(medhard) >= 0.8:
            level = "proficient"
        elif len(unassisted) >= 4 and acc(recent) >= 0.5:
            level = "developing"
        else:
            level = "beginner"
        return {"unit": unit, "level": level, "levelLabel": LEVEL_LABEL[level],
                "attempts": len(rows), "recentAccuracy": round(acc(recent), 2),
                "hardSample": len(hard_sample), "hardAccuracy": round(acc(hard_sample), 2),
                "mediumHardAccuracy": round(acc(medhard), 2),
                "lastDay": rows[-1]["day"] if rows else None}

    def all_stats(self, today):
        return {u: self.unit_stats(u, today) for u in SEQUENCE}

    def mastery_explainer(self, st):
        """Plain-language note on what is needed for the next level."""
        lvl = st["level"]
        if lvl == "beginner":
            return "Answer a few questions unassisted with at least 50% accuracy to reach Developing."
        if lvl == "developing":
            return "Get 80% of your recent medium and hard questions right to reach Proficient."
        if lvl == "proficient":
            return ("Mastery needs 90%% accuracy on a sample of at least 8 hard questions, answered "
                    "without hints (%d so far, %d%% correct). Repeats count only after a week." %
                    (st["hardSample"], round(st["hardAccuracy"] * 100)))
        return "Mastered. You'll get spaced revision so it stays that way."

    def _sync_mastery(self, unit, today):
        st = self.unit_stats(unit, today)
        p = self.progress(unit)
        if st["level"] == "mastered" and not p["mastered_day"]:
            self.db.execute("UPDATE unit_progress SET mastered_day=?, review_stage=0 WHERE unit=?", (today, unit))
        elif st["level"] != "mastered" and p["mastered_day"]:
            self.db.execute("UPDATE unit_progress SET mastered_day=NULL, review_stage=0 WHERE unit=?", (unit,))
        return st

    # ------------------------------------------------------------ question picking
    def _question_history(self):
        hist = {}
        for r in self.q("SELECT question_id, correct, day, id FROM attempts ORDER BY id"):
            hist[r["question_id"]] = (r["correct"], r["day"], r["id"])
        return hist

    def pick_questions(self, unit, plan, exclude=(), hist=None):
        """plan: list of (difficulty, count). Prefers unseen, then previously
        wrong, then least recently seen. Falls back to nearby difficulties."""
        hist = hist if hist is not None else self._question_history()
        pool = [i for i in BY_UNIT.get(unit, []) if i not in exclude]

        def rank(i):
            h = hist.get(i)
            if h is None:
                return (0, 0, i)
            return (1 if not h[0] else 2, h[2], i)

        chosen = []
        for diff, count in plan:
            for d in [diff] + [x for x in (2, 3, 1) if x != diff]:
                if count <= 0:
                    break
                cands = sorted((i for i in pool if Q[i]["difficulty"] == d and i not in chosen), key=rank)
                take = cands[:count]
                chosen += take
                count -= len(take)
        chosen.sort(key=lambda i: Q[i]["difficulty"])
        return chosen

    # How much each session length holds. Rough timing: lesson ~6 min,
    # worked example ~2.5 min, question ~1.5 min. 60 minutes = two topics.
    LENGTHS = {
        30: {"review": 4, "mixed": 4, "topics": [{"examples": 1, "practice": 8}]},
        60: {"review": 8, "mixed": 6, "topics": [{"examples": 2, "practice": 10}, {"examples": 1, "practice": 8}]},
    }

    # Target days between mixed-review appearances, by level.
    MIXED_GAP = {"beginner": 2, "developing": 3, "proficient": 5, "mastered": 9}

    @staticmethod
    def scale_plan(plan, total):
        """Scale a [(difficulty, count)] plan to `total` questions, keeping its shape."""
        base = sum(c for _, c in plan)
        out = [(d, int(c * total / base)) for d, c in plan]
        rem = total - sum(c for _, c in out)
        # Give leftovers to the hardest bands first.
        for i in sorted(range(len(out)), key=lambda i: -out[i][0]):
            if rem <= 0:
                break
            out[i] = (out[i][0], out[i][1] + 1)
            rem -= 1
        return out

    def practice_plan_for(self, level, kind):
        if kind == "review":
            return [(2, 3), (3, 7)]
        return {
            "beginner": [(1, 4), (2, 5), (3, 3)],
            "developing": [(1, 2), (2, 5), (3, 5)],
            "proficient": [(2, 4), (3, 8)],
            "mastered": [(2, 3), (3, 7)],
        }[level]

    # ------------------------------------------------------------ scheduling
    def introduced_units(self):
        return [r["unit"] for r in self.q("SELECT unit FROM unit_progress WHERE introduced_day IS NOT NULL")]

    def decide_focus(self, today, exclude=()):
        """Choose a focus unit (skipping `exclude`). Deterministic given history."""
        exclude = set(exclude)
        stats = self.all_stats(today)
        introduced = set(self.introduced_units())
        done = self.q("SELECT * FROM sessions WHERE status='complete' ORDER BY id")
        last = done[-1] if done else None

        if last:
            summ = json.loads(last["summary"] or "{}")
            topics = summ.get("topics") or [{"unit": last["focus_unit"], "kind": last["kind"],
                                             "accuracy": summ.get("practiceAccuracy")}]
            struggled = sorted((t for t in topics if t.get("accuracy") is not None and t["accuracy"] < 0.6
                                and t.get("kind") != "reinforce" and t["unit"] not in exclude),
                               key=lambda t: t["accuracy"])
            if struggled:
                t = struggled[0]
                return {"unit": t["unit"], "kind": "reinforce",
                        "reason": "Second look: you scored %d%% last time." % round(t["accuracy"] * 100)}

        recent_units = set()
        for r in done[-2:]:
            summ = json.loads(r["summary"] or "{}")
            recent_units |= {t["unit"] for t in summ.get("topics", [])} | {r["focus_unit"]}
        weak = sorted((u for u in introduced if LEVELS.index(stats[u]["level"]) < 2
                       and u not in recent_units and u not in exclude),
                      key=lambda u: (LEVELS.index(stats[u]["level"]), stats[u]["recentAccuracy"],
                                     self.progress(u)["last_practiced_day"] or "", stats[u]["lastDay"] or ""))
        if done and len(done) % 4 == 3 and weak:
            return {"unit": weak[0], "kind": "reinforce", "reason": "Weak-spot day: your least secure topic."}

        for u in SEQUENCE:
            if u not in introduced and u not in exclude:
                return {"unit": u, "kind": "new", "reason": "Next topic in your course."}

        # Whole course introduced: rotate by need, with spaced revision for mastered units.
        cands = []
        for u in SEQUENCE:
            if u in exclude:
                continue
            st = stats[u]
            p = self.progress(u)
            last_day = p["last_practiced_day"] or st["lastDay"] or today
            gap = days_between(last_day, today)
            if st["level"] == "mastered":
                interval = MASTERY_REVIEW_DAYS[min(p["review_stage"], len(MASTERY_REVIEW_DAYS) - 1)]
                if gap < interval:
                    continue
                score = gap - interval
                kind, why = "review", "Mastered. Keeping it fresh."
            else:
                score = (3 - LEVELS.index(st["level"])) * 10 + gap
                kind, why = "reinforce", "Building it toward mastery."
            cands.append((score, u, kind, why))
        cands.sort(key=lambda c: (-c[0], SEQUENCE.index(c[1])))
        if len(cands) > 1 and cands[0][1] in recent_units:
            cands = cands[1:] + cands[:1]
        if not cands:
            pool = [x for x in SEQUENCE if x not in exclude] or SEQUENCE
            u = min(pool, key=lambda x: self.progress(x)["last_practiced_day"] or "")
            return {"unit": u, "kind": "review", "reason": "Mastered. Keeping it fresh."}
        _, u, kind, why = cands[0]
        return {"unit": u, "kind": kind, "reason": why}

    def default_minutes(self):
        return 60 if self.meta_get("minutes", 30) == 60 else 30

    def set_default_minutes(self, minutes):
        self.meta_set("minutes", 60 if int(minutes) >= 60 else 30)
        self.db.commit()

    def planned_focus(self, today):
        plan = self.meta_get("next_plan")
        return plan or self.decide_focus(today)

    def due_mistakes(self, today, limit=None):
        rows = self.q("SELECT * FROM mistakes WHERE due_day<=? ORDER BY due_day, times_wrong DESC, question_id", (today,))
        rows = [r for r in rows if r["question_id"] in Q]
        return rows[:limit] if limit else rows

    def build_session(self, today, minutes=30):
        minutes = 60 if int(minutes or 30) >= 60 else 30
        L = self.LENGTHS[minutes]
        hist = self._question_history()
        stats = self.all_stats(today)
        focuses = [self.planned_focus(today)]
        while len(focuses) < len(L["topics"]):
            focuses.append(self.decide_focus(today, exclude={f["unit"] for f in focuses}))

        stages = []
        review = [r["question_id"] for r in self.due_mistakes(today, L["review"])]
        if review:
            stages.append({"type": "review", "title": "Review due mistakes", "questions": review})
        used = set(review)
        topics = []
        for f, T in zip(focuses, L["topics"]):
            u = f["unit"]
            mode = {"new": "full", "reinforce": "reteach", "review": "revision"}[f["kind"]]
            stages.append({"type": "lesson", "title": LESSONS[u]["title"], "unit": u, "mode": mode})
            # The video solves one worked example, so a new topic starts with a different one.
            # A second look swaps the order, since the student saw that one last time.
            demo = SHORT[u]["demo"]["example"]
            ex_ids = sorted((e["id"] for e in WORKED.get(u, [])), key=lambda i: i == demo)
            if f["kind"] != "new":
                ex_ids.reverse()
            stages.append({"type": "examples", "title": "Worked examples", "unit": u,
                           "examples": ex_ids[:T["examples"]]})
            plan_q = self.scale_plan(self.practice_plan_for(stats[u]["level"], f["kind"]), T["practice"])
            practice = self.pick_questions(u, plan_q, exclude=used, hist=hist)
            used |= set(practice)
            stages.append({"type": "practice", "title": "Practice", "unit": u, "questions": practice})
            topics.append({"unit": u, "kind": f["kind"], "reason": f["reason"]})

        # Mixed review keeps every topic already taught in rotation (spaced retrieval).
        # Each topic has a target gap that grows with its level; the most overdue come
        # first, so nothing taught goes untouched for long, even on 30-minute days.
        today_units = {t["unit"] for t in topics}
        others = [u for u in self.introduced_units() if u not in today_units]

        def overdue(u):
            last = stats[u]["lastDay"] or self.progress(u)["introduced_day"] or today
            return days_between(last, today) / self.MIXED_GAP[stats[u]["level"]]
        others.sort(key=lambda u: (-overdue(u), LEVELS.index(stats[u]["level"]), SEQUENCE.index(u)))
        mixed = []
        i = 0
        while others and len(mixed) < L["mixed"] and i < 40:
            u = others[i % len(others)]
            diff = {"beginner": 1, "developing": 2}.get(stats[u]["level"], 3)
            pick = self.pick_questions(u, [(diff, 1)], exclude=used | set(mixed), hist=hist)
            if pick:
                mixed += pick
            i += 1
        if mixed:
            stages.append({"type": "mixed", "title": "Mixed review", "questions": mixed})
        stages.append({"type": "summary", "title": "Wrap-up"})

        first = focuses[0]
        plan = {"stages": stages, "minutes": minutes, "topics": topics}
        state = {"stage": 0, "index": 0, "max": 0, "answers": {}}
        cur = self.db.execute(
            "INSERT INTO sessions(day, focus_unit, kind, reason, plan, state, status) VALUES(?,?,?,?,?,?,?)",
            (today, first["unit"], first["kind"], first["reason"], json.dumps(plan), json.dumps(state), "active"))
        for t in topics:
            self.progress(t["unit"])
            self.db.execute("UPDATE unit_progress SET introduced_day=COALESCE(introduced_day, ?) WHERE unit=?", (today, t["unit"]))
        self.meta_set("next_plan", None)
        self.db.commit()
        return cur.lastrowid

    # ------------------------------------------------------------ daily status
    def today_status(self, today):
        # A session belongs to the day it was planned for. Sessions for later
        # days exist only when the student works ahead.
        active = self.one("SELECT * FROM sessions WHERE status='active' AND day<=? ORDER BY id DESC LIMIT 1", (today,))
        if active:
            status = "in_progress" if active["day"] == today else "carried_over"
            return {"status": status, "session": self.session_view(active["id"])}
        done_today = self.one("SELECT * FROM sessions WHERE status='complete' AND (day=? OR completed_day=?) "
                              "ORDER BY (day=?) DESC, id DESC LIMIT 1", (today, today, today))
        if done_today:
            nxt = self.planned_focus(today)
            return {"status": "complete", "session": self.session_view(done_today["id"]),
                    "next": self._focus_view(nxt), "ahead": self.ahead_status(today)}
        return {"status": "ready", "focus": self._focus_view(self.planned_focus(today)),
                "dueReviews": len(self.due_mistakes(today))}

    # ------------------------------------------------------------ working ahead
    AHEAD_DAYS = 6

    def next_open_day(self, today):
        """The first day after today that has no finished session (within the plan window)."""
        for i in range(1, self.AHEAD_DAYS + 1):
            d = add_days(today, i)
            if not self.one("SELECT 1 FROM sessions WHERE day=? AND status='complete'", (d,)):
                return d
        return None

    def ahead_status(self, today):
        active = self.one("SELECT * FROM sessions WHERE status='active' AND day>? ORDER BY day LIMIT 1", (today,))
        if active:
            return {"status": "in_progress", "day": active["day"], "sessionId": active["id"]}
        d = self.next_open_day(today)
        return {"status": "ready" if d else "none", "day": d}

    def start_ahead(self, today, minutes=30):
        """Start the next day's session early. Only once today's is finished."""
        with self.lock:
            st = self.today_status(today)
            if st["status"] != "complete":       # today first, always
                return self.start_today(today, minutes)
            ah = st["ahead"]
            if ah["status"] == "in_progress":
                return ah["sessionId"]
            if ah["status"] == "ready":
                return self.build_session(ah["day"], minutes)
            return None

    def _focus_view(self, f):
        les = LESSONS[f["unit"]]
        return {"unit": f["unit"], "title": les["title"], "moduleTitle": les["moduleTitle"],
                "domainTitle": les["domainTitle"], "kind": f["kind"], "reason": f["reason"], "short": les["short"]}

    def start_today(self, today, minutes=30):
        with self.lock:
            st = self.today_status(today)
            if st["status"] in ("in_progress", "carried_over"):
                return st["session"]["id"]
            if st["status"] == "complete":
                return st["session"]["id"]
            return self.build_session(today, minutes)

    def session_view(self, sid):
        s = self.one("SELECT * FROM sessions WHERE id=?", (sid,))
        if not s:
            return None
        plan, state = json.loads(s["plan"]), json.loads(s["state"])
        summary = json.loads(s["summary"]) if s["summary"] else None
        if summary is not None:
            saved = {r["question_id"] for r in self.q("SELECT question_id FROM mistakes")}
            summary["unsaved"] = [{"id": q, "selected": a["selected"], "unitTitle": LESSONS[Q[q]["unit"]]["title"],
                                   "skill": Q[q]["skill"]}
                                  for q, a in state.get("answers", {}).items()
                                  if not a["correct"] and q in Q and q not in saved]
        return {"id": s["id"], "day": s["day"], "unit": s["focus_unit"], "kind": s["kind"],
                "reason": s["reason"], "status": s["status"], "plan": plan, "state": state,
                "completedDay": s["completed_day"],
                "summary": summary,
                "focus": self._focus_view({"unit": s["focus_unit"], "kind": s["kind"], "reason": s["reason"]})}

    def advance(self, sid, stage, index):
        with self.lock:
            s = self.one("SELECT * FROM sessions WHERE id=?", (sid,))
            if not s or s["status"] != "active":
                return self.session_view(sid)
            state = json.loads(s["state"])
            n = len(json.loads(s["plan"])["stages"])
            state["stage"], state["index"] = max(0, min(int(stage), n - 1)), int(index)
            state["max"] = max(state.get("max", 0), state["stage"])
            self.db.execute("UPDATE sessions SET state=? WHERE id=?", (json.dumps(state), sid))
            self.db.commit()
            return self.session_view(sid)

    def complete_session(self, sid, today):
        with self.lock:
            s = self.one("SELECT * FROM sessions WHERE id=?", (sid,))
            if not s:
                return None
            if s["status"] == "complete":
                return self.session_view(sid)
            plan, state = json.loads(s["plan"]), json.loads(s["state"])
            answers = state.get("answers", {})

            def stage_acc(t):
                qs = [q for st in plan["stages"] if st["type"] == t for q in st.get("questions", [])]
                done = [answers[q]["correct"] for q in qs if q in answers]
                return (sum(done) / len(done)) if done else None, len(done), len(qs)

            unit = s["focus_unit"]
            p_acc, p_n, p_total = stage_acc("practice")
            r_acc, r_n, _ = stage_acc("review")
            m_acc, m_n, _ = stage_acc("mixed")
            wrong_today = [q for q, a in answers.items() if not a["correct"]]
            plan_topics = plan.get("topics") or [{"unit": unit, "kind": s["kind"]}]
            topics = []
            for t in plan_topics:
                u = t["unit"]
                qs = [q for stg in plan["stages"] if stg["type"] == "practice" and stg.get("unit", unit) == u
                      for q in stg.get("questions", [])]
                got = [answers[q]["correct"] for q in qs if q in answers]
                st = self._sync_mastery(u, today)
                if t["kind"] == "review" and st["level"] == "mastered":
                    self.db.execute("UPDATE unit_progress SET review_stage=review_stage+1 WHERE unit=?", (u,))
                self.db.execute("UPDATE unit_progress SET last_practiced_day=? WHERE unit=?", (today, u))
                topics.append({"unit": u, "unitTitle": LESSONS[u]["title"], "kind": t["kind"],
                               "accuracy": (sum(got) / len(got)) if got else None, "answered": len(got), "total": len(qs),
                               "level": st["levelLabel"], "mantra": SHORT[u]["mantra"]})
            summary = {
                "unit": unit, "unitTitle": " + ".join(t["unitTitle"] for t in topics), "kind": s["kind"],
                "minutes": plan.get("minutes", 30), "topics": topics,
                "practiceAccuracy": p_acc, "practiceAnswered": p_n, "practiceTotal": p_total,
                "reviewAccuracy": r_acc, "reviewAnswered": r_n,
                "mixedAccuracy": m_acc, "mixedAnswered": m_n,
                "remember": [a[0] for a in SHORT[unit]["attack"]], "mantra": SHORT[unit]["mantra"],
                "level": topics[0]["level"], "levelNote": "",
                "mistakesToday": [{"id": q, "unitTitle": LESSONS[Q[q]["unit"]]["title"], "skill": Q[q]["skill"]}
                                  for q in wrong_today if q in Q],
            }
            self.db.execute("UPDATE sessions SET status='complete', completed_day=?, summary=? WHERE id=?",
                            (today, json.dumps(summary), sid))
            # Decide and freeze the next session's plan now, so extra practice
            # later today cannot change it. A session done ahead plans the day after it.
            base = max(s["day"], today)
            nxt = self.decide_focus(add_days(base, 1))
            self.meta_set("next_plan", nxt)
            summary["next"] = self._focus_view(nxt)
            summary["ahead"] = s["day"] > today
            tomorrow = add_days(base, 1)
            summary["dueTomorrow"] = len(self.q("SELECT 1 FROM mistakes WHERE due_day<=?", (tomorrow,)))
            self.db.execute("UPDATE sessions SET summary=? WHERE id=?", (json.dumps(summary), sid))
            self.db.commit()
            return self.session_view(sid)

    # ------------------------------------------------------------ forecast
    def forecast(self, today, minutes, days=7):
        """Plan for the next `days` days if every day is a `minutes`-long session.
        Runs the real scheduler on an in-memory copy of the database, so it
        matches what will actually happen (assuming no struggles along the way)."""
        minutes = 60 if int(minutes) >= 60 else 30
        mem = sqlite3.connect(":memory:")
        with self.lock:
            self.db.commit()
            self.db.backup(mem)
        mem.row_factory = sqlite3.Row
        sim = Engine.__new__(Engine)
        sim.db, sim.lock, sim.data_dir = mem, threading.RLock(), None
        out = []
        for i in range(days):
            d = add_days(today, i)
            st = sim.today_status(d)
            entry = {"day": d, "minutes": minutes, "status": "planned"}
            if st["status"] in ("in_progress", "carried_over", "complete") and (i == 0 or st["session"]["day"] == d):
                sess = st["session"]
                entry["status"] = "done" if st["status"] == "complete" else "in_progress"
                entry["sessionId"] = sess["id"]
                entry["minutes"] = sess["plan"].get("minutes", 30)
                sid = sess["id"]
                plan = sess["plan"]
            else:
                sid = sim.build_session(d, minutes)
                plan = json.loads(sim.one("SELECT plan FROM sessions WHERE id=?", (sid,))["plan"])
            topics = plan.get("topics") or [{"unit": sess["unit"], "kind": sess["kind"], "reason": sess["reason"]}]
            entry["topics"] = [{"unit": t["unit"], "title": LESSONS[t["unit"]]["title"], "domain": LESSONS[t["unit"]]["domain"],
                                "kind": t["kind"], "reason": t.get("reason", "")} for t in topics]
            entry["reviews"] = sum(len(stg["questions"]) for stg in plan["stages"] if stg["type"] == "review")
            entry["questions"] = sum(len(stg.get("questions", [])) for stg in plan["stages"])
            sim.complete_session(sid, d)
            out.append(entry)
        mem.close()
        return out

    def course_outlook(self, today):
        """How far through the course you are, and when every question type
        will have been taught at 30 or 60 minutes a day."""
        taught = len(self.introduced_units())
        finish = {}
        for m in (30, 60):
            seen = set(self.introduced_units())
            day = today if len(seen) >= len(SEQUENCE) else None
            if day is None:
                for e in self.forecast(today, m, 45):
                    seen |= {t["unit"] for t in e["topics"]}
                    if len(seen) >= len(SEQUENCE):
                        day = e["day"]
                        break
            finish[str(m)] = day
        return {"taught": taught, "total": len(SEQUENCE), "finish": finish}

    def record_answer(self, qid, selected, context, today, session_id=None, assisted=False):
        if qid not in Q:
            raise KeyError(qid)
        q = Q[qid]
        correct = int(selected == q["answer"])
        with self.lock:
            self.db.execute(
                "INSERT INTO attempts(question_id, unit, difficulty, selected, correct, assisted, context, session_id, day, answered_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,?)",
                (qid, q["unit"], q["difficulty"], selected, correct, int(bool(assisted)), context, session_id, today, now_iso()))
            m = self.one("SELECT * FROM mistakes WHERE question_id=?", (qid,))
            journal = None
            if not correct:
                if m:
                    # Already in the journal: missed again, so it comes back tomorrow.
                    self.db.execute("UPDATE mistakes SET selected=?, times_wrong=times_wrong+1, stage=0, due_day=?, last_day=?, unsure=0 WHERE question_id=?",
                                    (selected, add_days(today, 1), today, qid))
                    journal = "missed_again"
                else:
                    journal = "not_saved"   # the student decides with "Add to Mistake Journal"
            elif m and m["due_day"] <= today:
                # A correct answer on a due mistake counts as a successful review.
                stage = min(m["stage"] + 1, len(MISTAKE_INTERVALS) - 1)
                bonus = 0 if m["times_wrong"] < 3 else -1     # stubborn mistakes come back a bit sooner
                interval = MISTAKE_INTERVALS[max(0, stage + bonus)]
                self.db.execute("UPDATE mistakes SET stage=?, due_day=?, times_reviewed=times_reviewed+1, last_day=? WHERE question_id=?",
                                (stage, add_days(today, interval), today, qid))
                journal = "rescheduled"
            if session_id:
                s = self.one("SELECT state, status FROM sessions WHERE id=?", (session_id,))
                if s and s["status"] == "active":
                    state = json.loads(s["state"])
                    state.setdefault("answers", {})
                    if qid not in state["answers"]:
                        state["answers"][qid] = {"selected": selected, "correct": bool(correct),
                                                 "tries": [] if correct else [selected], "solved": bool(correct)}
                    self.db.execute("UPDATE sessions SET state=? WHERE id=?", (json.dumps(state), session_id))
            self._sync_mastery(q["unit"], today)
            self.db.commit()
            m = self.one("SELECT * FROM mistakes WHERE question_id=?", (qid,))
        if not correct:
            # Wrong first pick: say so, but keep the answer and explanation back
            # until the student finds the right choice.
            return {"id": qid, "selected": selected, "correct": False, "solved": False, "tries": [selected],
                    "journal": journal, "inJournal": bool(m),
                    "mistake": {k: m[k] for k in ("due_day", "stage", "times_wrong")} and
                    {"dueDay": m["due_day"], "stage": m["stage"], "timesWrong": m["times_wrong"]} if m else None}
        res = full_question(qid)
        res.update({"selected": selected, "correct": True, "solved": True, "tries": [], "journal": journal,
                    "inJournal": bool(m), "mistake": self.mistake_view(m) if m else None})
        return res

    def record_retry(self, qid, selected, session_id=None, first=None, tries=None):
        """A second (or later) pick on a question already answered wrong. Not
        graded: it only reveals the explanation once the right choice is found."""
        if qid not in Q:
            raise KeyError(qid)
        q = Q[qid]
        right = selected == q["answer"]
        tries = [t for t in (tries or []) if t in "ABCD" and t != q["answer"]]
        with self.lock:
            if session_id:
                s = self.one("SELECT state, status FROM sessions WHERE id=?", (session_id,))
                if s:
                    state = json.loads(s["state"])
                    ans = state.setdefault("answers", {}).get(qid)
                    if ans:
                        first = ans["selected"]
                        tries = ans.setdefault("tries", [] if ans.get("correct") else [ans["selected"]])
                        if right:
                            ans["solved"] = True
                        elif selected not in tries:
                            tries.append(selected)
                        if s["status"] == "active":
                            self.db.execute("UPDATE sessions SET state=? WHERE id=?", (json.dumps(state), session_id))
                            self.db.commit()
            if not right and selected not in tries:
                tries = tries + [selected]
            m = self.one("SELECT * FROM mistakes WHERE question_id=?", (qid,))
        if not right:
            return {"id": qid, "correct": False, "solved": False, "tries": tries}
        first = first if first in ("A", "B", "C", "D") else (tries[0] if tries else selected)
        res = full_question(qid)
        res.update({"selected": first, "correct": first == q["answer"], "solved": True, "tries": tries,
                    "inJournal": bool(m), "mistake": self.mistake_view(m) if m else None})
        return res

    def add_mistake(self, qid, selected, today):
        """Save a question to the Mistake Journal (a miss, or a lucky guess)."""
        if qid not in Q:
            raise KeyError(qid)
        q = Q[qid]
        guessed = selected == q["answer"]
        with self.lock:
            m = self.one("SELECT * FROM mistakes WHERE question_id=?", (qid,))
            if m:
                if guessed:
                    self.db.execute("UPDATE mistakes SET unsure=1, due_day=MIN(due_day, ?) WHERE question_id=?",
                                    (add_days(today, 1), qid))
            else:
                wrong = self.one("SELECT COUNT(*) c FROM attempts WHERE question_id=? AND correct=0", (qid,))["c"]
                self.db.execute("INSERT INTO mistakes(question_id, unit, selected, category, unsure, times_wrong, stage, due_day, first_day, last_day) "
                                "VALUES(?,?,?,?,?,?,0,?,?,?)",
                                (qid, q["unit"], selected, "execution" if guessed else default_category(q["unit"]),
                                 int(guessed), 0 if guessed else max(1, wrong), add_days(today, 1), today, today))
            self.db.commit()
            m = self.one("SELECT * FROM mistakes WHERE question_id=?", (qid,))
        return self.mistake_view(m)

    def mistake_view(self, m, full=False):
        qid = m["question_id"]
        q = Q.get(qid)
        if not q:
            return None
        les = LESSONS[q["unit"]]
        sel = m["selected"]
        d = {"questionId": qid, "unit": q["unit"], "unitTitle": les["title"], "moduleTitle": les["moduleTitle"],
             "skill": q["skill"], "difficulty": q["difficulty"], "selected": sel, "answer": q["answer"],
             "category": m["category"], "unsure": bool(m["unsure"]), "timesWrong": m["times_wrong"],
             "timesReviewed": m["times_reviewed"], "stage": m["stage"], "dueDay": m["due_day"],
             "firstDay": m["first_day"], "lastDay": m["last_day"], "concept": les["concept"],
             "whyWrong": q["why"]["ABCD".index(sel)] if sel in ("A", "B", "C", "D") else None,
             "preview": q["passage"][:140]}
        if full:
            d["question"] = full_question(qid)
        return d

    def list_mistakes(self, today, unit=None, status="all"):
        sql, args = "SELECT * FROM mistakes WHERE 1=1", []
        if unit:
            sql += " AND unit=?"
            args.append(unit)
        if status == "due":
            sql += " AND due_day<=?"
            args.append(today)
        elif status == "upcoming":
            sql += " AND due_day>?"
            args.append(today)
        sql += " ORDER BY due_day, times_wrong DESC"
        return [v for v in (self.mistake_view(m, full=True) for m in self.q(sql, args)) if v]

    def flag_unsure(self, qid, selected, today):
        return self.add_mistake(qid, selected or Q[qid]["answer"], today)

    def set_category(self, qid, category):
        if category not in [c["id"] for c in MISTAKE_CATEGORIES]:
            raise ValueError("bad category")
        with self.lock:
            self.db.execute("UPDATE mistakes SET category=? WHERE question_id=?", (category, qid))
            self.db.commit()

    def remove_mistake(self, qid):
        with self.lock:
            self.db.execute("DELETE FROM mistakes WHERE question_id=?", (qid,))
            self.db.commit()

    def upcoming_reviews(self, today, days=7):
        out = []
        for i in range(days):
            d = add_days(today, i)
            n = self.one("SELECT COUNT(*) c FROM mistakes WHERE due_day=?", (d,))["c"] if i else \
                self.one("SELECT COUNT(*) c FROM mistakes WHERE due_day<=?", (d,))["c"]
            out.append({"day": d, "count": n})
        return out

    # ------------------------------------------------------------ masterclass
    def masterclass(self, today):
        stats = self.all_stats(today)
        introduced = set(self.introduced_units())
        units = {}
        for u, les in LESSONS.items():
            p = self.progress(u)
            secs = norm_sections(p["sections"])
            units[u] = {"id": u, "title": les["title"], "short": les["short"], "level": stats[u]["level"],
                        "levelLabel": stats[u]["levelLabel"], "sectionsDone": secs,
                        "lessonDone": bool(p["lesson_done"]) or CORE_SECTIONS.issubset(secs), "introduced": u in introduced,
                        "questionCount": len(BY_UNIT.get(u, []))}
        recommended = next((u for u in SEQUENCE if not units[u]["lessonDone"] and units[u]["level"] != "mastered"), None)
        self.db.commit()
        return {"domains": CONTENT["domains"], "modules": CONTENT["modules"], "units": units,
                "sequence": SEQUENCE, "recommended": recommended}

    def unit_detail(self, unit, today):
        les = LESSONS[unit]
        p = self.progress(unit)
        st = self.unit_stats(unit, today)
        self.db.commit()
        vocab = []
        if unit == "WIC":
            seen = {r["question_id"] for r in self.q("SELECT DISTINCT question_id FROM attempts WHERE unit='WIC'")}
            for qid in BY_UNIT["WIC"]:
                if qid in seen:
                    vocab += [{"word": a, "meaning": b} for a, b in Q[qid]["vocab"]]
        secs = norm_sections(p["sections"])
        return {"lesson": les, "short": SHORT[unit], "worked": WORKED.get(unit, []), "stats": st,
                "levelNote": self.mastery_explainer(st),
                "sectionsDone": secs, "lessonDone": bool(p["lesson_done"]) or CORE_SECTIONS.issubset(secs),
                "sections": MASTERCLASS_SECTIONS, "vocab": vocab}

    def mark_section(self, unit, section, today):
        if unit not in LESSONS or section not in MASTERCLASS_SECTIONS:
            raise ValueError("bad section")
        with self.lock:
            p = self.progress(unit)
            secs = norm_sections(p["sections"])
            if section not in secs:
                secs.append(section)
            done = int(CORE_SECTIONS.issubset(secs))
            self.db.execute("UPDATE unit_progress SET sections=?, lesson_done=?, introduced_day=COALESCE(introduced_day, ?) WHERE unit=?",
                            (json.dumps(secs), done, today, unit))
            self.db.commit()
            return {"sectionsDone": secs, "lessonDone": bool(done)}

    def masterclass_set(self, unit, kind):
        """Question sets for the Masterclass practice steps."""
        hist = self._question_history()
        plans = {"guided": [(1, 2), (2, 2)], "independent": [(2, 3), (3, 3)],
                 "mastery": [(3, 8), (2, 2)]}
        return self.pick_questions(unit, plans[kind], hist=hist)

    def drill(self, unit, n, today):
        hist = self._question_history()
        if unit and unit != "mixed":
            stats = self.unit_stats(unit, today)
            plan = {"beginner": [(1, 3), (2, 4), (3, 3)], "developing": [(2, 5), (3, 5)]}.get(stats["level"], [(2, 3), (3, 7)])
            return self.pick_questions(unit, plan, hist=hist)[:n]
        stats = self.all_stats(today)
        units = self.introduced_units() or SEQUENCE[:3]
        units.sort(key=lambda u: (LEVELS.index(stats[u]["level"]), stats[u]["recentAccuracy"]))
        out, i = [], 0
        while len(out) < n and i < n * 4:
            u = units[i % len(units)]
            diff = {"beginner": 1, "developing": 2}.get(stats[u]["level"], 3)
            out += self.pick_questions(u, [(diff, 1)], exclude=set(out), hist=hist)
            i += 1
        return out[:n]

    # ------------------------------------------------------------ tutor memory
    def tutor_history(self, thread_id, limit=30):
        rows = self.q("SELECT role, content, created_at FROM tutor_messages WHERE thread_id=? ORDER BY id", (thread_id,))
        return [dict(r) for r in rows][-limit:]

    def tutor_add(self, thread_id, role, content):
        with self.lock:
            self.db.execute("INSERT INTO tutor_messages(thread_id, role, content, created_at) VALUES(?,?,?,?)",
                            (thread_id, role, content, now_iso()))
            self.db.commit()

    def learner_profile(self, today):
        stats = self.all_stats(today)
        cats = self.q("SELECT category, COUNT(*) c FROM mistakes GROUP BY category ORDER BY c DESC")
        lines = ["%s: %s (%d attempts, recent accuracy %d%%)" % (LESSONS[u]["title"], s["levelLabel"], s["attempts"],
                                                                 round(s["recentAccuracy"] * 100))
                 for u, s in stats.items() if s["attempts"]]
        return {"levels": lines or ["No questions answered yet."],
                "mistakeCategories": ", ".join("%s (%d)" % (r["category"], r["c"]) for r in cats) or "none yet"}

    # ------------------------------------------------------------ backup
    def export_all(self):
        with self.lock:
            out = {"app": "sat-academy", "version": 1, "exported_at": now_iso(), "tables": {}}
            for t in USER_TABLES:
                out["tables"][t] = [dict(r) for r in self.q("SELECT * FROM %s" % t)]
            return out

    def import_all(self, data):
        if not isinstance(data, dict) or data.get("app") != "sat-academy" or "tables" not in data:
            raise ValueError("This file is not a SAT Academy backup.")
        tables = data["tables"]
        with self.lock:
            # Safety copy of the current state before replacing anything.
            bdir = os.path.join(self.data_dir, "backups")
            os.makedirs(bdir, exist_ok=True)
            self.db.commit()
            dst = sqlite3.connect(os.path.join(bdir, "before-restore-%s.db" % dt.datetime.now().strftime("%Y%m%d-%H%M%S")))
            self.db.backup(dst)
            dst.close()
            try:
                self.db.execute("BEGIN")
                for t in USER_TABLES:
                    cols = [r["name"] for r in self.q("PRAGMA table_info(%s)" % t)]
                    self.db.execute("DELETE FROM %s" % t)
                    for row in tables.get(t, []):
                        keys = [k for k in row if k in cols]
                        self.db.execute("INSERT INTO %s(%s) VALUES(%s)" % (t, ",".join(keys), ",".join("?" * len(keys))),
                                        [row[k] for k in keys])
                self.db.commit()
            except Exception:
                self.db.rollback()
                raise
