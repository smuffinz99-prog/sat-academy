from .schema import q, w, lesson

WQ = "Which choice completes the text with the most logical and precise word or phrase?"
FQ = "Which choice best states the main purpose of the text?"
SQ = "Which choice best describes the overall structure of the text?"
CTQ = "Based on the texts, how would the author of Text 2 most likely respond to the claim made in Text 1?"

LESSONS = [
lesson("WIC", "WIC", "Words in Context", "Predict your own word from the clues before you look at the choices.",
what="""
A Words in Context question gives you a short passage with either a **blank** or an **underlined word**. You choose the word that best fits the meaning the context requires, or the meaning a word has *in that specific sentence*.

Many SAT words have several meanings. *Novel* can be a book or mean "new". The context decides.
""",
testing="""
The SAT is testing whether you can work out precise meaning from context, which is how strong readers handle unfamiliar or multi-meaning words. Vocabulary helps, but the core skill is reading the clues around the blank.
""",
recognise="""
- *"Which choice completes the text with the most logical and precise word or phrase?"*
- *"As used in the text, what does the word '…' most nearly mean?"*
- Choices are single words or short phrases.
""",
method=[
    "Read the whole passage, not just the sentence with the blank.",
    "Find the **clue**: a word or phrase that tells you what the blank must mean. Look for contrast words (*but*, *although*), cause words (*because*, *so*) and restatements (a colon, a dash, *in other words*).",
    "**Predict** your own simple word or phrase for the blank (*'hard to understand'*, *'not changing'*). Say it in plain English.",
    "Check whether the blank needs a **positive or negative** word, and how **strong** it must be.",
    "Compare your prediction with the choices. Eliminate words that don't match. If you don't know a word, judge the ones you do know first.",
],
traps=[
    ("The common meaning", "For 'what does X most nearly mean', the most common meaning of the word is often the trap."),
    ("Topic words", "A choice that relates to the passage's topic but doesn't fit the sentence's logic."),
    ("Right direction, wrong strength", "*Mildly critical* vs *scathing*: match the intensity the context supports."),
    ("Skipping the prediction", "Reading choices first lets attractive words pull you away from the meaning you need."),
],
revision=[
    "Find the clue, predict a plain-English word, then match.",
    "Contrast words flip the meaning; restatements copy it.",
    "Check positive/negative and strength.",
    "For 'most nearly mean', beware the word's most common meaning.",
    "Eliminate known wrong words when unsure of a hard one.",
],
extra="""
### High-frequency SAT vocabulary

| Word | Meaning |
|---|---|
| ambiguous | open to more than one interpretation |
| corroborate | confirm with additional evidence |
| discern | notice or perceive something not obvious |
| empirical | based on observation or experiment |
| mitigate | make less severe |
| novel (adj.) | new and original |
| paradoxical | seemingly contradictory but possibly true |
| pragmatic | practical, focused on results |
| proliferate | increase rapidly in number |
| scrutinize | examine closely |
| tenuous | very weak or slight |
| ubiquitous | found everywhere |
| undermine | weaken gradually |
| conventional | following what is usual or traditional |
| idiosyncratic | peculiar to one individual |
| substantiate | provide evidence to support |
| meticulous | showing great attention to detail |
| reconcile | make two ideas compatible |
| arbitrary | based on random choice, not reason |
| candid | truthful and straightforward |
""",
concept="Use context clues to predict the meaning required, then choose the word that matches that meaning precisely."),

lesson("TSP", "TSP", "Text Structure and Purpose", "Ask what the author is DOING, not just what the text says.",
what="""
These questions ask **why** the author wrote the text or a part of it (purpose), or **how** the text is organised (structure). Some ask about the function of an underlined sentence.

Answers are written as **actions**: *to describe*, *to argue*, *to introduce a debate and then present a resolution*.
""",
testing="""
The SAT is testing whether you can see a text from the writer's point of view: what job each part is doing. This is a step beyond understanding content.
""",
recognise="""
- *"Which choice best states the main purpose of the text?"*
- *"Which choice best describes the overall structure of the text?"*
- *"Which choice best describes the function of the underlined sentence in the text as a whole?"*
""",
method=[
    "Read the passage and label each sentence with a verb: *introduces*, *describes*, *challenges*, *gives example*, *concludes*.",
    "For **purpose**, combine the labels into one action: *'to present a surprising finding about X'*.",
    "For **structure**, keep the order of the labels: *'describes a belief, then presents evidence against it'*.",
    "For an **underlined sentence**, look at what comes before and after. Does it set up, support, contrast with or conclude?",
    "Check **every word** of each choice. The verb (argue vs describe) and every part must match. One wrong part makes the whole choice wrong.",
],
traps=[
    ("Wrong verb", "*Argue* or *criticize* when the author only *describes* (or vice versa). Tone matters."),
    ("Half right", "Structure answers with two parts where the first is right and the second is wrong."),
    ("Content instead of function", "A choice that summarises what a sentence says rather than what it does."),
    ("Too strong", "*Refute* or *dismiss* when the author only *questions* or *qualifies*."),
],
revision=[
    "Label each sentence with a verb.",
    "Purpose = the main action; structure = the actions in order.",
    "Underlined sentence = its job relative to what's around it.",
    "Every part of the answer must be right, including the verb.",
],
concept="Purpose and structure questions ask what job the text or sentence is doing, so the action verb in the answer must match the author's actual move."),

lesson("CTC", "CTC", "Cross-Text Connections", "Summarise each author in a sentence, then decide how they relate.",
what="""
You read **two short texts** on the same topic (Text 1 and Text 2). The question asks how one author would respond to the other, or what they agree or disagree about.
""",
testing="""
The SAT is testing whether you can track two viewpoints at once and compare them precisely. Authors often agree on facts but disagree about interpretation, or partly agree.
""",
recognise="""
- Two passages labelled **Text 1** and **Text 2**.
- *"Based on the texts, how would the author of Text 2 most likely respond to…"*
- *"Based on the texts, both authors would most likely agree that…"*
""",
method=[
    "Read **Text 1**. Summarise its main claim in one sentence.",
    "Read **Text 2**. Summarise its main claim in one sentence.",
    "Decide the relationship: agree, disagree, partly agree (agree on facts, disagree on cause), or Text 2 adds a complication/qualification.",
    "Find the **specific point** the question is about (often a claim in Text 1). Ask: what would Text 2's author say about exactly that?",
    "Pick the answer that matches the relationship and is grounded in what Text 2 actually says.",
],
traps=[
    ("Total disagreement", "Assuming Text 2 rejects everything in Text 1, when it usually challenges one specific claim."),
    ("Using only one text", "An answer that's true of Text 2 but doesn't respond to Text 1's point."),
    ("Extreme responses", "*Text 1's evidence is fabricated* when Text 2 only says it's incomplete."),
    ("Mixing up the authors", "Attributing Text 1's view to Text 2's author."),
],
revision=[
    "One-sentence summary per text.",
    "Name the relationship: agree, disagree, partly, qualify.",
    "Focus on the specific claim in the question.",
    "Responses are usually measured, not extreme.",
],
concept="Cross-text questions require summarising each author's position and identifying exactly where they agree or differ on the specific point in question."),
]

WORKED = [
w("WIC-W1", "WIC", "Using a contrast clue",
"""Although the scientist's early experiments were ______, producing results that differed every time she repeated them, her later work was remarkably consistent and became a foundation for the field.""",
WQ, ["inconsistent", "influential", "inexpensive", "meticulous"], "A",
"Words in Context (blank)",
"Single-word choices and the question asks for 'the most logical and precise word'.",
["Clue 1: *Although* sets up a contrast with 'her later work was remarkably consistent'.",
 "Clue 2: the phrase right after the blank: 'producing results that differed every time'.",
 "Prediction: *unreliable / not consistent*.",
 "Match: *inconsistent*."],
["Correct: matches 'results that differed every time' and contrasts with 'consistent'.",
 "Influential is positive; the context describes unreliable results.",
 "Cost is never discussed.",
 "Meticulous (careful) is positive and doesn't explain varying results."],
["'Meticulous' sounds scientific and tempting, but it doesn't contrast with 'consistent'."]),

w("TSP-W1", "TSP", "Describing structure",
"""Many people believe that goldfish have a memory span of only a few seconds. Experiments tell a different story. In one study, goldfish were trained to push a lever for food at a particular time of day; months later, they still approached the lever at that hour. Such results suggest that goldfish memory is far more durable than commonly assumed.""",
SQ,
["It describes a scientific experiment and then explains why the experiment was flawed.",
 "It presents a common belief, provides experimental evidence that contradicts it, and states a conclusion based on that evidence.",
 "It compares the memories of goldfish with those of other animals.",
 "It explains how goldfish are trained and argues that training is cruel."],
"B", "Text Structure and Purpose: structure",
"'Which choice best describes the overall structure of the text?'",
["Label each sentence: S1 *presents a common belief*. S2 *signals disagreement*. S3 *gives experimental evidence*. S4 *concludes*.",
 "Prediction: belief → evidence against → conclusion.",
 "Check each choice part by part. Only one has all three parts in order."],
["The experiment isn't criticised; it's used as evidence.",
 "Correct: belief → contradicting evidence → conclusion.",
 "No other animals are mentioned.",
 "No argument about cruelty."],
["Structure answers fail on one wrong part; check every clause."]),

w("CTC-W1", "CTC", "Partial agreement",
"""**Text 1**
Studies show that students who play musical instruments tend to earn higher math scores than students who don't. Clearly, learning music improves mathematical ability, and schools should expand their music programs for this reason.

**Text 2**
It is true that young musicians often excel at math. But families who can afford instruments and lessons also tend to provide other advantages, such as tutoring and quiet study spaces. Without studies that account for these factors, we cannot say that music itself causes better math performance.""",
CTQ,
["By arguing that music lessons harm students' math performance",
 "By agreeing that young musicians tend to perform well in math but questioning whether music is the cause",
 "By claiming that the studies mentioned in Text 1 contained false data",
 "By agreeing that schools should expand music programs to improve math scores"],
"B", "Cross-Text Connections",
"Two texts labelled Text 1 and Text 2 with 'how would the author of Text 2 most likely respond'.",
["Text 1: music students score higher in math → music *causes* better math → expand programs.",
 "Text 2: yes, they score higher (*'It is true…'*), BUT other family advantages could explain it; cause is unproven.",
 "Relationship: agree on the correlation, disagree on the cause.",
 "Only one choice keeps both halves."],
["Too extreme; Text 2 never says music harms math.",
 "Correct: agrees with the pattern, doubts the causal claim.",
 "Text 2 accepts the data ('It is true…'); it questions the interpretation.",
 "Text 2 doesn't endorse Text 1's conclusion."],
["'It is true that…' at the start of Text 2 signals partial agreement before a 'But'."]),
]

QUESTIONS = [
# ---------------- WORDS IN CONTEXT ----------------
q("WIC-001", "WIC", "Blank: contrast clue", 1,
"""The hiking trail was described in the guidebook as easy, but the steep climbs and loose rocks made it surprisingly ______.""",
WQ, ["pleasant", "strenuous", "brief", "familiar"], "B",
"'Described as easy, *but*…' signals a contrast. Steep climbs and loose rocks make a hike hard, so the word must mean *difficult and tiring*: strenuous.",
["Pleasant doesn't contrast with 'easy' and doesn't fit steep climbs.",
 "Correct: strenuous means requiring great effort.",
 "Length isn't the issue; the clues describe difficulty.",
 "Familiar has nothing to do with difficulty."],
vocab=[("strenuous", "requiring great effort or energy")]),

q("WIC-002", "WIC", "Blank: restatement clue", 1,
"""The new manager was praised for being ______: she listened carefully to every employee's concerns and responded with patience and understanding.""",
WQ, ["indifferent", "considerate", "impatient", "secretive"], "B",
"The colon introduces a restatement: listening carefully and responding with patience. The blank must mean *thoughtful of others*.",
["Indifferent means not caring, the opposite.",
 "Correct: considerate means thoughtful toward others.",
 "Contradicts 'patience'.",
 "Nothing suggests hiding information."],
vocab=[("considerate", "careful not to inconvenience or hurt others"), ("indifferent", "having no interest or concern")]),

q("WIC-003", "WIC", "Most nearly means", 1,
"""When the explorer finally reached the summit, the view was so striking that she stopped and simply stared for several minutes.""",
"As used in the text, what does the word \"striking\" most nearly mean?",
["hitting", "impressive", "refusing to work", "lighting"], "B",
"The view made her stop and stare for minutes, so it must be remarkable and impressive. 'Striking' here means attention-grabbing.",
["The literal meaning (hitting something) doesn't apply to a view.",
 "Correct: a striking view is impressive and attention-grabbing.",
 "Workers 'striking' (refusing to work) is a different sense.",
 "Striking a match lights it, which is irrelevant here."],
vocab=[("striking", "attracting attention; impressive")]),

q("WIC-004", "WIC", "Blank: cause clue", 2,
"""Because the historian's argument relied on a single letter whose author was unknown, other scholars considered her conclusions ______ at best.""",
WQ, ["tenuous", "definitive", "celebrated", "redundant"], "A",
"Relying on one anonymous letter makes an argument weak, and 'at best' signals a negative judgment. The blank must mean *weak or poorly supported*.",
["Correct: tenuous means very weak or slight.",
 "Definitive (conclusive) is the opposite of the scholars' view.",
 "Celebrated is positive; the clue is negative.",
 "Redundant means unnecessarily repeated, which doesn't fit."],
vocab=[("tenuous", "very weak or slight"), ("definitive", "conclusive; settling a question")]),

q("WIC-005", "WIC", "Blank: precise meaning", 2,
"""Smartphones have become so ______ that it is now difficult to find a café, train or classroom where no one is using one.""",
WQ, ["obsolete", "ubiquitous", "fragile", "expensive"], "B",
"'So ___ that it is difficult to find a place where no one is using one' means they are everywhere.",
["Obsolete (out of date) contradicts constant use.",
 "Correct: ubiquitous means found everywhere.",
 "Fragility doesn't explain why they're everywhere.",
 "Expense would make them less common, not more."],
vocab=[("ubiquitous", "present or found everywhere"), ("obsolete", "no longer used; out of date")]),

q("WIC-006", "WIC", "Most nearly means", 2,
"""The committee spent weeks debating the proposal, but the final vote was largely a formality: most members had already settled on their positions before the discussion began.""",
"As used in the text, what does the word \"settled\" most nearly mean?",
["calmed", "decided", "colonized", "paid"], "B",
"Members had 'settled on their positions' before discussion, so they had already decided. That's why the vote was a formality.",
["'Settled' can mean calmed, but calming a position makes no sense.",
 "Correct: they had decided their positions.",
 "Settling land (colonizing) is a different sense.",
 "Settling a bill means paying it, which doesn't fit."],
vocab=[("formality", "something done only because it is required, with no real effect")]),

q("WIC-007", "WIC", "Blank: contrast clue", 2,
"""While the first edition of the dictionary included only a few thousand entries, later editions grew ______, eventually listing more than half a million words.""",
WQ, ["modestly", "erratically", "exponentially", "reluctantly"], "C",
"'While' sets up a contrast between a few thousand and half a million entries: enormous growth. The blank must mean *very rapidly/enormously*.",
["Modestly means slightly, which is too weak for 'half a million'.",
 "Erratically means irregularly; the text emphasises size, not irregularity.",
 "Correct: exponentially means increasing very rapidly.",
 "A dictionary can't grow 'reluctantly'; it has no feelings."],
vocab=[("exponentially", "increasing more and more rapidly"), ("erratically", "irregularly, unpredictably")]),

q("WIC-008", "WIC", "Blank: precise meaning", 3,
"""Critics who expected the director's latest film to repeat the formula of her earlier hits were surprised: rather than ______ her established style, the film abandons it entirely in favor of long, quiet scenes with almost no dialogue.""",
WQ, ["parodying", "replicating", "rejecting", "explaining"], "B",
"Critics expected her to 'repeat the formula'. 'Rather than ___ her established style, the film abandons it.' The blank must contrast with 'abandons' and match 'repeat': *replicating*.",
["Parodying (mocking) is a form of abandoning, not repeating.",
 "Correct: replicating = repeating, which critics expected.",
 "Rejecting means abandoning, so it doesn't contrast with 'abandons'.",
 "Explaining doesn't match 'repeat the formula'."],
vocab=[("replicate", "make an exact copy of; repeat"), ("parody", "imitate in a mocking way")]),

q("WIC-009", "WIC", "Blank: tone and strength", 3,
"""Although the reviewer admired the novel's vivid descriptions, she found its plot so ______ that she could rarely predict what any character would do next. That was not a compliment: the characters' choices seemed to follow no logic at all.""",
WQ, ["arbitrary", "suspenseful", "conventional", "intricate"], "A",
"The reviewer criticises the plot ('not a compliment'), and the characters' choices 'follow no logic'. The blank must mean *random, without reason*.",
["Correct: arbitrary means based on random choice rather than reason.",
 "Suspenseful is a compliment, but the text says it was not one.",
 "Conventional (predictable) contradicts 'could rarely predict'.",
 "Intricate (complex) is often positive and doesn't mean 'no logic'."],
vocab=[("arbitrary", "based on random choice or impulse, not reason"), ("conventional", "following what is usual or traditional"), ("intricate", "very complicated or detailed")],
tip="When context tells you the tone (here, 'not a compliment'), eliminate words with the wrong tone first."),

q("WIC-010", "WIC", "Most nearly means", 3,
"""The scientist's paper did not overturn the existing theory; it merely qualified it, showing that the theory held true for most cases but failed under extremely low temperatures.""",
"As used in the text, what does the word \"qualified\" most nearly mean?",
["certified", "limited", "praised", "proved"], "B",
"The paper showed the theory works in most cases but not at very low temperatures. It added a limitation, which is what 'qualify' means in an argument.",
["'Qualified' often means certified (a qualified doctor), the common-meaning trap.",
 "Correct: it restricted the theory's scope.",
 "No praise is described.",
 "Proved overstates; the paper showed where the theory fails."],
vocab=[("qualify (a claim)", "make a statement less absolute by adding limits")]),

q("WIC-011", "WIC", "Blank: precise meaning", 3,
"""For decades, the two research groups published findings that seemed impossible to ______: one reported that the drug lowered blood pressure, while the other found it had no effect at all. A 2019 study finally explained the discrepancy by showing that the drug worked only in patients with a particular gene.""",
WQ, ["reconcile", "publish", "dismiss", "replicate"], "A",
"The findings contradicted each other, and a later study 'explained the discrepancy', bringing them together. The blank: *make consistent with each other*.",
["Correct: reconcile means make two ideas compatible.",
 "They were published; the problem was the contradiction.",
 "Dismissing doesn't connect to the later study 'explaining the discrepancy'.",
 "Replicate means repeat; the issue isn't repetition."],
vocab=[("reconcile", "make two things consistent or compatible"), ("discrepancy", "a difference between things that should match")]),

q("WIC-012", "WIC", "Blank: cause clue", 1,
"""The museum guard was known for being ______; in twenty years, he had never once arrived late for his shift.""",
WQ, ["punctual", "forgetful", "talkative", "careless"], "A",
"The semicolon explains: never late in twenty years. The word must mean *always on time*.",
["Correct: punctual means on time.",
 "Forgetful contradicts his perfect record.",
 "Talkativeness isn't related to arriving on time.",
 "Careless contradicts never arriving late."],
vocab=[("punctual", "happening or arriving on time")]),

q("WIC-013", "WIC", "Blank: precise meaning", 2,
"""The ancient bridge has survived floods, earthquakes and centuries of heavy traffic, a testament to the ______ of the methods its builders used.""",
WQ, ["fragility", "durability", "novelty", "obscurity"], "B",
"Surviving floods, earthquakes and centuries of traffic shows the methods produced something long-lasting.",
["Fragility (weakness) contradicts survival.",
 "Correct: durability means ability to last.",
 "Novelty (newness) doesn't explain survival.",
 "Obscurity (being unknown) is unrelated."],
vocab=[("durability", "the ability to last without wearing out"), ("testament", "evidence or proof of something")]),

q("WIC-014", "WIC", "Blank: tone and strength", 3,
"""The biography is not a work of uncritical admiration. Its author openly acknowledges the inventor's genius, but she is equally ______ about his failures, describing in detail the business decisions that drove two of his companies into bankruptcy.""",
WQ, ["evasive", "candid", "nostalgic", "dismissive"], "B",
"The biography is 'not uncritical'; it 'openly acknowledges' and describes failures 'in detail'. The blank must mean *open and honest*.",
["Evasive (avoiding the subject) contradicts describing failures in detail.",
 "Correct: candid means frank and honest.",
 "Nostalgic (longing for the past) doesn't fit describing failures.",
 "Dismissive means treating something as unimportant; she describes the failures in detail instead."],
vocab=[("candid", "truthful and straightforward"), ("evasive", "avoiding a direct answer")]),

# ---------------- TEXT STRUCTURE AND PURPOSE ----------------
q("TSP-001", "TSP", "Main purpose", 1,
"""The kakapo is a large, flightless parrot found only in New Zealand. It is nocturnal, feeds on plants, and can live for up to ninety years. Because it has no natural defenses against introduced predators such as cats and rats, its population dropped to just 51 birds in 1995. Intensive conservation efforts have since raised the population to more than 240.""",
FQ,
["To argue that cats should be banned in New Zealand",
 "To describe the kakapo and summarize how its population declined and partly recovered",
 "To compare the kakapo with parrots in other countries",
 "To explain why some birds lose the ability to fly"],
"B",
"The text describes the bird (traits), explains its decline (predators), and notes recovery (conservation). It informs; it doesn't argue or compare.",
["The text doesn't argue for a ban.",
 "Correct: description + decline + recovery.",
 "No other parrots are discussed.",
 "Flightlessness is mentioned, not explained."],
tip="Purpose answers start with a verb. Check that it matches the author's tone (describe vs argue)."),

q("TSP-002", "TSP", "Overall structure", 2,
"""Early weather forecasters relied mainly on observations of the sky and on folk sayings, such as "red sky at night, sailor's delight." In the 1850s, the telegraph allowed observers in different cities to share measurements quickly. Forecasters could then track storms as they moved across a region. Today, satellites and computer models allow forecasts several days in advance.""",
SQ,
["It presents a problem and then proposes a solution.",
 "It traces how methods of weather forecasting changed over time.",
 "It compares two competing theories about the causes of storms.",
 "It describes a single forecaster's career."],
"B",
"The text moves chronologically: early methods → 1850s telegraph → today's satellites. That's a historical progression.",
["No problem/solution framing; it's a timeline.",
 "Correct: a chronological history of forecasting.",
 "No theories about storms are compared.",
 "No individual forecaster is discussed."]),

q("TSP-003", "TSP", "Function of a sentence", 2,
"""Bioluminescence, the production of light by living things, is common in the deep ocean, where sunlight cannot reach. [u]Some estimates suggest that three-quarters of deep-sea animals can produce their own light.[/u] Animals use this light to attract prey, find mates, and confuse predators.""",
"Which choice best describes the function of the underlined sentence in the text as a whole?",
["It introduces a scientific debate that the rest of the text resolves.",
 "It provides a statistic that illustrates how common bioluminescence is in the deep ocean.",
 "It explains how deep-sea animals produce light.",
 "It contradicts the claim made in the first sentence."],
"B",
"Sentence 1 claims bioluminescence is 'common in the deep ocean'. The underlined sentence backs that up with a number (three-quarters). It illustrates/supports the first claim.",
["No debate is introduced.",
 "Correct: the statistic supports 'common'.",
 "It gives how many, not how.",
 "It supports, rather than contradicts, the first sentence."],
tip="Function = the sentence's job relative to its neighbours."),

q("TSP-004", "TSP", "Main purpose (literary)", 2,
"""The following text is adapted from an original short story.

The kitchen was the only warm room in the house that winter. We did our homework at the long table while my mother cooked, and my father read the newspaper aloud, stopping to explain words we didn't know. Years later, when I had a large house of my own with heat in every room, I sometimes found myself carrying my work to the kitchen, as if the warmth I was looking for could still be found there.""",
FQ,
["To criticize the narrator's parents for failing to heat the house",
 "To show how a childhood memory continues to shape the narrator's behavior as an adult",
 "To describe the narrator's career as a writer",
 "To explain how to prepare a family meal"],
"B",
"The text recalls a warm childhood kitchen, then shows the adult narrator still drawn to the kitchen. The past shapes the present.",
["The tone is fond, not critical.",
 "Correct: links the memory to adult behaviour.",
 "No career is described.",
 "No cooking instructions."]),

q("TSP-005", "TSP", "Overall structure", 3,
"""Economists have traditionally assumed that people make financial decisions rationally, weighing costs and benefits to maximize their gains. Behavioral economists have challenged this view, documenting cases in which people consistently make choices that leave them worse off, such as failing to enroll in employer retirement plans that offer free matching contributions. Yet these researchers do not claim that people are simply irrational; rather, they argue that predictable mental shortcuts shape decisions in ways that can be anticipated and even used to design better policies.""",
SQ,
["It describes a traditional assumption, presents a challenge to that assumption, and then clarifies the nature of the challenge.",
 "It presents a theory, offers evidence supporting it, and concludes that it is correct.",
 "It compares two economic policies and recommends one of them.",
 "It describes an experiment and then explains why its results were misinterpreted."],
"A",
"S1: traditional assumption (rational decisions). S2: behavioral economists challenge it with examples. S3 ('Yet… rather'): clarifies that the challenge isn't 'people are irrational' but 'predictable shortcuts'.",
["Correct: assumption → challenge → clarification of the challenge.",
 "The traditional theory is challenged, not confirmed.",
 "No two policies are compared.",
 "No single experiment is described or reinterpreted."]),

q("TSP-006", "TSP", "Function of a sentence", 3,
"""Many accounts of the invention of the telephone credit Alexander Graham Bell alone. Historians have noted, however, that inventor Elisha Gray filed a design for a similar device on the very same day in 1876. [u]Some scholars go further, arguing that Bell's lawyers may have had improper access to Gray's design.[/u] Whatever the truth of that claim, the story illustrates how often major inventions emerge from several people working on the same problem at once.""",
"Which choice best describes the function of the underlined sentence in the text as a whole?",
["It provides the final proof that Gray invented the telephone.",
 "It presents a stronger, more controversial claim that goes beyond the historians' observation.",
 "It explains why accounts of the telephone credit Bell alone.",
 "It summarizes the main idea of the text."],
"B",
"'Go further' signals escalation: historians note simultaneous filing; some scholars suggest improper access. The next sentence ('Whatever the truth of that claim') shows the author doesn't endorse it, so it's a more controversial claim, not proof.",
["The author explicitly leaves it unresolved ('Whatever the truth').",
 "Correct: escalates beyond the historians' point.",
 "It doesn't explain the Bell-only accounts.",
 "The main idea comes in the last sentence (simultaneous invention)."],
tip="Phrases like 'go further' and 'whatever the truth' tell you how the author regards a claim."),

q("TSP-007", "TSP", "Main purpose", 3,
"""It is tempting to see the decline of handwritten letters as a simple loss. Letters were slow and expensive to send, however, and for most of history only a small, literate portion of the population could write them. Email and text messages, whatever their shortcomings, have made written communication available to billions of people who never had it before. Before mourning the letter, we should consider who was left out of the age of letter writing.""",
FQ,
["To argue that people should return to writing letters by hand",
 "To challenge a purely nostalgic view of letter writing by pointing out who benefits from newer forms of communication",
 "To describe the history of postal services",
 "To criticize email for being less personal than letters"],
"B",
"The author pushes back against seeing the decline of letters as 'a simple loss', noting letters excluded many people and digital messaging includes billions.",
["The opposite of the author's point.",
 "Correct: questions nostalgia by highlighting broader access.",
 "Postal history is background, not the purpose.",
 "The author defends new forms ('whatever their shortcomings')."]),

q("TSP-008", "TSP", "Overall structure", 1,
"""Rubber trees grow naturally in the Amazon rainforest. In the late 1800s, seeds were taken from Brazil and planted in Southeast Asia. Within a few decades, plantations in Malaysia and Indonesia produced more rubber than Brazil did.""",
SQ,
["It describes a sequence of events that changed where rubber was produced.",
 "It argues that rubber trees should be grown only in Brazil.",
 "It compares the taste of rubber from different regions.",
 "It explains the chemistry of rubber."],
"A",
"The text tells a sequence: native to the Amazon → seeds moved to Asia → Asian plantations overtook Brazil.",
["Correct: a sequence of events shifting production.",
 "No argument is made.",
 "Taste is irrelevant to rubber.",
 "No chemistry is discussed."]),

q("TSP-009", "TSP", "Main purpose", 2,
"""Sculptor Simone Leigh often draws on the forms of everyday objects made by Black women, such as clay water jugs, to create large bronze and ceramic figures. In works like *Brick House* (2019), a sixteen-foot bust of a woman whose body merges with a dome-shaped structure, Leigh transforms familiar shapes into monumental ones. Critics note that the scale itself is part of the message: forms long treated as merely functional are presented as worthy of public monuments.""",
FQ,
["To explain how bronze sculptures are cast",
 "To describe how Leigh's work elevates everyday forms by presenting them on a monumental scale",
 "To argue that functional objects are more beautiful than sculptures",
 "To list the museums that display Leigh's sculptures"],
"B",
"The text explains Leigh's source (everyday objects), gives an example, and notes that the monumental scale elevates these forms.",
["Casting techniques aren't explained.",
 "Correct: captures the description and the significance of scale.",
 "No such comparison is made.",
 "No museums are listed."]),

q("TSP-010", "TSP", "Function of a sentence", 1,
"""Many people think of deserts as lifeless. [u]In fact, deserts are home to a wide variety of plants and animals.[/u] Cacti store water in their stems, and kangaroo rats can survive without ever drinking water.""",
"Which choice best describes the function of the underlined sentence in the text as a whole?",
["It corrects a common misconception introduced in the previous sentence.",
 "It gives an example of an animal that lives in the desert.",
 "It explains how cacti store water.",
 "It concludes the text with a summary."],
"A",
"Sentence 1 states a common belief (deserts are lifeless). 'In fact' signals a correction: deserts are full of life. The final sentence gives examples.",
["Correct: it corrects the misconception.",
 "Examples come in the next sentence.",
 "Cacti are explained in the next sentence.",
 "It's in the middle, followed by examples, so it isn't a conclusion."]),

# ---------------- CROSS-TEXT CONNECTIONS ----------------
q("CTC-001", "CTC", "Respond to a claim", 1,
"""**Text 1**
Homework helps students practice what they learn in class. Without regular homework, students forget much of the day's lesson before the next class.

**Text 2**
Assigning large amounts of homework can backfire. When students spend hours on repetitive assignments, they often become tired and lose interest in learning. Short, focused assignments are more effective than long ones.""",
"Based on the texts, how would the author of Text 2 most likely respond to Text 1?",
["By agreeing that homework should be eliminated entirely",
 "By arguing that homework can be useful but should be short and focused",
 "By claiming that students never forget their lessons",
 "By suggesting that teachers should give more homework"],
"B",
"Text 2 doesn't reject homework; it rejects *large amounts* and recommends short, focused assignments. So it partly agrees with Text 1 but adds a limit.",
["Text 1 doesn't argue for elimination, and Text 2 supports short assignments.",
 "Correct: accepts homework's value but limits its amount.",
 "Text 2 says nothing about forgetting.",
 "Text 2 warns against too much homework."]),

q("CTC-002", "CTC", "Respond to a claim", 2,
"""**Text 1**
The decline of honeybee populations is largely the result of pesticide use. Studies have found that bees exposed to certain pesticides have trouble navigating back to their hives. Banning these chemicals would solve the problem.

**Text 2**
Pesticides certainly harm bees, but they are only part of the story. Parasitic mites, the loss of wildflower habitats, and disease all contribute to colony losses. Researchers increasingly argue that bee decline results from these factors acting together.""",
CTQ,
["By arguing that pesticides have no effect on honeybees",
 "By agreeing that pesticides harm bees but disputing that banning them alone would solve the problem",
 "By claiming that honeybee populations are actually increasing",
 "By agreeing that pesticides are the only significant cause of bee decline"],
"B",
"Text 2 accepts that 'pesticides certainly harm bees' but says they are 'only part of the story', listing other causes. So it would dispute that a ban alone would fix things.",
["Contradicts Text 2's 'pesticides certainly harm bees'.",
 "Correct: partial agreement plus a challenge to the single-cause solution.",
 "Text 2 discusses colony losses, not growth.",
 "Text 2 explicitly lists other causes."],
tip="'Certainly X, but…' = agrees on X, disagrees on something larger."),

q("CTC-003", "CTC", "Both authors agree", 2,
"""**Text 1**
The ancient city of Great Zimbabwe, built between the 11th and 15th centuries, is one of Africa's most impressive archaeological sites. Its massive stone walls, built without mortar, demonstrate advanced engineering skills.

**Text 2**
Colonial-era European writers refused to believe that Africans had built Great Zimbabwe, attributing it to foreign visitors instead. Archaeological evidence has since shown conclusively that the city was built by the ancestors of the Shona people, whose sophisticated society controlled regional trade routes.""",
"Based on the texts, both authors would most likely agree with which statement?",
["Great Zimbabwe reflects significant achievements by the society that built it.",
 "Colonial writers correctly identified the builders of Great Zimbabwe.",
 "Great Zimbabwe was built using mortar.",
 "Little is known about the city's construction."],
"A",
"Text 1 praises its engineering; Text 2 describes a 'sophisticated society' with trade networks. Both view the city as a major achievement.",
["Correct: both emphasise the builders' accomplishments.",
 "Text 2 says colonial writers were wrong.",
 "Text 1 says the walls were built *without* mortar.",
 "Both texts present substantial knowledge of the site."]),

q("CTC-004", "CTC", "Respond to a claim", 3,
"""**Text 1**
Some linguists argue that the language we speak shapes how we perceive the world. They point out that speakers of languages with many words for shades of blue are faster at distinguishing between similar blue colors in laboratory tests. This, they claim, shows that language determines perception.

**Text 2**
The speed differences found in color tests are real but small, a fraction of a second. More importantly, speakers of all languages can distinguish the colors when given enough time. Language may nudge attention in subtle ways, but that is very different from determining what people can perceive.""",
CTQ,
["By rejecting the laboratory findings as invalid",
 "By accepting the laboratory findings but arguing that they show only a modest influence of language, not that language determines perception",
 "By agreeing that language determines what people can perceive",
 "By arguing that color perception is unrelated to the eyes"],
"B",
"Text 2 says the differences 'are real but small' and that everyone can distinguish the colors with time. It accepts the data but rejects the strong conclusion ('determines'), allowing only a 'nudge'.",
["Text 2 calls the differences 'real'.",
 "Correct: accepts the data, rejects the strong interpretation.",
 "Text 2 explicitly separates 'nudge' from 'determining'.",
 "Nothing in Text 2 discusses the eyes."]),

q("CTC-005", "CTC", "Respond to a claim", 3,
"""**Text 1**
Urban planners have long recommended building wider roads to reduce traffic congestion. When a road is widened, more cars can travel on it at once, which should shorten commute times.

**Text 2**
Decades of data reveal a pattern known as "induced demand": when roads are widened, people who previously avoided driving at busy times begin to drive, and within a few years traffic returns to its former levels. Adding lanes, in other words, tends to attract more cars rather than relieve congestion over the long term.""",
CTQ,
["By arguing that the expected benefits of widening roads are typically temporary because widening encourages more driving",
 "By agreeing that wider roads permanently shorten commute times",
 "By claiming that no cars use widened roads",
 "By arguing that roads should be made narrower to increase traffic"],
"A",
"Text 1's reasoning: more lanes → shorter commutes. Text 2: more lanes → more drivers → congestion returns 'within a few years'. So any benefit is temporary.",
["Correct: summarises induced demand as a response to Text 1.",
 "Text 2 says traffic returns to former levels.",
 "Text 2 says more cars come, the opposite.",
 "Text 2 doesn't propose narrowing roads, and nobody wants more traffic."]),

q("CTC-006", "CTC", "Respond to a claim", 3,
"""**Text 1**
Historian Ellen Park argues that the growth of public libraries in nineteenth-century Britain was driven mainly by reformers who hoped that access to books would improve workers' moral character and reduce crime.

**Text 2**
Recently discovered borrowing records from several early public libraries show that workers overwhelmingly borrowed novels and travel books rather than the moral and religious works that reformers recommended. Whatever reformers intended, workers used the libraries largely for their own entertainment and curiosity.""",
"Based on the texts, how would the author of Text 2 most likely respond to Park's argument?",
["By claiming that reformers played no role in founding public libraries",
 "By suggesting that even if reformers' goals drove the founding of libraries, workers used them for different purposes",
 "By agreeing that workers' moral character improved because of library use",
 "By arguing that borrowing records are unreliable sources"],
"B",
"Text 2 doesn't dispute *why* libraries were founded ('Whatever reformers intended'); it shows that workers used them for entertainment and curiosity rather than moral improvement. It adds a different angle rather than denying Park's claim.",
["Too extreme: Text 2 concedes reformers had intentions.",
 "Correct: allows Park's account of founding but shows actual use differed.",
 "Text 2 doesn't discuss moral improvement outcomes.",
 "Text 2 relies on borrowing records as its evidence."],
tip="'Whatever X intended…' concedes the point about intentions and shifts to a different issue."),

q("CTC-007", "CTC", "Respond to a claim", 2,
"""**Text 1**
Allowing students to use calculators in math class weakens their basic arithmetic skills. Students who rely on calculators never learn to perform calculations in their heads.

**Text 2**
In a three-year study, students who used calculators for complex problems while also practicing mental arithmetic separately performed as well on arithmetic tests as students who never used calculators. They also scored higher on problem-solving tests.""",
CTQ,
["By arguing that the study described in Text 2 supports Text 1's claim",
 "By suggesting that calculator use need not weaken arithmetic skills when combined with separate practice",
 "By agreeing that calculators should be banned from math classes",
 "By claiming that mental arithmetic is no longer a useful skill"],
"B",
"Text 1 says calculator use weakens arithmetic. Text 2's study shows calculator users who also practiced mental math did just as well, so the weakening isn't inevitable.",
["The study contradicts Text 1's claim.",
 "Correct: calculators plus practice didn't harm arithmetic.",
 "Text 2's results favor calculator use.",
 "Text 2 values arithmetic; it measured it."]),

q("CTC-008", "CTC", "Respond to a claim", 1,
"""**Text 1**
Reading on paper leads to better understanding than reading on a screen, because paper allows readers to see where they are in a text and to flip back easily.

**Text 2**
A recent review of studies found that students understood short texts equally well on paper and on screens. For long texts, however, paper readers performed better.""",
CTQ,
["By arguing that screens are always better for reading",
 "By suggesting that the advantage of paper may apply mainly to longer texts",
 "By claiming that no studies have compared paper and screen reading",
 "By agreeing that paper is better for every kind of text"],
"B",
"Text 2 found equal understanding for short texts but better paper results for long ones. So it would say paper's advantage depends on length.",
["Text 2 never says screens are better.",
 "Correct: qualifies Text 1 by text length.",
 "Text 2 describes a review of such studies.",
 "Text 2 found no difference for short texts."]),
]
