"""Helpers for authoring curriculum content.

Every practice question uses q(); every worked example uses w().
Choices are always four strings (A-D) and `why` holds one explanation per
choice, in the same order, so every option is explained.
"""

LETTERS = "ABCD"


def q(id, unit, skill, diff, passage, question, choices, answer, explain, why,
      tip=None, hint=None, data=None, vocab=None):
    assert len(choices) == 4, id
    assert len(why) == 4, id
    assert answer in LETTERS, id
    assert diff in (1, 2, 3), id
    return {
        "id": id, "unit": unit, "skill": skill, "difficulty": diff,
        "passage": passage.strip(), "question": question.strip(),
        "choices": [c.strip() for c in choices], "answer": answer,
        "explanation": explain.strip(), "why": [w.strip() for w in why],
        "tip": tip, "hint": hint, "data": data, "vocab": vocab or [],
    }


def w(id, unit, title, passage, question, choices, answer, qtype, recognise,
      steps, why, traps, data=None):
    assert len(choices) == 4 and len(why) == 4, id
    return {
        "id": id, "unit": unit, "title": title, "passage": passage.strip(),
        "question": question.strip(), "choices": [c.strip() for c in choices],
        "answer": answer, "qtype": qtype, "recognise": recognise,
        "steps": steps, "why": why, "traps": traps, "data": data,
    }


def lesson(id, module, title, short, what, testing, recognise, method, traps,
           revision, extra=None, concept=None):
    return {
        "id": id, "module": module, "title": title, "short": short,
        "what": what.strip(), "testing": testing.strip(),
        "recognise": recognise.strip(), "method": method, "traps": traps,
        "revision": revision, "extra": (extra or "").strip(),
        "concept": concept or short,
    }
