from .schema import q, w, lesson

CQ = "Which choice completes the text so that it conforms to the conventions of Standard English?"

LESSONS = [
lesson("F1", "FSS", "Subject–Verb Agreement", "Find the real subject, ignoring everything between it and the verb.",
what="""
A verb must agree with its **subject** in number: singular subject → singular verb; plural subject → plural verb.

*The bird **sings**.* / *The birds **sing**.*

The SAT makes this hard by placing a lot of words between the subject and the verb, often including a noun of the opposite number.
""",
testing="""
The SAT tests whether you can identify the true grammatical subject in long, complex sentences, which is a core skill for clear writing.
""",
recognise="""
- Choices are the same verb in different forms: *is / are*, *has / have*, *shows / show*, *was / were*.
- Often a prepositional phrase (*of the…*, *in the…*) or clause sits between the subject and the blank.
""",
method=[
    "Find the verb blank. Ask: **who or what** is doing this action?",
    "Cross out prepositional phrases (*of the scientists*, *in the forest*) and extra phrases between commas or dashes.",
    "Identify the remaining subject noun. Singular or plural?",
    "Choose the verb that matches. Also check tense against the rest of the passage.",
    "Special cases: *each, every, either, neither, everyone, the number of* → singular. *A number of* → plural. *A and B* → plural. *A or B* → match the closer noun.",
],
traps=[
    ("The nearest noun", "*The collection of rare books **is**…* not *are*. 'Books' is inside the prepositional phrase."),
    ("Inverted sentences", "*Among the ruins **were** two statues.* The subject (statues) comes after the verb."),
    ("Collective nouns", "*The team*, *the committee*, *the population* are singular in Standard English."),
    ("Subjects that look plural", "*Each of the students **has**…*, *The number of applicants **has** grown.*"),
],
revision=[
    "Cross out 'of…' phrases and anything between commas.",
    "Singular subject → verb ending in -s (is, has, shows).",
    "Each, every, neither, the number → singular.",
    "A and B → plural.",
    "In inverted sentences, find the subject after the verb.",
],
concept="A verb must agree in number with its true subject, not with a nearby noun in a phrase that modifies the subject."),

lesson("F2", "FSS", "Pronouns: Agreement and Case", "Every pronoun must clearly match the noun it replaces.",
what="""
A pronoun (*it, they, its, their, he, she, this*) replaces a noun called its **antecedent**. The pronoun must agree with its antecedent in number.

*The company changed **its** logo.* ✓ (company = singular)
*The companies changed **their** logos.* ✓

**Case:** subject pronouns (*I, he, she, we, they, who*) vs object pronouns (*me, him, her, us, them, whom*).
""",
testing="""
The SAT mostly tests pronoun–antecedent agreement in number (*it/its* vs *they/their*), especially with singular collective nouns and long sentences. It sometimes tests *who* vs *whom* and pronoun case after prepositions.
""",
recognise="""
- Choices are pronouns: *it / they*, *its / their*, *this / these*, *who / whom*.
- Often a singular organisation or object is the antecedent.
""",
method=[
    "Find the pronoun blank. Ask: **what noun does it refer to?**",
    "Trace it back carefully. The antecedent may be several words or a sentence earlier.",
    "Singular antecedent → *it, its, this, he, she*. Plural → *they, their, these*.",
    "For *who/whom*: if you could replace it with *he/she*, use *who*; with *him/her*, use *whom*.",
    "After a preposition (*between, for, with, to*), use object pronouns: *between you and **me***.",
],
traps=[
    ("Organisations are singular", "*The museum*, *the government*, *the team* take *it/its*."),
    ("Nearest noun again", "*The flower of the plants opens **its** petals.* The antecedent is 'flower'."),
    ("It's vs its", "*It's* = it is. *Its* = belonging to it. (See Possessives lesson.)"),
],
revision=[
    "Find the antecedent before choosing.",
    "Singular: it/its. Plural: they/their.",
    "Companies, teams, governments = singular.",
    "Who = he; whom = him.",
],
concept="A pronoun must agree in number with the noun it refers to; organisations and collective nouns take singular pronouns."),

lesson("F3", "FSS", "Verb Tense and Verb Forms", "Match the time frame of the passage, and give every sentence a finite main verb.",
what="""
**Tense** tells when an action happens. Verbs in a passage should stay in a consistent time frame unless the meaning requires a change.

- *Simple past:* She **studied**.
- *Present perfect:* She **has studied** (began in the past, connects to now).
- *Past perfect:* She **had studied** (before another past event).

**Verb forms:** finite verbs (*studies, studied*) can be main verbs. Non-finite forms (*studying, to study, having studied*) cannot be main verbs on their own.
""",
testing="""
The SAT tests whether you can choose the tense that fits clues in the passage (dates, other verbs, words like *since*, *by the time*, *currently*), and whether a sentence has a proper main verb.
""",
recognise="""
- Choices are one verb in different tenses: *discovered / discovers / has discovered / will discover*.
- Or finite vs non-finite: *uses / using / to use / having used*.
""",
method=[
    "Look for **time clues**: dates, *since*, *currently*, *by 1900*, *last year*, and the tense of nearby verbs.",
    "Past event, finished → simple past. Started in the past and continues → present perfect (*has been*). Before another past event → past perfect (*had been*).",
    "General truths and descriptions of works/research findings often use present tense.",
    "Check whether the sentence already has a main verb. If not, the blank needs a finite verb. If it does, the blank often needs a non-finite form (*to…*, *-ing*).",
    "Check agreement too: the tense choice still has to match the subject.",
],
traps=[
    ("Ignoring the time clue", "'In 1928' signals simple past, not present perfect."),
    ("Since = perfect", "*Since 2010, the city **has built**…*"),
    ("Two main verbs", "*The study, which examined…, **finding** that…* — no main verb."),
],
revision=[
    "Match tense to time clues and surrounding verbs.",
    "Since/for + time to now → present perfect.",
    "Earlier past → past perfect (had + verb).",
    "Every sentence needs one finite main verb.",
],
concept="Verb tense must match the time frame established by the passage, and each clause needs a finite main verb."),

lesson("F4", "FSS", "Modifiers", "An introductory phrase describes whatever comes right after the comma.",
what="""
A **modifier** is a word or phrase that describes something. It must be placed next to the thing it describes.

**Dangling modifier:** *Walking to school, the rain started.* ✗ (The rain wasn't walking.)
*Walking to school, **I** got caught in the rain.* ✓
""",
testing="""
The SAT tests whether the noun immediately after an introductory phrase is the one that phrase logically describes. Choices usually rearrange the start of the main clause.
""",
recognise="""
- The sentence begins with a descriptive phrase followed by a comma: *Born in Lagos, …* / *Known for her murals, …* / *After analyzing the data, …*
- The blank comes right after that comma, and choices start with different nouns.
""",
method=[
    "Read the introductory phrase. Ask: **who or what** is being described?",
    "The answer must put that person or thing **immediately** after the comma.",
    "Eliminate choices that begin with something else (a possessive like *her work*, an object, *it*, *there*).",
    "Careful with possessives: *Known for her murals, **Diego's** work…* — the subject is 'work', not Diego.",
],
traps=[
    ("Possessive subject", "*Raised in Ohio, Toni Morrison's novels…* ✗ The novels weren't raised in Ohio."),
    ("Passive voice", "*Analyzing the samples, a discovery was made…* ✗ Who analyzed? Not 'a discovery'."),
],
revision=[
    "Introductory phrase → describes the first noun after the comma.",
    "Ask 'who did this?' and put that noun first.",
    "Possessives (Morrison's) shift the subject to the thing owned.",
],
concept="A modifying phrase must be placed directly next to the noun it describes; an introductory phrase modifies the subject that immediately follows it."),

lesson("F5", "FSS", "Possessives and Plurals", "Apostrophes show ownership, never plurals.",
what="""
- **Plural** (more than one): *scientists*, *cities* — no apostrophe.
- **Singular possessive:** *the scientist's notes* (one scientist).
- **Plural possessive:** *the scientists' notes* (more than one scientist).
- **Irregular plural possessive:** *children's*, *women's*.
- **Pronoun possessives never use apostrophes:** *its, their, whose, yours*.
- **Contractions:** *it's* = it is, *they're* = they are, *who's* = who is.
""",
testing="""
The SAT tests whether you can tell plurals from possessives and choose the correct form when a noun is followed by another noun it owns.
""",
recognise="""
- Choices differ only by apostrophe position: *artists / artist's / artists' / artist's*.
- Or *its / it's*, *their / they're / there*.
""",
method=[
    "For each noun in the blank, ask: **is it owning the next noun?** If yes, it needs a possessive.",
    "Ask: **one or more than one?** Read the context for clues (a number, *each*, *several*, plural verbs).",
    "One owner → 's. Multiple owners ending in s → s'.",
    "If no ownership, no apostrophe.",
    "For pronouns, expand contractions: does *it is* make sense? If not, use *its*.",
],
traps=[
    ("Plural nouns with apostrophes", "*The 1990's* ✗ / *the 1990s* ✓"),
    ("It's / its", "*The bird built **its** nest.* — 'it is nest' makes no sense."),
    ("Two nouns, two decisions", "*The researchers' findings* — check every noun in the choices separately."),
],
revision=[
    "Plural = s, no apostrophe.",
    "One owner = 's; many owners = s'.",
    "Its / their / whose: no apostrophe.",
    "It's = it is; they're = they are.",
],
concept="Use an apostrophe only to show possession (or in contractions), placing it before the s for one owner and after the s for plural owners."),

lesson("F6", "FSS", "Parallel Structure and Logical Comparisons", "Items in a list or comparison must match in form and in kind.",
what="""
**Parallel structure:** items in a list or pair must use the same grammatical form.
*She likes **hiking**, **swimming**, and **reading**.* ✓ / *She likes hiking, to swim, and reading.* ✗

Paired structures need parallel parts too: *not only… but also*, *either… or*, *both… and*.

**Logical comparisons:** compare like with like.
*The climate of Spain is warmer than **that of** Norway.* ✓ (climate vs climate)
*The climate of Spain is warmer than Norway.* ✗ (climate vs a country)
""",
testing="""
The SAT tests whether you keep forms consistent in lists and paired constructions, and whether comparisons compare the same kind of thing. These questions are less frequent than punctuation questions but appear regularly in hard modules.
""",
recognise="""
- Lists of actions or qualities where the blank is one item.
- Sentences with *not only*, *both*, *either*, *rather than*.
- Comparisons with *than*, *like*, *unlike*, *similar to*.
""",
method=[
    "Identify the other items in the list or pair. What form are they? (-ing, to + verb, noun, past tense)",
    "Choose the option that matches that form.",
    "For comparisons, name the two things being compared. Are they the same kind of thing? Use *that of* / *those of* or a possessive to fix mismatches.",
],
traps=[
    ("Mixed forms in lists", "*to analyze, comparing, and to report* ✗"),
    ("Comparing a thing to a person", "*Her paintings are brighter than Monet* ✗ / *than Monet's* ✓"),
],
revision=[
    "Lists and pairs: same form for every item.",
    "Compare like with like (paintings to paintings).",
    "Use that of / those of / possessives to fix comparisons.",
],
concept="Items joined in lists, pairs or comparisons must be grammatically parallel and logically comparable."),
]

WORKED = [
w("F1-W1", "F1", "Skipping the prepositional phrase",
"""The collection of letters written by soldiers during the Civil War ______ historians a rare view of daily life in military camps.""",
CQ, ["offer", "have offered", "offers", "are offering"], "C",
"Form, Structure and Sense: subject–verb agreement",
"Choices are the same verb in different forms (offer/offers/have/are).",
["Find who/what offers: 'The collection'.",
 "Cross out 'of letters written by soldiers during the Civil War' (prepositional phrase).",
 "'The collection' is singular → singular verb.",
 "Only 'offers' is singular."],
["Plural verb; would agree with 'letters' or 'soldiers', not the subject.",
 "Plural helping verb 'have'.",
 "Correct: singular verb matches 'collection'.",
 "Plural helping verb 'are'."],
["'Letters', 'soldiers' and 'camps' are all plural nouns placed to pull you toward a plural verb."]),

w("F4-W1", "F4", "The dangling modifier",
"""Born in Guatemala in 1939, ______ wrote novels and essays that explored the experiences of Indigenous communities.""",
CQ,
["the work of Margarita Carrera", "Margarita Carrera's novels", "Margarita Carrera", "it was Margarita Carrera who"],
"C", "Form, Structure and Sense: modifiers",
"An introductory descriptive phrase followed by a comma, and choices start with different nouns.",
["Who was 'born in Guatemala in 1939'? A person: Margarita Carrera.",
 "So 'Margarita Carrera' must come right after the comma.",
 "Eliminate 'the work', 'novels' (possessive makes 'novels' the subject) and 'it'."],
["The work wasn't born in 1939.",
 "The novels weren't born; the possessive makes 'novels' the subject.",
 "Correct: the person who was born comes right after the comma.",
 "'It' is placed after the comma, so 'it' would be the one born."],
["The possessive trap: 'Margarita Carrera's novels' contains her name, but the grammatical subject is 'novels'."]),

w("F5-W1", "F5", "Plural possessive",
"""In the 1960s, the ______ campaign to protect the wetland convinced the state to declare it a nature reserve.""",
CQ, ["residents", "resident's", "residents'", "residents's"], "C",
"Form, Structure and Sense: possessives",
"Choices differ only in apostrophe placement.",
["Does the word own the next noun? 'Campaign' belongs to the residents → possessive.",
 "One or many? 'Residents' of an area organizing a campaign implies many.",
 "Plural possessive → residents'."],
["No apostrophe: plural, but not possessive.",
 "Singular possessive: one resident.",
 "Correct: many residents' shared campaign.",
 "Not a standard English form."],
["Two decisions every time: ownership (apostrophe?) and number (before or after s?)."]),
]

QUESTIONS = [
# -------- F1 SUBJECT–VERB AGREEMENT --------
q("F1-001", "F1", "Prepositional phrase", 1,
"""The box of old photographs ______ in the attic for more than fifty years before anyone opened it.""",
CQ, ["was stored", "were stored", "are stored", "have been stored"], "A",
"Subject: 'The box' (singular). 'Of old photographs' is a prepositional phrase. The past time frame ('before anyone opened it') calls for simple past: 'was stored'.",
["Correct: singular and past.",
 "Plural; agrees with 'photographs', not 'box'.",
 "Plural and present tense.",
 "Plural and present perfect, which doesn't fit 'before anyone opened it'."]),

q("F1-002", "F1", "Compound subject", 1,
"""Rising temperatures and decreasing rainfall ______ farmers in the region to switch to more drought-resistant crops.""",
CQ, ["is forcing", "has forced", "forces", "are forcing"], "D",
"'Rising temperatures and decreasing rainfall': two subjects joined by 'and' make a plural subject.",
["Singular.",
 "Singular.",
 "Singular.",
 "Correct: plural verb for a compound subject."]),

q("F1-003", "F1", "Collective noun", 2,
"""After weeks of debate, the city council ______ to fund a new public library in the downtown district.""",
CQ, ["have voted", "vote", "has voted", "were voting"], "C",
"'The city council' is a collective noun, treated as singular in Standard English.",
["Plural.",
 "Plural (and present tense clashes with 'after weeks of debate').",
 "Correct: singular.",
 "Plural."]),

q("F1-004", "F1", "Each/every", 2,
"""Each of the twelve paintings in the exhibition ______ a different stage in the artist's long career.""",
CQ, ["represent", "represents", "are representing", "have represented"], "B",
"Subject: 'Each' (singular). 'Of the twelve paintings in the exhibition' is a prepositional phrase.",
["Plural; agrees with 'paintings'.",
 "Correct: singular to match 'Each'.",
 "Plural.",
 "Plural."]),

q("F1-005", "F1", "Inverted sentence", 2,
"""Hidden beneath the floor of the ancient temple ______ a series of tunnels that archaeologists believe were used for storing grain.""",
CQ, ["was", "were", "are", "have been"], "A",
"Inverted sentence: the subject comes after the verb. Rearranged: 'A series of tunnels was hidden beneath…'. 'A series' is singular.",
["Correct: singular to match 'a series'.",
 "Plural; agrees with 'tunnels', which is inside the prepositional phrase.",
 "Plural and present tense.",
 "Plural."],
tip="In inverted sentences, flip the order to find the subject."),

q("F1-006", "F1", "Long modifier", 3,
"""The discovery of microscopic fossils in rocks that formed nearly 3.5 billion years ago ______ that life appeared on Earth much earlier than scientists once believed.""",
CQ, ["suggest", "have suggested", "suggests", "are suggesting"], "C",
"Subject: 'The discovery'. Everything from 'of microscopic fossils' to 'ago' modifies it. Singular.",
["Plural; agrees with 'fossils' or 'rocks'.",
 "Plural.",
 "Correct: singular.",
 "Plural."]),

q("F1-007", "F1", "The number of", 3,
"""Over the past decade, the number of students who study a foreign language in high school ______ steadily, according to a national survey.""",
CQ, ["have declined", "has declined", "are declining", "decline"], "B",
"'The number' is singular (unlike 'a number of', which is plural). 'Over the past decade' calls for present perfect.",
["Plural; agrees with 'students'.",
 "Correct: singular and present perfect.",
 "Plural.",
 "Plural and simple present."],
tip="THE number → singular. A number → plural."),

q("F1-008", "F1", "Neither/nor", 3,
"""Neither the director nor the actors ______ willing to discuss the film's controversial ending in interviews.""",
CQ, ["was", "were", "is", "has been"], "B",
"With 'neither… nor', the verb agrees with the closer subject: 'the actors' (plural).",
["Singular; would only be correct if the closer subject were singular.",
 "Correct: plural to match 'the actors'.",
 "Singular.",
 "Singular."]),

q("F1-009", "F1", "Relative clause", 3,
"""The researcher, along with her two graduate students, ______ spent the past three summers documenting bird species in the cloud forests of Ecuador.""",
CQ, ["have", "has", "are", "were"], "B",
"Subject: 'The researcher'. 'Along with her two graduate students' is an extra phrase between commas and doesn't make the subject plural.",
["Plural; treats 'along with' like 'and'.",
 "Correct: singular to match 'the researcher'.",
 "Plural.",
 "Plural."]),

q("F1-010", "F1", "Prepositional phrase", 1,
"""The sound of the waves ______ many visitors to fall asleep on the beach.""",
CQ, ["cause", "causes", "are causing", "have caused"], "B",
"Subject: 'The sound' (singular). 'Of the waves' is a prepositional phrase.",
["Plural.",
 "Correct.",
 "Plural.",
 "Plural."]),

# -------- F2 PRONOUNS --------
q("F2-001", "F2", "Agreement: singular collective", 1,
"""The museum announced that ______ will offer free admission on the first Sunday of every month.""",
CQ, ["they", "it", "we", "those"], "B",
"Antecedent: 'The museum' (singular). Use 'it'.",
["'They' is plural.",
 "Correct.",
 "'We' doesn't refer to the museum in third-person narration.",
 "'Those' is plural."]),

q("F2-002", "F2", "Agreement: possessive", 1,
"""The honeybee communicates with other members of ______ hive through a series of movements called the waggle dance.""",
CQ, ["their", "its", "it's", "they're"], "B",
"Antecedent: 'The honeybee' (singular). Possessive singular pronoun: 'its'.",
["Plural.",
 "Correct: singular possessive.",
 "'It's' means 'it is'.",
 "'They're' means 'they are'."]),

q("F2-003", "F2", "Agreement: plural", 2,
"""Many ancient Greek temples were originally painted in bright colors; over the centuries, ______ paint faded, leaving the white marble we see today.""",
CQ, ["its", "their", "it's", "there"], "B",
"Antecedent: 'Many ancient Greek temples' (plural). Plural possessive: 'their'.",
["Singular.",
 "Correct.",
 "Contraction for 'it is'.",
 "'There' refers to a place, not possession."]),

q("F2-004", "F2", "Agreement: distant antecedent", 2,
"""The company that developed the vaccine said that, despite months of delays caused by supply shortages and regulatory reviews, ______ expected to deliver the first doses by spring.""",
CQ, ["they", "it", "these", "one"], "B",
"Antecedent: 'The company' (singular), even though many plural nouns ('delays', 'shortages', 'reviews') appear in between.",
["Plural.",
 "Correct.",
 "Plural and unclear.",
 "'One' is a generic pronoun that doesn't refer to the company."]),

q("F2-005", "F2", "Who vs whom", 3,
"""The archaeologist ______ the team credited with locating the shipwreck had studied old navigation charts for years.""",
CQ, ["who", "whom", "which", "whose"], "B",
"Inside the clause: 'the team credited ___ with locating…' → 'the team credited **him/her**'. Object → 'whom'.",
["'Who' is a subject form; the team is the subject of 'credited'.",
 "Correct: object of 'credited'.",
 "'Which' doesn't refer to people.",
 "'Whose' shows possession, which isn't needed here."],
tip="Him → whom. He → who."),

q("F2-006", "F2", "Agreement: plural", 3,
"""Unlike most frogs, which lay eggs in water, the Darwin's frogs of Chile and Argentina carry ______ developing young in the male's vocal sac.""",
CQ, ["its", "his", "their", "it's"], "C",
"Antecedent: 'the Darwin's frogs' (plural; note the plural verb 'carry'). Plural possessive: 'their'.",
["Singular.",
 "Singular masculine; the antecedent is 'frogs', plural.",
 "Correct.",
 "Contraction."]),

q("F2-007", "F2", "Agreement: singular", 3,
"""Every one of the city's public schools must submit ______ annual budget to the board of education by June 30.""",
CQ, ["their", "its", "they're", "there"], "B",
"Antecedent: 'Every one' (singular), not 'schools'.",
["Plural; agrees with 'schools'.",
 "Correct.",
 "Contraction.",
 "Place word."]),

q("F2-008", "F2", "Pronoun case", 2,
"""The coach gave special awards to Priya and ______ for organizing the team's fundraising event.""",
CQ, ["I", "me", "myself", "mine"], "B",
"'To Priya and ___': the pronoun is the object of the preposition 'to'. Test it alone: 'gave awards to **me**'.",
["'I' is a subject pronoun.",
 "Correct: object pronoun.",
 "'Myself' is used only when the subject is also 'I'.",
 "'Mine' is possessive."]),

q("F2-009", "F2", "Agreement: plural", 1,
"""The volunteers finished cleaning the park early, so ______ spent the afternoon planting trees.""",
CQ, ["it", "they", "he", "this"], "B",
"Antecedent: 'The volunteers' (plural). Use 'they'.",
["Singular.",
 "Correct.",
 "Singular.",
 "Singular demonstrative; unclear."]),

# -------- F3 VERB TENSE AND FORM --------
q("F3-001", "F3", "Tense: time clue", 1,
"""In 1928, Scottish scientist Alexander Fleming ______ that a mold called *Penicillium* killed bacteria in a laboratory dish.""",
CQ, ["notices", "noticed", "will notice", "has noticed"], "B",
"'In 1928' marks a finished past event. Simple past: 'noticed'.",
["Present tense.",
 "Correct.",
 "Future tense.",
 "Present perfect connects to the present, which doesn't fit a specific past date."]),

q("F3-002", "F3", "Tense: since", 2,
"""Since its founding in 1945, the United Nations ______ its membership from 51 to 193 countries.""",
CQ, ["expanded", "expands", "has expanded", "had expanded"], "C",
"'Since 1945' describes something that started in the past and continues to now. Present perfect: 'has expanded'.",
["Simple past doesn't fit 'since'.",
 "Simple present doesn't fit 'since'.",
 "Correct.",
 "Past perfect means before another past event; none is given."]),

q("F3-003", "F3", "Tense: consistency", 2,
"""When the explorers finally reached the summit, they planted a flag, took photographs, and ______ down before the storm arrived.""",
CQ, ["begin heading", "began heading", "have begun heading", "will begin heading"], "B",
"The list of actions is in simple past ('planted', 'took'). Keep the same tense: 'began'.",
["Present tense breaks consistency.",
 "Correct.",
 "Present perfect doesn't match.",
 "Future doesn't match."]),

q("F3-004", "F3", "Finite vs non-finite", 2,
"""The new study, which surveyed more than 10,000 adults across twelve countries, ______ that people who regularly spend time in nature report higher levels of well-being.""",
CQ, ["finding", "to find", "having found", "found"], "D",
"The subject 'The new study' needs a main verb. The 'which…' clause is extra. Only 'found' is a finite main verb.",
["'Finding' isn't a main verb.",
 "'To find' isn't a main verb.",
 "'Having found' isn't a main verb.",
 "Correct."]),

q("F3-005", "F3", "Past perfect", 3,
"""By the time the Spanish expedition reached the city of Tenochtitlan in 1519, the Aztecs ______ it into one of the largest cities in the world, with a population of perhaps 200,000.""",
CQ, ["build", "have built", "had built", "will have built"], "C",
"'By the time [past event]' signals an action completed before another past event. Past perfect: 'had built'.",
["Present tense.",
 "Present perfect connects to now, not to 1519.",
 "Correct.",
 "Future perfect."]),

q("F3-006", "F3", "Finite vs non-finite", 3,
"""Hoping to reduce traffic in the city center, officials in Bogotá in the 1970s began closing major roads to cars every Sunday, ______ the streets to cyclists, runners and walkers.""",
CQ, ["opened", "opening", "they opened", "and opens"], "B",
"The sentence already has a main verb ('began'). The phrase after the comma describes a result, so it needs a non-finite form: 'opening'.",
["'Opened' without a conjunction creates two main verbs joined by a comma.",
 "Correct: participial phrase describing the result.",
 "Comma splice ('they opened' is a new independent clause).",
 "Present tense 'opens' clashes with past 'began'."],
tip="If the sentence already has its main verb, the blank often needs an -ing or 'to' form."),

q("F3-007", "F3", "Tense: present for findings", 3,
"""In her 2016 book, historian Mariana Ruiz argues that cotton was central to the Industrial Revolution. She ______ that textile factories in Britain depended on cotton grown by enslaved people in the Americas.""",
CQ, ["shows", "showed", "will show", "had shown"], "A",
"When describing what an author argues or shows in a work, Standard English uses present tense, matching 'argues' in the first sentence.",
["Correct: matches the present tense 'argues'.",
 "Past tense breaks consistency with 'argues'.",
 "Future tense doesn't fit.",
 "Past perfect doesn't fit."]),

q("F3-008", "F3", "Finite vs non-finite", 1,
"""The goal of the program is ______ children in rural areas with access to computers and the internet.""",
CQ, ["provide", "to provide", "provided", "provides"], "B",
"'The goal… is ___' needs a noun-like phrase. The infinitive 'to provide' works: 'The goal is to provide…'.",
["'Is provide' is ungrammatical.",
 "Correct.",
 "'Is provided children' changes the meaning and is ungrammatical here.",
 "'Is provides' is two finite verbs together."]),

q("F3-009", "F3", "Tense: time clue", 1,
"""Next year, the observatory ______ a new telescope that can detect light from the earliest galaxies.""",
CQ, ["installed", "has installed", "will install", "had installed"], "C",
"'Next year' signals the future.",
["Past.",
 "Present perfect.",
 "Correct.",
 "Past perfect."]),

# -------- F4 MODIFIERS --------
q("F4-001", "F4", "Dangling modifier", 1,
"""Running across the field, ______""",
CQ,
["the ball was caught by the dog.",
 "the dog caught the ball.",
 "the ball and the dog met.",
 "the catch was made by the dog."],
"B",
"Who was running across the field? The dog. 'The dog' must come right after the comma.",
["The ball wasn't running.",
 "Correct.",
 "The ball wasn't running.",
 "The catch wasn't running."]),

q("F4-002", "F4", "Dangling modifier", 2,
"""A pioneer of modern dance, ______""",
CQ,
["Martha Graham's technique is still taught in dance schools around the world.",
 "dance schools around the world still teach Martha Graham's technique.",
 "Martha Graham developed a technique that is still taught in dance schools around the world.",
 "the technique of Martha Graham is still taught in dance schools around the world."],
"C",
"'A pioneer of modern dance' describes a person, so 'Martha Graham' must be the subject right after the comma.",
["The subject is 'technique' (possessive trap).",
 "The subject is 'dance schools'.",
 "Correct.",
 "The subject is 'the technique'."]),

q("F4-003", "F4", "Dangling modifier", 2,
"""After analyzing tree rings from more than 1,000 trees, ______""",
CQ,
["the researchers concluded that the region experienced a severe drought in the 1500s.",
 "a severe drought in the 1500s was identified.",
 "the conclusion was that the region experienced a severe drought in the 1500s.",
 "the region's severe drought in the 1500s became clear."],
"A",
"Who analyzed tree rings? The researchers. They must come right after the comma.",
["Correct.",
 "A drought didn't analyze tree rings.",
 "A conclusion didn't analyze tree rings.",
 "The drought didn't analyze anything."]),

q("F4-004", "F4", "Dangling modifier", 3,
"""Known for her detailed drawings of plants and insects, ______""",
CQ,
["Maria Sibylla Merian's 1705 book on the insects of Suriname became a landmark in scientific illustration.",
 "a landmark in scientific illustration was Maria Sibylla Merian's 1705 book on the insects of Suriname.",
 "Maria Sibylla Merian published a 1705 book on the insects of Suriname that became a landmark in scientific illustration.",
 "the insects of Suriname were the subject of a landmark 1705 book by Maria Sibylla Merian."],
"C",
"Who was 'known for her detailed drawings'? Merian herself. 'Maria Sibylla Merian' must be the subject immediately after the comma.",
["Possessive trap: the subject is 'book'.",
 "The subject is 'a landmark'.",
 "Correct.",
 "The subject is 'the insects'."]),

q("F4-005", "F4", "Dangling modifier", 3,
"""Originally built as a railway station in 1900, ______""",
CQ,
["visitors to Paris's Musée d'Orsay can now see one of the world's great collections of Impressionist art.",
 "the Musée d'Orsay in Paris now houses one of the world's great collections of Impressionist art.",
 "Impressionist art is now housed in Paris's Musée d'Orsay.",
 "one of the world's great collections of Impressionist art is now housed in Paris's Musée d'Orsay."],
"B",
"What was built as a railway station? The building, the Musée d'Orsay. It must follow the comma.",
["Visitors weren't built as a railway station.",
 "Correct.",
 "The art wasn't built as a station.",
 "The collection wasn't built as a station."]),

q("F4-006", "F4", "Dangling modifier", 1,
"""Excited about the results, ______""",
CQ,
["the experiment was described by the students to their teacher.",
 "the students described the experiment to their teacher.",
 "the results were described to the teacher.",
 "the description of the experiment was given to the teacher."],
"B",
"Who was excited about the results? The students (who described them). They must come first.",
["The experiment wasn't excited.",
 "Correct.",
 "The results weren't excited about themselves.",
 "A description can't be excited."]),

q("F4-007", "F4", "Dangling modifier", 2,
"""Stretching more than 6,000 kilometers across northern Africa, ______""",
CQ,
["travelers have long found the Sahara Desert difficult to cross.",
 "the Sahara Desert has long been difficult for travelers to cross.",
 "crossing the Sahara Desert has long been difficult for travelers.",
 "the difficulty of crossing the Sahara Desert has long challenged travelers."],
"B",
"What stretches across northern Africa? The Sahara Desert. It must be the subject right after the comma.",
["Travelers don't stretch across Africa.",
 "Correct.",
 "'Crossing' doesn't stretch across Africa.",
 "'The difficulty' doesn't stretch across Africa."]),

q("F4-008", "F4", "Dangling modifier", 3,
"""Raised by her grandmother on a farm in rural Mississippi, ______""",
CQ,
["the stories that Fannie Lou Hamer heard as a child shaped her later work as a civil rights leader.",
 "Fannie Lou Hamer drew on her childhood experiences in her later work as a civil rights leader.",
 "the civil rights work of Fannie Lou Hamer drew on her childhood experiences.",
 "her childhood experiences shaped Fannie Lou Hamer's later work as a civil rights leader."],
"B",
"Who was raised by her grandmother? Fannie Lou Hamer. Only one choice places her name as the subject after the comma.",
["Subject is 'the stories'.",
 "Correct.",
 "Subject is 'the civil rights work'.",
 "Subject is 'her childhood experiences'."]),

# -------- F5 POSSESSIVES AND PLURALS --------
q("F5-001", "F5", "Its vs it's", 1,
"""The town is famous for ______ annual kite festival, which attracts visitors from around the world.""",
CQ, ["it's", "its", "its'", "their"], "B",
"Possessive of 'the town' (singular): 'its'. 'It's' means 'it is'.",
["'It is annual kite festival' makes no sense.",
 "Correct.",
 "'Its'' is never correct.",
 "Plural; the town is singular."]),

q("F5-002", "F5", "Plural, not possessive", 1,
"""The ______ in the botanical garden bloom only once every several years.""",
CQ, ["plant's", "plants'", "plants", "plants's"], "C",
"'Plants' here doesn't own anything; it's simply the plural subject of 'bloom'.",
["Singular possessive.",
 "Plural possessive, but nothing is owned.",
 "Correct: plain plural.",
 "Not a standard English form."]),

q("F5-003", "F5", "Singular possessive", 2,
"""The ______ new album features songs recorded in five different languages.""",
CQ, ["singer's", "singers'", "singers", "singer"], "A",
"The album belongs to one singer: singular possessive 'singer's'.",
["Correct.",
 "Plural possessive: implies many singers.",
 "Plural with no possession.",
 "No possession shown."]),

q("F5-004", "F5", "Two nouns", 2,
"""Several ______ showed that the bridge's supports had weakened over time.""",
CQ, ["engineers' reports", "engineer's reports'", "engineers report's", "engineers's reports"], "A",
"'Several engineers' (plural) own 'reports'. Plural possessive 'engineers'' + plain plural 'reports'.",
["Correct.",
 "'Reports'' implies the reports own something.",
 "'Report's' implies one report owns something, and 'engineers' would need a possessive.",
 "Not a standard English form."]),

q("F5-005", "F5", "Their/they're/there", 2,
"""Scientists studying emperor penguins have found that ______ huddling behavior helps the birds survive temperatures as low as −40°C.""",
CQ, ["they're", "there", "their", "it's"], "C",
"The huddling belongs to the penguins (plural): 'their'.",
["'They are huddling behavior' makes no sense.",
 "'There' indicates a place.",
 "Correct.",
 "'It is huddling behavior' makes no sense."]),

q("F5-006", "F5", "Irregular plural possessive", 3,
"""The ______ section of the library, renovated last year, now includes a reading nook designed to look like a treehouse.""",
CQ, ["childrens'", "children's", "childrens", "childs'"], "B",
"'Children' is already plural (irregular), so add 's for possession: 'children's'.",
["'Childrens' is not a word.",
 "Correct.",
 "'Childrens' is not a word.",
 "'Childs' is not a word."]),

q("F5-007", "F5", "Two nouns", 3,
"""The three ______ led to a recall of thousands of vehicles.""",
CQ, ["manufacturers' errors", "manufacturer's errors'", "manufacturers errors'", "manufacturers' error's"], "A",
"'Three manufacturers' (plural) own the 'errors' (plural, owning nothing). 'Manufacturers'' + 'errors'.",
["Correct.",
 "'Errors'' implies the errors own something, and 'manufacturer's' conflicts with 'three'.",
 "'Manufacturers' needs an apostrophe; 'errors'' shouldn't have one.",
 "'Error's' implies one error owns something."]),

q("F5-008", "F5", "Plural, not possessive", 3,
"""During the ______ cities across the country began building highways that cut through older neighborhoods.""",
CQ, ["1950's,", "1950s,", "1950s'", "1950s's,"], "B",
"Decades are plural, not possessive: '1950s'. A comma closes the introductory phrase 'During the 1950s'.",
["Apostrophe incorrectly makes the decade possessive.",
 "Correct.",
 "Possessive form, and the comma is missing.",
 "Not a standard English form; decades take no apostrophe."]),

q("F5-009", "F5", "Singular possessive", 1,
"""The ______ roots can stretch three times as wide as its branches.""",
CQ, ["trees", "tree's", "trees'", "tree"], "B",
"'Its branches' tells us there's one tree. One tree owns the roots: 'tree's'.",
["Plural, no possession.",
 "Correct.",
 "Plural possessive conflicts with 'its' (singular).",
 "No possession shown."]),

# -------- F6 PARALLELISM AND COMPARISONS --------
q("F6-001", "F6", "Parallel list", 1,
"""The training program teaches volunteers to identify bird species, to record their observations, and ______ the data online.""",
CQ, ["uploading", "to upload", "they upload", "uploaded"], "B",
"The list items use 'to + verb': 'to identify', 'to record', so the third should be 'to upload'.",
["'Uploading' breaks the pattern.",
 "Correct.",
 "A clause breaks the pattern.",
 "Past tense breaks the pattern."]),

q("F6-002", "F6", "Logical comparison", 2,
"""The population of Tokyo is larger than ______""",
CQ, ["New York.", "that of New York.", "the city of New York.", "those of New York."], "B",
"Compare population to population. 'That of New York' = 'the population of New York'.",
["Compares a population to a city.",
 "Correct.",
 "Compares a population to a city.",
 "'Those' is plural; 'population' is singular."]),

q("F6-003", "F6", "Paired construction", 2,
"""The new policy is designed not only to reduce costs but also ______ the quality of patient care.""",
CQ, ["improving", "improves", "to improve", "improvement of"], "C",
"'Not only to reduce… but also to improve': both halves need the same form.",
["Breaks the parallel 'to + verb' pattern.",
 "Breaks the pattern.",
 "Correct.",
 "A noun phrase breaks the pattern."]),

q("F6-004", "F6", "Logical comparison", 3,
"""Unlike ______ the sculptor's later works are made almost entirely from recycled metal.""",
CQ, ["her early career,", "her early sculptures,", "the early period,", "her early style,"], "B",
"Compare works to works. 'Unlike her early sculptures, the sculptor's later works…'.",
["Compares works to a career.",
 "Correct.",
 "Compares works to a period.",
 "Compares works to a style."]),

q("F6-005", "F6", "Parallel list", 3,
"""Founded in 1088, the University of Bologna was known for training lawyers, attracting students from across Europe, and ______ a model for later universities.""",
CQ, ["it served as", "to serve as", "serving as", "served as"], "C",
"The list after 'known for' uses '-ing' forms: 'training', 'attracting', so the third should be 'serving'.",
["A clause breaks the pattern.",
 "Infinitive breaks the pattern.",
 "Correct.",
 "Past tense breaks the pattern."]),

q("F6-006", "F6", "Logical comparison", 3,
"""Researchers found that the songs of humpback whales in the South Pacific change more rapidly than ______""",
CQ, ["whales in the North Atlantic.", "those of whales in the North Atlantic.", "the North Atlantic.", "that of whales in the North Atlantic."], "B",
"Compare songs to songs. 'Those of whales…' = 'the songs of whales…' ('those' is plural to match 'songs').",
["Compares songs to whales.",
 "Correct.",
 "Compares songs to an ocean.",
 "'That' is singular; 'songs' is plural."]),

q("F6-007", "F6", "Paired construction", 1,
"""Visitors can either explore the gardens on their own or ______ a guided tour.""",
CQ, ["joining", "to join", "join", "they join"], "C",
"'Either explore… or join': both verbs in the same base form after 'can'.",
["Breaks the pattern.",
 "Breaks the pattern.",
 "Correct.",
 "Adds a subject, breaking the pattern."]),
]
