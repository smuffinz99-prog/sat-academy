"""Loads, validates and indexes all course content.

Answer positions are shuffled deterministically (seeded by question id) so
the correct letter is spread evenly across A-D and is stable forever.
Letter references inside explanations are remapped to the new order.
"""
import random
import re

from . import curriculum, expression, info_ideas, craft, boundaries, form, extra, bank2_reading, bank2_grammar, worked2

_SOURCES = [info_ideas, craft, expression, boundaries, form, extra, bank2_reading, bank2_grammar, worked2]
LETTERS = "ABCD"

# Letter references used in explanations, e.g. "Only C names", "B shows", "A:".
_VERBS = ("shows|states|does|gives|combines|names|ticks|keeps|identifies|offers|"
          "describes|matches|covers|accomplishes|captures|corrects")
_LETTER_RE = re.compile(r"(?<![\w'*])(?:(Only )([ABCD])\b|([ABCD])(?=\s+(?:%s)\b)|([ABCD])(?=:\s))" % _VERBS)


def _remap_letters(text, mapping):
    def sub(m):
        if m.group(2):
            return m.group(1) + mapping[m.group(2)]
        letter = m.group(3) or m.group(4)
        return mapping[letter]
    return _LETTER_RE.sub(sub, text)


def _shuffle(question):
    rng = random.Random("sat-academy:" + question["id"])
    order = list(range(4))
    rng.shuffle(order)
    old_answer = LETTERS.index(question["answer"])
    mapping = {LETTERS[old]: LETTERS[new] for new, old in enumerate(order)}
    question["choices"] = [question["choices"][i] for i in order]
    question["why"] = [question["why"][i] for i in order]
    question["answer"] = LETTERS[order.index(old_answer)]
    question["explanation"] = _remap_letters(question["explanation"], mapping)
    return question


def load():
    lessons, worked, questions = {}, {}, {}
    for src in _SOURCES:
        for les in src.LESSONS:
            lessons[les["id"]] = les
        for ex in src.WORKED:
            worked.setdefault(ex["unit"], []).append(ex)
        for qu in src.QUESTIONS:
            assert qu["id"] not in questions, "duplicate id " + qu["id"]
            questions[qu["id"]] = _shuffle(dict(qu))

    modules = {m["id"]: m for m in curriculum.MODULES}
    unit_module = {}
    for m in curriculum.MODULES:
        for u in m["units"]:
            assert u in lessons, "missing lesson " + u
            unit_module[u] = m["id"]
    for qu in questions.values():
        assert qu["unit"] in lessons, qu["id"]
    assert sorted(curriculum.SEQUENCE) == sorted(lessons), "sequence must cover every unit"

    by_unit = {}
    for qu in questions.values():
        by_unit.setdefault(qu["unit"], []).append(qu["id"])
    for u in by_unit:
        by_unit[u].sort(key=lambda i: (questions[i]["difficulty"], i))

    domain_titles = {d["id"]: d["title"] for d in curriculum.DOMAINS}
    for u, les in lessons.items():
        m = modules[unit_module[u]]
        les["moduleTitle"] = m["title"]
        les["domain"] = m["domain"]
        les["domainTitle"] = domain_titles[m["domain"]]

    return {
        "lessons": lessons, "worked": worked, "questions": questions,
        "by_unit": by_unit, "unit_module": unit_module,
        "modules": curriculum.MODULES, "domains": curriculum.DOMAINS,
        "sequence": curriculum.SEQUENCE,
    }


CONTENT = load()
