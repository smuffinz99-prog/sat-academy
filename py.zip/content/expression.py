from .schema import q, w, lesson

TQ = "Which choice completes the text with the most logical transition?"
RSQ_INTRO = "While researching a topic, a student has taken the following notes:"

LESSONS = [
lesson("TRN", "TRN", "Transitions", "Name the logical relationship before you read the choices.",
what="""
A transition question shows you a short passage with a blank, usually at the start of a sentence. You choose the word or phrase (such as *however*, *therefore* or *for example*) that correctly shows how the new sentence connects to the one before it.

Transitions are not about style. Exactly one choice states the **true logical relationship** between the ideas.
""",
testing="""
The SAT is testing whether you can follow the logic of a text: does the next idea **contrast** with, **add to**, **result from**, **illustrate** or **continue in time** from the previous one? Strong readers track these relationships automatically, and strong writers signal them clearly.
""",
recognise="""
- The question says: *"Which choice completes the text with the most logical transition?"*
- The blank sits at a sentence boundary, often followed by a comma.
- All four choices are transition words or phrases.
""",
method=[
    "Cover the answer choices.",
    "Read the sentence **before** the blank and the sentence **containing** the blank. Ignore earlier sentences unless you need them.",
    "Ask: *How does the second idea relate to the first?* Put the relationship into one word: contrast, addition, cause/effect, example, similarity, sequence or emphasis/clarification.",
    "Sort the four choices into those same categories.",
    "Eliminate every choice in the wrong category. Usually only one survives. If two survive, choose the one whose precise meaning fits (for example *instead* vs *still*).",
],
traps=[
    ("Reading only the second sentence", "The relationship lives *between* two sentences. A sentence can't be a contrast on its own."),
    ("Picking the 'fancy' word", "*Moreover* and *consequently* sound sophisticated but are wrong if the logic is contrast."),
    ("Confusing contrast types", "*However* (general contrast), *instead* (replacement of one thing with another) and *nevertheless/still* (despite that) are not interchangeable."),
    ("Confusing addition with cause", "If the second sentence is a *consequence*, *in addition* is wrong even though the ideas are related."),
    ("Ignoring 'surprise' contrast", "If the first sentence sets up an expectation and the second breaks it, you need contrast even when both sentences are positive."),
],
revision=[
    "Predict the relationship before looking at choices.",
    "Contrast: however, but, yet, by contrast, nevertheless, still, instead, conversely, on the other hand.",
    "Addition: moreover, furthermore, in addition, also, additionally, likewise (similarity).",
    "Cause/effect: therefore, thus, consequently, as a result, hence, accordingly.",
    "Example: for example, for instance, specifically. Clarification: in other words, that is, in fact.",
    "Sequence: first, then, next, later, subsequently, finally, meanwhile (same time).",
],
extra="""
### The transition toolbox

| Relationship | Ask yourself | Common words |
|---|---|---|
| Contrast | Does the new idea push against the old one? | however, but, yet, by contrast, conversely, on the other hand |
| Concession | Is it true *despite* the previous idea? | nevertheless, nonetheless, still, even so, regardless |
| Replacement | Is one thing happening *in place of* another? | instead, rather |
| Addition | Is it another point in the same direction? | moreover, furthermore, in addition, additionally, also |
| Similarity | Is it the same kind of thing in a new case? | similarly, likewise, in the same way |
| Cause → effect | Is it a result of the previous idea? | therefore, thus, consequently, as a result, hence, accordingly |
| Example | Is it a specific case of a general claim? | for example, for instance, specifically |
| Clarification | Is it restating more precisely? | in other words, that is, in fact |
| Sequence | Is it the next step in time? | then, next, subsequently, later, finally, previously, meanwhile |
| Summary | Is it a wrap-up of what came before? | in sum, ultimately, overall |
""",
concept="A transition must match the logical relationship (contrast, addition, cause, example, sequence) between two ideas."),

lesson("RS", "RS", "Rhetorical Synthesis", "The goal in the question decides the answer, not the notes.",
what="""
You get a bulleted list of a student's research notes, then a question such as *"The student wants to emphasize a similarity between the two novels. Which choice most effectively uses relevant information from the notes to accomplish this goal?"*

Every answer is usually **true** according to the notes. Only one does the **specific job** the question names.
""",
testing="""
The SAT is testing whether you can select and combine information to achieve a specific purpose, which is what real writers do when they decide what belongs in a sentence. It rewards reading the task carefully, not memorising the notes.
""",
recognise="""
- A bulleted list introduced by *"While researching a topic, a student has taken the following notes."*
- The question begins *"The student wants to…"*
- The answer choices are full sentences built from the notes.
""",
method=[
    "Read the **question first**, skipping the notes. Underline the goal: the exact verb (emphasize, explain, introduce, contrast, present) and the object (a similarity, the study's aim, an audience unfamiliar with X).",
    "Turn the goal into a checklist. *'Emphasize a difference in the length of the two bridges'* means: two bridges, a difference, about length.",
    "Check each answer against the checklist without reading the notes in detail. Eliminate any that miss a part of the goal.",
    "If the goal mentions an audience (*'for an audience unfamiliar with…'*), the answer must explain or identify the unfamiliar thing.",
    "Only if two answers remain, glance at the notes to check accuracy.",
],
traps=[
    ("True but off-task", "The most common trap: an accurate sentence from the notes that does a *different* job than the one asked."),
    ("Half the goal", "Comparing two things but not showing the *similarity* asked for, or naming a study without its *method*."),
    ("Audience mismatch", "For an unfamiliar audience, a sentence that uses a technical term without explaining it fails."),
    ("Most detailed = best", "The longest answer with the most facts is often wrong. Extra detail doesn't accomplish the goal."),
],
revision=[
    "Question first, notes last.",
    "Make a checklist from the goal's verb and object; every part must be met.",
    "'Emphasize a similarity/difference' needs both items AND the comparison.",
    "'Unfamiliar audience' needs an explanation of who/what something is.",
    "Correct answers are usually not the longest ones.",
],
concept="The correct rhetorical synthesis answer accomplishes the exact goal in the question; accuracy alone is not enough."),
]

WORKED = [
w("TRN-W1", "TRN", "Spotting a surprise contrast",
"""Most desert plants store water in thick, waxy leaves that slow evaporation. The ocotillo of the Sonoran Desert, ______, drops its leaves entirely during dry spells and grows new ones within days of a rainstorm.""",
TQ, ["for instance,", "however,", "similarly,", "therefore,"], "B",
"Transitions: contrast",
"The blank is a transition between two ideas, and all four choices are transition words.",
["Cover the choices. Sentence 1: most desert plants *keep* water in waxy leaves.",
 "Sentence 2: the ocotillo *drops* its leaves. That is a different strategy, so the relationship is **contrast**.",
 "Sort the choices: *for instance* = example, *however* = contrast, *similarly* = similarity, *therefore* = cause/effect.",
 "Only *however* is a contrast word."],
["Example would mean the ocotillo is one of the plants that store water in waxy leaves, but it does the opposite.",
 "Correct: the ocotillo behaves differently from 'most desert plants'.",
 "Similarity would require the ocotillo to do the same thing as other desert plants.",
 "Nothing in sentence 1 causes the ocotillo to drop its leaves."],
["'For instance' is tempting because the ocotillo IS a desert plant, but it isn't an example of the behaviour described.",
 "The words 'Most…' at the start of sentence 1 often signal that an exception is coming."]),

w("TRN-W2", "TRN", "Choosing between two contrast words",
"""The town council had planned to repair the old footbridge over the river. After engineers found that its supports were badly corroded, ______, the council voted to demolish the bridge and build a new one.""",
TQ, ["for example,", "in addition,", "instead,", "likewise,"], "C",
"Transitions: contrast (replacement)",
"Blank in the middle of a sentence followed by a comma; all choices are transitions.",
["Plan: repair the bridge. What happened: demolish it and build a new one.",
 "The new action happens **in place of** the planned one, a special kind of contrast called replacement.",
 "*Instead* signals exactly that replacement."],
["The demolition is not an example of repairing.",
 "Demolishing is not an additional plan alongside repairing; it replaces it.",
 "Correct: the council chose demolition in place of repair.",
 "Likewise signals similarity; demolishing is not similar to repairing."],
["When the second idea *replaces* the first plan, look for *instead* or *rather*. A general 'however' would be weaker if offered, but 'instead' is the precise fit."]),

w("RS-W1", "RS", "Matching the goal, not the notes",
"""- The Akashi Kaikyō Bridge in Japan opened in 1998.
- Its central span is 1,991 meters long.
- The Golden Gate Bridge in the United States opened in 1937.
- Its central span is 1,280 meters long.
- Both are suspension bridges.""",
RSQ_INTRO + " The student wants to emphasize a difference in the lengths of the two bridges' central spans. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["The Akashi Kaikyō Bridge and the Golden Gate Bridge are both suspension bridges.",
 "The Golden Gate Bridge opened in 1937, while the Akashi Kaikyō Bridge opened in 1998.",
 "The central span of the Akashi Kaikyō Bridge (1,991 meters) is over 700 meters longer than that of the Golden Gate Bridge (1,280 meters).",
 "With a central span of 1,991 meters, the Akashi Kaikyō Bridge opened in Japan in 1998."],
"C", "Rhetorical Synthesis",
"Bulleted notes plus 'The student wants to…'.",
["Read the question first: goal = **difference** in **span length** between **two** bridges.",
 "Checklist: both bridges named? a difference? about length?",
 "A: similarity, not difference. B: difference in dates, not length. D: one bridge only.",
 "C ticks every box."],
["States a similarity, the opposite of the goal.",
 "Shows a difference, but in opening dates, not lengths.",
 "Correct: two bridges, a difference, about span length.",
 "Mentions only one bridge's length, so no comparison."],
["Answer B is the classic trap: it has the right structure (a contrast with 'while') but the wrong content."]),

w("RS-W2", "RS", "Writing for an unfamiliar audience",
"""- Mary Anning (1799–1847) was a fossil collector in Lyme Regis, England.
- In 1811, she and her brother found the first correctly identified ichthyosaur skeleton.
- An ichthyosaur was a marine reptile that lived during the age of dinosaurs.
- Many scientists of her time relied on her finds but rarely credited her.""",
RSQ_INTRO + " The student wants to introduce Mary Anning's 1811 discovery to an audience unfamiliar with ichthyosaurs. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["Mary Anning, a collector from Lyme Regis, England, was rarely credited by scientists of her time.",
 "In 1811, fossil collector Mary Anning and her brother found the first correctly identified skeleton of an ichthyosaur, a marine reptile from the age of dinosaurs.",
 "In 1811, Mary Anning and her brother found the first correctly identified ichthyosaur skeleton.",
 "Ichthyosaurs, which lived during the age of dinosaurs, were marine reptiles."],
"B", "Rhetorical Synthesis (audience)",
"'The student wants to…' plus an audience description.",
["Goal: introduce **the 1811 discovery** to readers who **don't know what an ichthyosaur is**.",
 "Checklist: the discovery is mentioned AND ichthyosaur is explained.",
 "A: no discovery. C: discovery, but no explanation of 'ichthyosaur'. D: explanation, but no discovery.",
 "B does both."],
["Doesn't mention the discovery at all.",
 "Correct: presents the discovery and defines ichthyosaur for unfamiliar readers.",
 "Presents the discovery but assumes the reader knows what an ichthyosaur is.",
 "Explains ichthyosaurs but never introduces Anning's discovery."],
["C is the trap: it accomplishes most of the goal. 'Unfamiliar audience' is a requirement, not decoration."]),
]

QUESTIONS = [
# ---------------- TRANSITIONS ----------------
q("TRN-001", "TRN", "Example", 1,
"""Honeybees communicate the location of flowers through a movement called the waggle dance. The angle of the dance tells other bees which direction to fly. ______, a bee that dances straight up the honeycomb is telling its nestmates to fly directly toward the sun.""",
TQ, ["For example,", "However,", "In contrast,", "Meanwhile,"], "A",
"Sentence 2 states a general rule (the angle shows direction). Sentence 3 gives one specific case of that rule (straight up = toward the sun). A specific case of a general rule is an **example**.",
["Correct: the straight-up dance is a specific instance of the general rule about angles.",
 "'However' signals contrast, but sentence 3 agrees with sentence 2.",
 "'In contrast' signals a difference; there is no opposing idea here.",
 "'Meanwhile' signals something happening at the same time, which doesn't describe this relationship."],
tip="General statement followed by a specific case = example."),

q("TRN-002", "TRN", "Cause and effect", 1,
"""The new subway line cut the trip from the suburbs to downtown from fifty minutes to twenty. ______, the number of commuters who drove into the city fell sharply during the line's first year.""",
TQ, ["Nevertheless,", "As a result,", "For instance,", "Similarly,"], "B",
"A much faster subway trip is a reason people would stop driving. The second sentence is a **consequence** of the first, so a cause-and-effect transition is needed.",
["'Nevertheless' means 'despite this', which would suggest the drop was surprising; it isn't.",
 "Correct: fewer people drove because the subway became faster.",
 "The drop in driving is not an example of the trip becoming shorter.",
 "'Similarly' needs two parallel situations; this is one event causing another."],
tip="Ask: did sentence 1 make sentence 2 happen? If yes, use a cause/effect word."),

q("TRN-003", "TRN", "Addition", 1,
"""Urban trees provide shade that lowers street temperatures on hot afternoons. ______, their roots absorb rainwater that would otherwise overwhelm city drains during storms.""",
TQ, ["In other words,", "Instead,", "Moreover,", "Therefore,"], "C",
"Both sentences list benefits of urban trees: shade, then rainwater absorption. The second adds another point in the same direction, so an **addition** transition fits.",
["'In other words' restates the same idea; absorbing rain is a different benefit from providing shade.",
 "'Instead' means one thing replaces another; trees do both.",
 "Correct: it adds a second benefit to the first.",
 "Shade does not cause roots to absorb rainwater."],
tip="Two separate points supporting the same overall idea = addition."),

q("TRN-004", "TRN", "Contrast", 1,
"""Early critics dismissed Zora Neale Hurston's novel *Their Eyes Were Watching God* as light entertainment, and it went out of print within a decade. ______, today the book is widely taught as a classic of American literature.""",
TQ, ["Likewise,", "Consequently,", "For example,", "However,"], "D",
"The novel was dismissed and went out of print, but today it is celebrated. These ideas point in opposite directions, so the relationship is **contrast**.",
["'Likewise' signals similarity; the book's reception changed dramatically.",
 "Being dismissed did not cause the book to become a classic.",
 "Today's status is not an example of early criticism.",
 "Correct: the current praise contrasts with the early dismissal."]),

q("TRN-005", "TRN", "Sequence", 1,
"""To make paper by hand, workers first soak plant fibers in water until they break down into a pulp. They ______ spread a thin layer of the pulp across a mesh screen and leave it to dry.""",
TQ, ["then", "however", "similarly", "for instance"], "A",
"The text describes steps in a process: first soak the fibres, next spread the pulp. The word *first* in sentence 1 sets up a **sequence**.",
["Correct: spreading the pulp is the next step after soaking.",
 "There is no contrast between the two steps.",
 "Spreading pulp is not similar to soaking fibres; it is the next step.",
 "Spreading the pulp is not an example of soaking."],
tip="Words like 'first' or 'initially' often set up a sequence transition."),

q("TRN-006", "TRN", "Contrast (concession)", 2,
"""The 1906 San Francisco earthquake destroyed much of the city's downtown and left more than half its residents homeless. ______, within nine years the rebuilt city hosted a world's fair that drew nearly nineteen million visitors.""",
TQ, ["Accordingly,", "Still,", "In addition,", "Specifically,"], "B",
"The earthquake was devastating, yet the city recovered enough to host a world's fair. The recovery happened **despite** the destruction. That is concession, a kind of contrast, which *still* expresses.",
["'Accordingly' means 'as a result'. Destruction didn't cause a world's fair.",
 "Correct: the city recovered despite the devastation.",
 "'In addition' would treat the world's fair as another piece of damage.",
 "'Specifically' introduces detail about the earthquake's damage; the world's fair is not a detail of the destruction."]),

q("TRN-007", "TRN", "Similarity", 2,
"""Octopuses can change the color of their skin in a fraction of a second by expanding tiny pigment sacs. ______, cuttlefish, a close relative, use the same kind of sacs to flash rapid color patterns at rivals.""",
TQ, ["By contrast,", "Thus,", "Similarly,", "In sum,"], "C",
"Octopuses use pigment sacs to change colour, and cuttlefish use *the same kind* of sacs. Two animals doing the same thing is **similarity**.",
["'By contrast' would require cuttlefish to do something different; they do the same.",
 "Octopus skin does not cause cuttlefish behaviour.",
 "Correct: it signals that cuttlefish share the octopus's ability.",
 "'In sum' introduces a summary, but sentence 2 adds a new animal rather than summarising."]),

q("TRN-008", "TRN", "Clarification", 2,
"""Economists describe the market for some goods as "inelastic." ______, when the price of these goods rises, people keep buying roughly the same amount because they cannot easily do without them.""",
TQ, ["That is,", "Conversely,", "Meanwhile,", "Even so,"], "A",
"Sentence 2 explains what 'inelastic' means in plain language. A restatement or definition of the previous idea is a **clarification**.",
["Correct: it introduces an explanation of the term just used.",
 "'Conversely' introduces the opposite situation; this sentence defines the same idea.",
 "'Meanwhile' signals a simultaneous but separate event.",
 "'Even so' signals that something holds despite the previous point; there's no tension here."],
tip="If sentence 2 defines or rephrases sentence 1, use 'that is' or 'in other words'."),

q("TRN-009", "TRN", "Contrast", 2,
"""Many people assume that the loudest animals are the largest. The tiny pistol shrimp, ______, snaps its claw so quickly that it produces one of the loudest sounds in the ocean, louder than the calls of many whales.""",
TQ, ["for this reason,", "in fact,", "moreover,", "though,"], "D",
"The assumption is that loud animals are large; the tiny pistol shrimp breaks that assumption. A counterexample to a belief is **contrast**. Mid-sentence, *though* expresses this.",
["The shrimp's loudness is not caused by people's assumption.",
 "'In fact' would confirm or intensify the assumption, but the shrimp contradicts it.",
 "'Moreover' adds a supporting point; the shrimp undermines the assumption instead.",
 "Correct: the shrimp is an exception that goes against the assumption."],
tip="'Many people assume…' almost always sets up a contrast."),

q("TRN-010", "TRN", "Cause and effect", 2,
"""Unlike most metals, gallium melts at about 30°C, below normal human body temperature. ______, a solid piece of gallium held in a person's hand will slowly turn into a silvery liquid.""",
TQ, ["Nonetheless,", "For this reason,", "On the other hand,", "Similarly,"], "B",
"Gallium melts below body temperature, so a hand is warm enough to melt it. The melting is a **result** of the low melting point.",
["'Nonetheless' suggests melting happens despite the low melting point; it happens because of it.",
 "Correct: the low melting point explains why it melts in a hand.",
 "'On the other hand' introduces a contrasting point; there isn't one.",
 "Melting in a hand is not a parallel situation to the melting point; it's a consequence."]),

q("TRN-011", "TRN", "Contrast", 3,
"""For decades, linguists classified the Basque language of northern Spain and southwestern France as an "isolate," a language with no known relatives. Some researchers have proposed links between Basque and the languages of the Caucasus. ______, these proposals remain unaccepted by most specialists, who argue that the supposed similarities are too few to be meaningful.""",
TQ, ["Indeed,", "Subsequently,", "Hence,", "Even so,"], "D",
"Some researchers proposed links; the blank sentence says specialists reject them. The proposals exist, **yet** they aren't accepted. That is concession/contrast, which *even so* expresses.",
["'Indeed' strengthens the previous point; rejecting the proposals weakens it.",
 "'Subsequently' indicates time order, but the sentence is about how the proposals are judged, not what happened next.",
 "'Hence' would mean the proposals caused their own rejection, which doesn't follow.",
 "Correct: despite the proposals, specialists remain unconvinced."]),

q("TRN-012", "TRN", "Cause and effect", 3,
"""Coral reefs depend on algae that live inside coral tissue and supply the coral with food. When ocean water becomes unusually warm, the coral expels these algae. ______, prolonged heat waves can leave whole reefs starving and pale, a condition known as bleaching.""",
TQ, ["Thus,", "Nevertheless,", "Alternatively,", "Likewise,"], "A",
"Corals need the algae for food; heat makes corals lose the algae; therefore long heat waves starve the reef. The final sentence is the logical **consequence** of the two before it.",
["Correct: starving reefs follow from losing the algae that feed them.",
 "'Nevertheless' signals an unexpected result, but starvation is exactly what you'd expect.",
 "'Alternatively' introduces another option; nothing is being chosen between.",
 "'Likewise' needs a second, similar case; this is a result, not a parallel."]),

q("TRN-013", "TRN", "Contrast", 3,
"""Novelist Kazuo Ishiguro's narrators often seem calm and reasonable. Readers who pay close attention to what these narrators leave out, ______, begin to notice regrets and self-deceptions that the narrators themselves never admit.""",
TQ, ["therefore,", "for example,", "however,", "in addition,"], "C",
"On the surface the narrators *seem* calm and reasonable; careful readers discover hidden regret and self-deception. Surface appearance vs hidden reality is **contrast**.",
["Seeming calm doesn't cause readers to notice regrets; the second idea undercuts the first.",
 "Noticing hidden regrets is not an example of the narrators seeming calm.",
 "Correct: what attentive readers find contrasts with the narrators' calm surface.",
 "'In addition' would treat the regrets as another sign of calm reasonableness."],
tip="'Seem' or 'appear' in the first sentence often sets up a contrast with what's really true."),

q("TRN-014", "TRN", "Sequence", 3,
"""In 1928, bacteriologist Alexander Fleming noticed that mold growing in one of his dishes had killed the surrounding bacteria. He named the substance the mold produced penicillin but struggled to purify it in useful amounts. It was not until about a decade ______ that a team at Oxford University developed methods to produce enough penicillin to treat patients.""",
TQ, ["earlier", "later", "instead", "regardless"], "B",
"The passage moves forward in time from Fleming's 1928 discovery to the Oxford team's work. 'Not until about a decade ___' needs a time word pointing **forward**: *later*.",
["'Earlier' points backward in time, before 1928, which contradicts the story of building on Fleming's discovery.",
 "Correct: the Oxford work happened about ten years after Fleming's discovery.",
 "'Instead' signals replacement, and it doesn't fit grammatically with 'a decade'.",
 "'Regardless' means 'despite that', and it doesn't express timing."]),

q("TRN-015", "TRN", "Contrast", 2,
"""Some historians argue that the printing press spread new ideas mainly by making books cheaper. ______, others emphasize that it standardized texts, allowing scholars in different cities to refer to exactly the same words on the same page.""",
TQ, ["By contrast,", "As a result,", "For instance,", "Finally,"], "A",
"'Some historians argue X' is followed by 'others emphasize Y': two different viewpoints. Presenting a different view is **contrast**.",
["Correct: it introduces a different emphasis held by other historians.",
 "The first group's argument does not cause the second group's view.",
 "The second view is not an example of the first.",
 "'Finally' signals the last step in a sequence; there is no sequence here."],
tip="'Some… others…' is a classic contrast pattern."),

# ---------------- RHETORICAL SYNTHESIS ----------------
q("RS-001", "RS", "Emphasize a similarity", 1,
"""- The emperor penguin lives in Antarctica.
- It can dive to depths of over 500 meters.
- The leatherback sea turtle lives in tropical and temperate oceans.
- It can also dive to depths of over 500 meters.
- The emperor penguin is a bird; the leatherback is a reptile.""",
RSQ_INTRO + " The student wants to emphasize a similarity between the emperor penguin and the leatherback sea turtle. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["The emperor penguin is a bird, while the leatherback sea turtle is a reptile.",
 "The emperor penguin lives in Antarctica.",
 "Both the emperor penguin and the leatherback sea turtle can dive to depths of over 500 meters.",
 "The leatherback sea turtle lives in tropical and temperate oceans."],
"C",
"The goal has three parts: both animals, a similarity. Only C names both and states something they share (diving over 500 meters).",
["States a difference (bird vs reptile), not a similarity.",
 "Mentions only the penguin.",
 "Correct: names both animals and a shared ability.",
 "Mentions only the turtle."],
tip="'Similarity' needs both items and a shared feature; look for 'both' or 'also'."),

q("RS-002", "RS", "State the main finding", 1,
"""- Researchers studied 200 students who took a weekly music class.
- They compared them with 200 students who did not.
- After one year, the music students scored 8% higher on a test of listening skills.
- The study was conducted in Toronto, Canada.""",
RSQ_INTRO + " The student wants to present the study's main finding. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["A study conducted in Toronto, Canada, involved 400 students.",
 "Researchers compared 200 students who took a weekly music class with 200 who did not.",
 "The study took place over one year.",
 "After a year, students who took a weekly music class scored 8% higher on a listening-skills test than students who did not."],
"D",
"A 'finding' is what the researchers discovered, which is the result. Only D states the result (8% higher listening scores).",
["Describes the location and size, not what was found.",
 "Describes the method (who was compared), not the result.",
 "Gives the time span, not the result.",
 "Correct: states the outcome of the comparison."],
tip="Finding = result. Method = how. Aim = why. Know the difference."),

q("RS-003", "RS", "Contrast two items", 2,
"""- Igneous rocks form when molten rock cools and hardens.
- Granite is an igneous rock that cools slowly underground.
- Slow cooling gives granite large, visible crystals.
- Basalt is an igneous rock that cools quickly on Earth's surface.
- Quick cooling gives basalt tiny crystals, too small to see without magnification.""",
RSQ_INTRO + " The student wants to contrast the crystal sizes of granite and basalt. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["Granite and basalt are both igneous rocks, which form when molten rock cools and hardens.",
 "Granite cools slowly underground, giving it large, visible crystals, whereas basalt cools quickly on the surface, giving it crystals too small to see without magnification.",
 "Basalt cools quickly on Earth's surface, which gives it tiny crystals.",
 "Igneous rocks, such as granite, form when molten rock cools and hardens underground."],
"B",
"Goal: contrast (difference) + crystal size + both rocks. B names both rocks and contrasts large crystals with tiny ones.",
["Emphasizes what the rocks have in common.",
 "Correct: contrasts granite's large crystals with basalt's tiny ones.",
 "Describes only basalt, so no contrast.",
 "Discusses how igneous rocks form, not crystal size, and mentions only granite."]),

q("RS-004", "RS", "Audience unfamiliar", 2,
"""- Chinua Achebe (1930–2013) was a Nigerian novelist.
- His 1958 novel *Things Fall Apart* depicts life in an Igbo village before and during British colonization.
- The Igbo are an ethnic group in southeastern Nigeria.
- The novel has been translated into more than fifty languages.""",
RSQ_INTRO + " The student wants to describe the setting of *Things Fall Apart* to an audience unfamiliar with the Igbo. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["*Things Fall Apart*, a 1958 novel by Chinua Achebe, has been translated into more than fifty languages.",
 "Chinua Achebe's *Things Fall Apart* is set in an Igbo village.",
 "Chinua Achebe's 1958 novel *Things Fall Apart* is set in a village of the Igbo, an ethnic group in southeastern Nigeria, before and during British colonization.",
 "The Igbo are an ethnic group in southeastern Nigeria."],
"C",
"The goal requires (1) the novel's setting and (2) an explanation of who the Igbo are. Only C does both.",
["Gives translation information, not the setting.",
 "Gives the setting but doesn't explain 'Igbo' for an unfamiliar audience.",
 "Correct: describes the setting and explains who the Igbo are.",
 "Explains the Igbo but never mentions the novel's setting."],
tip="An 'unfamiliar audience' requirement means the answer must explain the unfamiliar term."),

q("RS-005", "RS", "Explain the aim", 2,
"""- Botanist Leila Haddad studied wildflowers growing beside highways.
- She wanted to know whether road salt affects when these flowers bloom.
- She compared flowers 1 meter from the road with flowers 30 meters away.
- Flowers near the road bloomed an average of nine days later.""",
RSQ_INTRO + " The student wants to explain the aim of Haddad's research. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["Haddad found that wildflowers near highways bloomed an average of nine days later than those farther away.",
 "Haddad compared wildflowers 1 meter from a highway with those 30 meters away.",
 "Haddad, a botanist, studied wildflowers growing beside highways.",
 "Haddad sought to determine whether road salt affects the timing of wildflower blooming."],
"D",
"'Aim' means what the researcher wanted to find out. The second note gives it, and D states it.",
["States the result, not the aim.",
 "States the method, not the aim.",
 "Says what she studied, but not the question she wanted to answer.",
 "Correct: states what Haddad wanted to learn."]),

q("RS-006", "RS", "Specify a cause", 2,
"""- The Dust Bowl was a period of severe dust storms in the US Great Plains during the 1930s.
- Farmers had plowed up deep-rooted native grasses to plant wheat.
- Without the grasses, soil was no longer held in place.
- A long drought then dried the exposed soil, and strong winds carried it away.
- Thousands of families left the region.""",
RSQ_INTRO + " The student wants to explain why the soil of the Great Plains blew away during the Dust Bowl. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["During the 1930s, the Dust Bowl caused thousands of families to leave the Great Plains.",
 "After farmers removed the deep-rooted grasses that had held the soil in place, a long drought dried the exposed soil, which strong winds then carried away.",
 "The Dust Bowl was a period of severe dust storms in the 1930s.",
 "Farmers in the Great Plains planted wheat during the early twentieth century."],
"B",
"The goal asks *why* the soil blew away, which is the chain of causes. B gives the full chain: grasses removed → soil loose → drought → wind.",
["Describes an effect of the Dust Bowl, not why the soil blew away.",
 "Correct: explains the causes.",
 "Defines the Dust Bowl without explaining its cause.",
 "Mentions planting wheat but not how that led to soil loss."]),

q("RS-007", "RS", "Introduce a work", 1,
"""- *Las Meninas* is a 1656 painting by Diego Velázquez.
- Velázquez was a Spanish painter.
- The painting shows a young princess surrounded by attendants.
- Velázquez included a portrait of himself at an easel.""",
RSQ_INTRO + " The student wants to introduce *Las Meninas* to a reader who has never seen it. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["*Las Meninas*, a 1656 painting by Spanish artist Diego Velázquez, shows a young princess surrounded by attendants.",
 "Diego Velázquez was a Spanish painter.",
 "Velázquez included himself in the painting.",
 "*Las Meninas* was painted in 1656."],
"A",
"To introduce a painting to someone who hasn't seen it, you need to identify it (title, artist, date) and describe what it shows. A does both.",
["Correct: identifies the work and describes its content.",
 "Mentions the painter but not the painting.",
 "Gives one detail without identifying the painting or the artist by full name.",
 "Gives only the date, which tells the reader nothing about what it shows."]),

q("RS-008", "RS", "Emphasize a difference", 3,
"""- Researchers tracked two populations of song sparrows.
- One population lives in a city park; the other lives in a rural forest.
- City sparrows sang at an average pitch of 3.4 kilohertz.
- Rural sparrows sang at an average pitch of 2.9 kilohertz.
- The researchers suggest that city birds sing higher to be heard over low-pitched traffic noise.""",
RSQ_INTRO + " The student wants to emphasize the difference in pitch between the two populations while also noting a possible explanation for it. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["Researchers studied song sparrows living in a city park and in a rural forest to learn about their songs.",
 "City song sparrows sang at an average pitch of 3.4 kilohertz, possibly to be heard over traffic noise.",
 "City song sparrows sang at a higher average pitch (3.4 kilohertz) than rural ones (2.9 kilohertz), perhaps to be heard over low-pitched traffic noise.",
 "Rural song sparrows sang at 2.9 kilohertz, while city song sparrows sang at 3.4 kilohertz."],
"C",
"The goal has two parts: (1) a pitch *difference* between the populations and (2) a possible explanation. Only C has both.",
["Describes the study's design, with no pitch comparison or explanation.",
 "Gives an explanation but mentions only city birds, so no difference is shown.",
 "Correct: contrasts both pitches and offers the traffic-noise explanation.",
 "Shows the difference but leaves out the explanation."],
tip="Two-part goals ('while also…') eliminate answers that do only half."),

q("RS-009", "RS", "Generalize", 3,
"""- Mangrove forests grow along tropical coastlines.
- In Indonesia, mangroves reduced wave height by up to 66% during storms.
- In Florida, mangrove-lined coasts suffered less property damage during Hurricane Irma than unprotected coasts.
- In Bangladesh, villages behind mangroves reported fewer storm-related injuries.""",
RSQ_INTRO + " The student wants to make a general claim about mangroves supported by the notes. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["In Indonesia, mangroves reduced wave height by up to 66% during storms.",
 "Mangrove forests, which grow along tropical coastlines, can reduce storm damage to nearby coastal communities.",
 "Hurricane Irma caused property damage in Florida.",
 "Villages in Bangladesh that are located behind mangroves reported fewer storm-related injuries than other villages did."],
"B",
"A general claim summarizes what the individual cases have in common. All three examples show mangroves protecting coasts from storms; B states that pattern.",
["One specific example, not a general claim.",
 "Correct: generalizes from the Indonesia, Florida and Bangladesh examples.",
 "A specific fact that doesn't even mention mangroves.",
 "One specific example, not a general claim."],
tip="'General claim' = the common pattern, not one example."),

q("RS-010", "RS", "Present a method", 2,
"""- Archaeologist Tomás Rivera studied ancient trade routes in the Andes.
- He analyzed the chemical makeup of obsidian tools found at 40 sites.
- Each volcanic source of obsidian has a distinct chemical "fingerprint."
- Matching tools to sources revealed that some obsidian traveled over 400 kilometers.""",
RSQ_INTRO + " The student wants to describe the method Rivera used. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["Rivera discovered that some obsidian traveled more than 400 kilometers from its source.",
 "Rivera studied ancient trade routes in the Andes.",
 "Each volcanic source of obsidian has a distinct chemical fingerprint.",
 "Rivera analyzed the chemical makeup of obsidian tools from 40 sites to match each tool to its volcanic source."],
"D",
"Method = how the research was done. D describes the procedure: analyze chemistry, match tools to sources.",
["States the result, not the method.",
 "States the topic, not the method.",
 "A background fact, not a description of what Rivera did.",
 "Correct: describes Rivera's procedure."]),

q("RS-011", "RS", "Emphasize significance", 3,
"""- The Voynich manuscript is a handwritten book dated to the early 1400s.
- It is written in an unknown script.
- No one has been able to read it, despite efforts by professional codebreakers.
- In 2009, radiocarbon dating confirmed that its pages were made between 1404 and 1438.
- Before 2009, some scholars suspected it was a modern forgery.""",
RSQ_INTRO + " The student wants to emphasize the significance of the 2009 radiocarbon dating. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["The 2009 radiocarbon dating, which placed the Voynich manuscript's pages between 1404 and 1438, undermined the suspicion that the book was a modern forgery.",
 "In 2009, the Voynich manuscript's pages were dated to between 1404 and 1438.",
 "The Voynich manuscript is written in an unknown script that professional codebreakers have been unable to read.",
 "Some scholars once suspected that the Voynich manuscript was a modern forgery."],
"A",
"Significance means *why the event mattered*. The dating mattered because it challenged the forgery theory. Only A connects the dating to that consequence.",
["Correct: states the dating and explains why it was important.",
 "States the dating but not why it matters.",
 "Describes the mystery of the script, not the dating.",
 "Mentions the forgery theory but not the dating that challenged it."],
tip="'Significance' needs the fact AND why it mattered."),

q("RS-012", "RS", "Contrast two items", 3,
"""- Composer Florence Price (1887–1953) wrote her Symphony No. 1 in E Minor in 1932.
- It was performed by the Chicago Symphony Orchestra in 1933.
- It was the first symphony by a Black woman performed by a major American orchestra.
- Price drew on African American spirituals and dance rhythms.
- Antonín Dvořák's 1893 *New World* Symphony also drew on American folk melodies.""",
RSQ_INTRO + " The student wants to present Price's Symphony No. 1 as historically significant. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
["Like Dvořák's *New World* Symphony, Florence Price's Symphony No. 1 drew on American musical traditions.",
 "Florence Price's Symphony No. 1, written in 1932, draws on African American spirituals and dance rhythms.",
 "In 1933, Florence Price's Symphony No. 1 became the first symphony by a Black woman to be performed by a major American orchestra.",
 "Florence Price, who lived from 1887 to 1953, wrote a symphony in E minor."],
"C",
"Historical significance = an achievement that marks a first or a turning point. C states the 'first symphony by a Black woman performed by a major American orchestra'.",
["Compares Price to Dvořák, which shows a similarity, not historical significance.",
 "Describes the music's influences, not its place in history.",
 "Correct: states the historic first.",
 "Basic facts with no claim of significance."]),
]
