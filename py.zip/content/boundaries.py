from .schema import q, w, lesson

CQ = "Which choice completes the text so that it conforms to the conventions of Standard English?"

LESSONS = [
lesson("B1", "BND", "Clauses and Complete Sentences", "Every sentence needs an independent clause: a subject plus a main verb.",
what="""
This lesson is the foundation of every punctuation question. You'll learn to identify **independent clauses** (complete thoughts) and **dependent clauses** (incomplete thoughts), and to spot **fragments** and **run-ons**.

- **Independent clause:** has a subject and a main verb, and can stand alone. *The storm ended.*
- **Dependent clause:** has a subject and verb but starts with a subordinating word, so it can't stand alone. *Because the storm ended…*
- **Fragment:** a group of words punctuated as a sentence that has no independent clause. *Because the storm ended.* ✗
- **Run-on / comma splice:** two independent clauses joined with nothing, or with only a comma. *The storm ended, we went outside.* ✗
""",
testing="""
Boundaries questions test whether you know where one complete thought ends and another begins. Almost every punctuation decision depends on answering one question: **is each side of the punctuation an independent clause?**
""",
recognise="""
- The question reads *"Which choice completes the text so that it conforms to the conventions of Standard English?"*
- The four choices contain the **same words** with **different punctuation** (period, comma, semicolon, nothing).
- Or choices differ in verb form: *being*, *is*, *to be*, *having been* (testing whether a sentence has a main verb).
""",
method=[
    "Find where the choices differ. If it's punctuation, you're in Boundaries.",
    "Look at the words **before** the blank. Could they stand alone as a sentence? (subject + main verb, no subordinating word controlling it)",
    "Look at the words **after** the blank. Could they stand alone?",
    "Independent + independent → needs a period, semicolon, or comma + FANBOYS. Never a comma alone or nothing.",
    "If either side is not independent → usually a comma or no punctuation; never a period or semicolon.",
],
traps=[
    ("-ing words aren't main verbs", "*The scientist hoping to find…* has no main verb. Add *is* or *hoped*."),
    ("Subordinators hide in long sentences", "*Although*, *because*, *when*, *while*, *since*, *if*, *which*, *who*, *that* make a clause dependent."),
    ("Long ≠ complete", "A 40-word phrase with no main verb is still a fragment."),
    ("The comma splice", "A comma alone can never join two independent clauses."),
],
revision=[
    "Independent clause = subject + main verb + no subordinator.",
    "Period and semicolon need independent clauses on BOTH sides.",
    "Comma alone between two independent clauses = comma splice ✗.",
    "-ing and 'to' forms are not main verbs.",
    "Subordinators (although, because, which, who…) make clauses dependent.",
],
extra="""
### Common subordinating words
*after, although, as, because, before, if, once, since, than, that, though, unless, until, when, whenever, where, whereas, whether, which, while, who, whom, whose*

### Test: the "stand-alone" check
Cover everything except the clause. Read it aloud as a sentence. If it sounds complete (*"The museum opened in 1902."*), it's independent. If you're left waiting for more (*"Which opened in 1902."*), it's dependent.
""",
concept="Each sentence needs at least one independent clause (subject + main verb), and two independent clauses can't be joined by a comma alone."),

lesson("B2", "BND", "Commas and FANBOYS", "Comma + FANBOYS joins two independent clauses; a comma alone never does.",
what="""
**FANBOYS** are the seven coordinating conjunctions: **F**or, **A**nd, **N**or, **B**ut, **O**r, **Y**et, **S**o.

The rule: **independent clause + comma + FANBOYS + independent clause.**

*The museum was closed, so we visited the park.* ✓

This lesson also covers when commas are **required** with introductory elements and when a comma before a FANBOYS is **wrong** (when the second part is not an independent clause).
""",
testing="""
The SAT tests whether you can correctly join clauses with conjunctions, avoid comma splices, and avoid unnecessary commas when a FANBOYS joins just two verbs or phrases.
""",
recognise="""
- Choices differ in comma placement around *and, but, so, yet*.
- Choices offer *, and* vs *and* vs *,* vs *;*.
- An introductory phrase or clause comes before the main sentence.
""",
method=[
    "Identify both sides of the conjunction. Is the part after *and/but/so* an independent clause (with its own subject)?",
    "Two independent clauses + FANBOYS → comma before the FANBOYS: *I ran, but I missed the bus.*",
    "One subject with two verbs → **no comma**: *I ran and missed the bus.*",
    "Introductory dependent clause or long phrase → comma before the main clause: *When the bell rang, students left.*",
    "Never put a comma between a FANBOYS and the clause it introduces: *but, I missed* ✗.",
],
traps=[
    ("Comma with a compound verb", "*She studied the data, and wrote a report.* ✗ The second part has no subject."),
    ("However is not FANBOYS", "*The test was hard, however, I passed.* ✗ That's a comma splice. Use a semicolon or period before *however*."),
    ("Comma after the conjunction", "*…, but, the results…* ✗"),
],
revision=[
    "FANBOYS: for, and, nor, but, or, yet, so.",
    "IC, + FANBOYS + IC ✓",
    "One subject + two verbs: no comma before 'and'.",
    "However/therefore/moreover are NOT FANBOYS; they need a semicolon or period before them when joining clauses.",
    "Comma after an introductory dependent clause.",
],
concept="Two independent clauses can be joined by a comma plus a FANBOYS conjunction; conjunctive adverbs like 'however' need a semicolon or period."),

lesson("B3", "BND", "Semicolons and Colons", "Semicolon = period strength. Colon = 'here's what I mean'.",
what="""
**Semicolon (;)** works exactly like a period: independent clause on **both** sides.
*The lab was quiet; everyone had gone home.* ✓

Semicolons can also separate items in a list when the items themselves contain commas.

**Colon (:)** needs an **independent clause before it**. After it comes an explanation, example, list or restatement, which can be a complete sentence or just a word or phrase.
*She had one goal: winning the scholarship.* ✓
""",
testing="""
The SAT tests whether you know the strict requirements of each mark. Most wrong answers put a semicolon where one side isn't independent, or a colon after an incomplete clause.
""",
recognise="""
- Choices include ; and : alongside , and .
- The blank appears between two parts of a sentence, or before a list or explanation.
""",
method=[
    "Semicolon test: cover the semicolon. Are both sides independent? If not, the semicolon is wrong.",
    "Colon test: is the part **before** the colon a complete sentence? If not, the colon is wrong.",
    "Does the part after the colon explain, list or illustrate the part before? If yes, the colon fits.",
    "Remember: a semicolon and a period follow the same rule. If a semicolon would work, a period would too, so the SAT never offers both as separate right answers.",
    "Use a semicolon before conjunctive adverbs (*however, therefore, moreover, consequently*) joining two independent clauses: *It rained; however, we played.*",
],
traps=[
    ("Colon after a verb or preposition", "*The ingredients are: flour, eggs…* ✗ The part before the colon is incomplete."),
    ("Semicolon before a dependent clause", "*He left early; because he was tired.* ✗"),
    ("Semicolon + FANBOYS", "Usually unnecessary; a comma does that job."),
],
revision=[
    "; = . (independent on both sides).",
    ": needs a complete sentence before it; anything that explains it can follow.",
    "; before however/therefore when joining two sentences.",
    "Semicolons can separate list items that already contain commas.",
],
concept="A semicolon requires an independent clause on each side; a colon requires an independent clause before it and introduces an explanation, example or list."),

lesson("B4", "BND", "Nonessential Elements: Commas, Dashes, Parentheses", "Matching marks surround extra information; never mix them.",
what="""
A **nonessential** (supplementary) element is extra information you could remove without breaking the sentence.

*The Nile, the longest river in Africa, flows north.* → Remove *the longest river in Africa* and the sentence still works.

It must be surrounded by **matching** marks: two commas, two dashes, or two parentheses. If it comes at the end of a sentence, one mark before it plus the period is enough.

**Essential** information (needed to identify which one) takes **no** commas:
*The student who won the prize is my cousin.* (Which student? The one who won.)
""",
testing="""
The SAT tests whether you can identify where an extra element begins and ends and punctuate both edges consistently. It also tests titles and names: *the novelist Toni Morrison* (no commas) vs *Toni Morrison, a novelist,* (commas).
""",
recognise="""
- A phrase in the middle of a sentence is set off by a comma or dash already, and the blank is at the other end.
- Choices differ between , — and no punctuation at one spot.
- Names next to descriptions: *author Kazuo Ishiguro* vs *the author, Kazuo Ishiguro,*.
""",
method=[
    "Find the extra element. Remove it in your head. Is the sentence still complete and grammatical?",
    "Check where the element **started**. If it opened with a dash, it must close with a dash. If with a comma, close with a comma.",
    "If a **title or descriptor comes right before a name** without *the* or *a* (*biologist Rachel Carson*), use **no** commas between them.",
    "If the description is a noun phrase with *a/the* placed after the name (*Rachel Carson, a biologist,*), use commas around it.",
    "Essential clauses with *that* never take commas; nonessential *which* clauses do.",
],
traps=[
    ("Mismatched marks", "*The lake — the deepest in the region, freezes…* ✗"),
    ("Forgetting the closing mark", "*The lake, the deepest in the region freezes in winter.* ✗"),
    ("Comma between title and name", "*Astronaut, Mae Jemison* ✗ / *Astronaut Mae Jemison* ✓"),
    ("Splitting subject and verb", "Only one comma between the subject and its verb is never correct."),
],
revision=[
    "Extra info = removable, surrounded by matching marks.",
    "Opened with a dash? Close with a dash. Comma? Close with a comma.",
    "Title + name: no commas (novelist Toni Morrison).",
    "The + description after a name: commas (Toni Morrison, the novelist,).",
    "That = essential (no commas); which = nonessential (commas).",
],
concept="Nonessential elements must be enclosed by a matching pair of commas, dashes or parentheses; essential elements take no punctuation."),

lesson("B5", "BND", "Punctuation Traps: When NOT to Punctuate", "If you can't name a rule for a punctuation mark, it probably shouldn't be there.",
what="""
Many SAT questions are won by choosing **no punctuation**. The SAT frequently offers answers that insert commas or other marks where none belong.

Never put a single punctuation mark:
- between a **subject and its verb**: *The results of the study, showed…* ✗
- between a **verb and its object**: *She discovered, that…* ✗
- between a **preposition and its object**: *in, the forest* ✗
- before **that** introducing a clause: *argued, that* ✗
- between an **adjective and its noun**, or after *such as* / *like*: *such as, oak and maple* ✗
- before the first item or after the last item of a list.

Also covered: commas in lists of three or more, and punctuation with quotations.
""",
testing="""
The SAT tests whether you can resist punctuation that 'feels like a pause'. Pauses in speech are not rules. Every mark needs a reason.
""",
recognise="""
- One choice has no punctuation and the others add commas, colons or dashes.
- The blank falls between a subject and verb, or a verb and what follows.
- Choices include *such as,* / *that,* / *, that*.
""",
method=[
    "Identify the grammatical parts on both sides of the blank (subject/verb? verb/object? preposition/object?).",
    "If the blank separates two parts that belong together (subject–verb, verb–object, preposition–object), choose no punctuation.",
    "For lists of three or more items, use commas between items: *A, B, and C*.",
    "For quotations introduced by *said*, *wrote*, *asked*: use a comma. For quotations blended into the sentence (*called it “a triumph”*), no comma.",
    "Ask: what rule justifies this mark? If you can't name one, eliminate it.",
],
traps=[
    ("The 'breath' comma", "Long subjects make you want to pause before the verb. Don't."),
    ("Comma before 'that'", "*Researchers found, that…* ✗"),
    ("Colon after 'such as' or 'including'", "*including: apples…* ✗"),
    ("Punctuation inside an integrated quote", "*described the plan as, “bold”* ✗"),
],
revision=[
    "No single mark between subject and verb.",
    "No mark between verb and object, or before 'that'.",
    "No mark after 'such as', 'including', 'like'.",
    "Lists of 3+: commas between items.",
    "Every mark needs a nameable rule.",
],
concept="Punctuation must not separate closely linked sentence parts such as subject and verb, verb and object, or preposition and object."),
]

WORKED = [
w("B1-W1", "B1", "Finding the missing main verb",
"""The Atacama Desert in Chile, one of the driest places on Earth, ______ some weather stations there have never recorded rain.""",
CQ, ["receives so little rainfall that", "receiving so little rainfall that", "having received so little rainfall,", "to receive so little rainfall that"], "A",
"Boundaries: complete sentences (main verb)",
"The choices keep the same words but change the verb form (receives/receiving/having received/to receive).",
["Find the subject: *The Atacama Desert*. (The part between commas is extra description.)",
 "Look for its main verb outside that description: there isn't one yet; the blank must supply it.",
 "*Receives* is a main verb. *Receiving*, *having received* and *to receive* are not.",
 "Check the rest: '…receives so little rainfall that some weather stations… have never recorded rain.' Complete."],
["Correct: supplies the main verb 'receives'.",
 "'Receiving' isn't a main verb, so the sentence becomes a fragment.",
 "'Having received' isn't a main verb, and the comma creates a splice-like structure.",
 "'To receive' isn't a main verb; fragment."],
["The descriptive phrase between commas makes it easy to forget the subject still needs its verb."]),

w("B2-W1", "B2", "Comma splice with 'however'",
"""The first prototype of the solar car failed to finish the race ______ the second, lighter model completed the course in record time.""",
CQ, ["race, however,", "race; however,", "race however", "race, however"], "B",
"Boundaries: joining independent clauses",
"Choices differ only in punctuation around 'however'.",
["Left: 'The first prototype… failed to finish the race' = independent.",
 "Right: 'the second, lighter model completed the course…' = independent.",
 "Two independent clauses need a period, semicolon, or comma + FANBOYS. *However* is not FANBOYS.",
 "So we need a semicolon before *however* (and a comma after it)."],
["Comma splice: commas alone around 'however' can't join two sentences.",
 "Correct: semicolon separates the clauses; comma follows the transition.",
 "Run-on: no punctuation at all.",
 "Comma splice again."],
["'However' looks like 'but', but grammatically it's an adverb. It can't join clauses with a comma."]),

w("B4-W1", "B4", "Closing what you open",
"""The Svalbard Global Seed Vault — a facility built deep inside a mountain on a remote Norwegian island ______ stores backup copies of more than a million seed samples from around the world.""",
CQ, ["island,", "island —", "island;", "island"], "B",
"Boundaries: nonessential elements",
"A dash opens a phrase before the blank; choices offer different marks at the blank.",
["The phrase 'a facility built… island' is extra description of the vault, opened by a dash.",
 "Remove it: 'The Svalbard Global Seed Vault stores backup copies…' works perfectly.",
 "It opened with a dash, so it must close with a dash."],
["Mismatched: opened with a dash, can't close with a comma.",
 "Correct: matching dashes enclose the extra element.",
 "A semicolon would separate the subject from its verb.",
 "No closing mark leaves the extra element unenclosed."],
["Always look back to see how the element was opened."]),

w("B5-W1", "B5", "No comma between subject and verb",
"""The researchers who spent three winters tracking the migration of snow geese across the Canadian Arctic ______ that the birds' routes had shifted east.""",
CQ, ["concluded", "concluded,", ", concluded", "concluded:"], "A",
"Boundaries: unnecessary punctuation",
"One choice has no punctuation; others add marks around 'concluded'.",
["Subject: 'The researchers who spent three winters tracking… Arctic' (long, but it's all one subject).",
 "Verb: 'concluded'. Object: 'that the birds' routes had shifted east'.",
 "No punctuation goes between a subject and its verb, or between a verb and its 'that' clause."],
["Correct: no punctuation between subject, verb and object.",
 "Comma separates the verb from its 'that' clause.",
 "Comma separates the subject from its verb.",
 "A colon after a verb is incorrect; 'concluded' doesn't complete a sentence on its own."],
["Long subjects tempt you to insert a 'breathing' comma before the verb. Resist it."]),
]

QUESTIONS = [
# -------- B1 CLAUSES & COMPLETE SENTENCES --------
q("B1-001", "B1", "Fragments: main verb", 1,
"""The Great Barrier Reef, which stretches for more than 2,000 kilometers along the coast of Australia, ______ the largest coral reef system in the world.""",
CQ, ["being", "is", "having been", "to be"], "B",
"Subject: *The Great Barrier Reef*. The 'which' clause is extra. The sentence needs a main verb: *is*.",
["'Being' is not a main verb, so this creates a fragment.",
 "Correct: 'is' provides the main verb.",
 "'Having been' is not a main verb; fragment.",
 "'To be' is not a main verb; fragment."],
tip="Skip the 'which/who' clause and check that the subject has a main verb."),

q("B1-002", "B1", "Run-ons", 1,
"""Maria Tallchief became the first Native American prima ballerina in the United States ______ she performed with the New York City Ballet for nearly two decades.""",
CQ, ["States, she", "States she", "States. She", "States, and, she"], "C",
"Both sides are independent clauses: 'Maria Tallchief became… States' and 'she performed… decades'. A period correctly separates them.",
["Comma splice: a comma alone can't join two independent clauses.",
 "Run-on: no punctuation between two independent clauses.",
 "Correct: a period separates two complete sentences.",
 "No comma belongs after 'and'."]),

q("B1-003", "B1", "Fragments: subordinator", 2,
"""Mushrooms are not plants. ______ they cannot make their own food through photosynthesis, they belong to a separate kingdom of living things, the fungi.""",
CQ, ["Because", "Because,", "They are fungi because", "Because of"], "A",
"'Because they cannot make their own food…' is a dependent clause that introduces the main clause 'they belong to…'. The dependent clause + comma + independent clause is correct.",
["Correct: forms 'Because [dependent clause], [independent clause]'.",
 "No comma after a subordinating conjunction.",
 "'They are fungi because they cannot…, they belong…' creates a comma splice.",
 "'Because of' must be followed by a noun phrase, not a clause with a verb."]),

q("B1-004", "B1", "Fragments: main verb", 2,
"""In 1969, the Apollo 11 mission ______ astronauts Neil Armstrong and Buzz Aldrin to the surface of the Moon while Michael Collins orbited above.""",
CQ, ["carrying", "carried", "having carried", "which carried"], "B",
"Subject: *the Apollo 11 mission*. It needs a main verb: *carried*.",
["'Carrying' isn't a main verb; fragment.",
 "Correct: past-tense main verb.",
 "'Having carried' isn't a main verb; fragment.",
 "'Which carried' turns the rest into a dependent clause, leaving the subject without a verb."]),

q("B1-005", "B1", "Run-ons", 2,
"""The Rosetta Stone carries the same decree in three scripts ______ scholars used it to decipher Egyptian hieroglyphs in the 1820s.""",
CQ, ["scripts, because of this,", "scripts, because of this", "scripts; because of this,", "scripts because of this"], "C",
"'The Rosetta Stone carries… scripts' and 'scholars used it…' are both independent. 'Because of this' is a transitional phrase, not a FANBOYS, so a semicolon is needed before it.",
["Comma splice: commas around a transitional phrase can't join two clauses.",
 "Comma splice.",
 "Correct: semicolon separates the clauses; comma after the transition.",
 "Run-on."]),

q("B1-006", "B1", "Fragments: subordinator", 3,
"""The octopus, ______ a nervous system in which two-thirds of the neurons are located in its arms rather than its brain, can solve puzzles and open jars.""",
CQ, ["which has", "it has", "has", "and it has"], "A",
"The phrase between commas must be an extra description of 'the octopus', which leaves 'The octopus… can solve puzzles' as the main clause. 'Which has' creates a nonessential clause.",
["Correct: 'which has…' is a properly enclosed nonessential clause.",
 "'It has' creates a second independent clause between commas, a comma splice.",
 "'Has' gives the octopus two separate main verbs with no conjunction: 'The octopus, has…, can solve…' is ungrammatical.",
 "'And it has' between commas leaves 'can solve' without a proper structure."]),

q("B1-007", "B1", "Run-ons", 3,
"""In 1895, sociologist W. E. B. Du Bois became the first Black American to earn a PhD from Harvard University ______ study *The Philadelphia Negro* (1899) is considered one of the first works of empirical sociology in the United States.""",
CQ, ["University, his", "University his", "University, and his", "University, and, his"], "C",
"'In 1895, sociologist… became the first Black American to earn a PhD from Harvard University' and 'his study… is considered…' are both independent. Comma + FANBOYS ('and') joins them.",
["Comma splice: a comma alone can't join two independent clauses.",
 "Run-on: no punctuation between two independent clauses.",
 "Correct: comma + 'and' joins two independent clauses.",
 "No comma belongs after 'and'."]),

q("B1-008", "B1", "Fragments: main verb", 1,
"""Every autumn, millions of monarch butterflies ______ thousands of kilometers from Canada and the United States to forests in central Mexico.""",
CQ, ["traveling", "to travel", "travel", "having traveled"], "C",
"Subject: *millions of monarch butterflies*. The sentence needs a main verb: *travel*.",
["'Traveling' isn't a main verb.",
 "'To travel' isn't a main verb.",
 "Correct: present-tense main verb for a recurring event.",
 "'Having traveled' isn't a main verb."]),

q("B1-009", "B1", "Fragments: subordinator", 3,
"""Although the novel was rejected by more than a dozen publishers ______ it went on to sell millions of copies and was translated into forty languages.""",
CQ, ["publishers.", "publishers;", "publishers,", "publishers, but"], "C",
"'Although the novel was rejected…' is a dependent clause. It must connect to the main clause with a comma.",
["A period would leave 'Although… publishers' as a fragment.",
 "A semicolon needs independent clauses on both sides.",
 "Correct: dependent clause + comma + independent clause.",
 "'Although' and 'but' together are redundant: both express contrast, and 'although' already links the clauses."],
tip="Although + but = double contrast. Use only one."),

q("B1-010", "B1", "Run-ons", 2,
"""Composer Clara Schumann was a celebrated concert pianist by the age of eleven ______ she later composed songs, chamber music and a piano concerto.""",
CQ, ["eleven", "eleven, she", "eleven; she", "eleven, and, she"], "C",
"Two independent clauses: 'Composer Clara Schumann was… eleven' and 'she later composed…'. A semicolon joins them.",
["The choice adds nothing between the clauses, so 'eleven she later composed' is a run-on.",
 "Comma splice.",
 "Correct: semicolon between two independent clauses.",
 "No comma after 'and'."]),

# -------- B2 COMMAS AND FANBOYS --------
q("B2-001", "B2", "Comma + FANBOYS", 1,
"""The museum's new exhibit features dinosaur skeletons from around the world ______ it has attracted record numbers of visitors.""",
CQ, ["world and", "world, and", "world and,", "world, and,"], "B",
"Both sides are independent ('The museum's new exhibit features…' / 'it has attracted…'), so use a comma before the FANBOYS 'and'.",
["Two independent clauses with 'and' need a comma before it.",
 "Correct: IC, + and + IC.",
 "Comma in the wrong place, after 'and'.",
 "Extra comma after 'and'."]),

q("B2-002", "B2", "Compound verb (no comma)", 1,
"""The volunteers cleaned the beach ______ planted dune grass to prevent erosion.""",
CQ, ["and", ", and", "; and", ", and,"], "A",
"One subject ('The volunteers') with two verbs ('cleaned' and 'planted'). The part after 'and' has no subject, so no comma.",
["Correct: one subject, two verbs, no comma needed.",
 "A comma before 'and' is only needed when an independent clause follows.",
 "A semicolon needs independent clauses on both sides.",
 "Extra commas around 'and'."],
tip="No new subject after 'and'? No comma."),

q("B2-003", "B2", "Introductory element", 1,
"""When the first snow of the season fell ______ the children ran outside to build a snowman.""",
CQ, ["fell;", "fell,", "fell.", "fell:"], "B",
"'When the first snow… fell' is an introductory dependent clause. A comma separates it from the main clause.",
["A semicolon needs two independent clauses.",
 "Correct: comma after an introductory dependent clause.",
 "A period would make 'When… fell' a fragment.",
 "A colon needs an independent clause before it."]),

q("B2-004", "B2", "Conjunctive adverbs", 2,
"""Solar panels can generate electricity only when the sun is shining ______ engineers are developing better batteries to store energy for nighttime use.""",
CQ, ["shining, therefore,", "shining; therefore,", "shining therefore", "shining, therefore"], "B",
"Two independent clauses joined by 'therefore', which is NOT a FANBOYS. Use a semicolon before it and a comma after.",
["Comma splice.",
 "Correct: semicolon + therefore + comma.",
 "Run-on.",
 "Comma splice."]),

q("B2-005", "B2", "Comma + FANBOYS", 2,
"""The painter Frida Kahlo spent long periods recovering from injuries ______ she used those months to develop the self-portraits that made her famous.""",
CQ, ["injuries, yet", "injuries yet,", "injuries; yet,", "injuries, yet,"], "A",
"Two independent clauses joined by 'yet' (a FANBOYS meaning 'but'). Comma before, nothing after.",
["Correct: IC, + yet + IC.",
 "Comma belongs before 'yet', not after.",
 "Semicolon + FANBOYS + comma is incorrect here.",
 "No comma after 'yet'."]),

q("B2-006", "B2", "Compound verb (no comma)", 2,
"""Astronomer Vera Rubin measured how fast stars orbit the centers of galaxies ______ found evidence for the invisible substance now called dark matter.""",
CQ, ["galaxies, and", "galaxies; and", "galaxies and", "galaxies, and,"], "C",
"One subject ('Astronomer Vera Rubin'), two verbs ('measured' and 'found'). No comma before 'and'.",
["A comma would signal a new independent clause, but 'found evidence…' has no subject.",
 "A semicolon needs independent clauses on both sides.",
 "Correct: no punctuation between two verbs sharing one subject.",
 "Extra commas."]),

q("B2-007", "B2", "Introductory element", 3,
"""Having studied the migration patterns of humpback whales for over a decade ______ marine biologist Kalani Akana proposed that the whales use Earth's magnetic field to navigate.""",
CQ, ["decade;", "decade,", "decade.", "decade, and"], "B",
"'Having studied… decade' is an introductory participial phrase describing Akana. A comma separates it from the main clause.",
["Semicolon requires an independent clause before it.",
 "Correct: comma after an introductory phrase.",
 "A period leaves the phrase as a fragment.",
 "'And' makes no sense here; the phrase isn't a clause to be joined."]),

q("B2-008", "B2", "Conjunctive adverbs", 3,
"""Early telescopes produced blurry images because different colors of light bent at different angles ______ Isaac Newton designed a telescope that used a curved mirror instead of a lens.""",
CQ, ["angles; consequently,", "angles, consequently,", "angles consequently", "angles, consequently"], "A",
"Two independent clauses connected by 'consequently', a conjunctive adverb. Use a semicolon before it.",
["Correct: semicolon + consequently + comma.",
 "Comma splice.",
 "Run-on.",
 "Comma splice."]),

q("B2-009", "B2", "Comma + FANBOYS", 3,
"""Most of the ancient library's scrolls were destroyed in a volcanic eruption in 79 CE ______ the heat that carbonized them also preserved hundreds of them, which researchers are now reading with X-ray imaging.""",
CQ, ["CE, but", "CE but", "CE, but,", "CE but,"], "A",
"Independent clause ('Most of the… scrolls were destroyed…') + independent clause ('the heat… also preserved…'). Comma + 'but'.",
["Correct: IC, + but + IC.",
 "Missing the comma before 'but' when joining two independent clauses.",
 "No comma after 'but'.",
 "Comma in the wrong place."]),

q("B2-010", "B2", "Compound verb (no comma)", 3,
"""In her 1962 book *Silent Spring*, Rachel Carson documented the harmful effects of pesticides on birds and other wildlife ______ urged readers to question the widespread use of chemicals.""",
CQ, ["wildlife, and", "wildlife; and", "wildlife and", "wildlife. And"], "C",
"One subject ('Rachel Carson') with two verbs ('documented' and 'urged'). No comma before 'and'.",
["Comma before 'and' wrongly signals a new independent clause.",
 "Semicolon requires two independent clauses.",
 "Correct: compound verb, no punctuation.",
 "A period creates a fragment ('And urged readers…' has no subject)."]),

# -------- B3 SEMICOLONS AND COLONS --------
q("B3-001", "B3", "Semicolon between clauses", 1,
"""The library closes at 6:00 p.m. on weekdays ______ on weekends, it stays open until 9:00 p.m.""",
CQ, ["weekdays,", "weekdays;", "weekdays", "weekdays:"], "B",
"Two independent clauses: 'The library closes…' and 'on weekends, it stays open…'. A semicolon joins them.",
["Comma splice.",
 "Correct: semicolon between independent clauses.",
 "Run-on.",
 "A colon would imply the second part explains the first; it contrasts with it instead."]),

q("B3-002", "B3", "Colon before a list", 1,
"""The recipe calls for only three ingredients ______ flour, water and salt.""",
CQ, ["ingredients;", "ingredients:", "ingredients", "ingredients, such as:"], "B",
"'The recipe calls for only three ingredients' is a complete sentence, and the list explains what they are. A colon is correct.",
["A semicolon needs an independent clause after it; 'flour, water and salt' is a list.",
 "Correct: independent clause + colon + list.",
 "Without punctuation the list runs into the sentence awkwardly.",
 "Never put a colon after 'such as'."]),

q("B3-003", "B3", "Colon misuse", 2,
"""The team's research focused on ______ how sea level rise affects coastal wetlands.""",
CQ, ["one question:", "one question;", "one question", "one question, it was"], "A",
"'The team's research focused on one question' is complete, and what follows specifies the question. Colon.",
["Correct: colon introduces the specific question.",
 "Semicolon needs an independent clause after it.",
 "No punctuation creates a confusing run-together sentence ('one question how…').",
 "Comma splice: 'it was how…' is an independent clause joined with only a comma."]),

q("B3-004", "B3", "Semicolon between clauses", 2,
"""Mount Everest is the highest mountain above sea level ______ Mauna Kea in Hawaii is taller when measured from its base on the ocean floor.""",
CQ, ["level, Mauna Kea", "level; Mauna Kea", "level: Mauna Kea", "level Mauna Kea"], "B",
"Two independent clauses showing contrast. A semicolon joins them.",
["Comma splice.",
 "Correct: semicolon between two independent clauses.",
 "A colon implies the second clause explains the first; it contrasts with it instead.",
 "Run-on."]),

q("B3-005", "B3", "Semicolons in complex lists", 3,
"""The conference included speakers from Nairobi, Kenya ______ Lima, Peru; and Hanoi, Vietnam.""",
CQ, ["Kenya,", "Kenya;", "Kenya:", "Kenya"], "B",
"The list items already contain commas (city, country), so semicolons separate the items. The other items are already separated by semicolons.",
["A comma would make it unclear where items begin and end.",
 "Correct: matches the semicolons used for the other items.",
 "A colon doesn't separate list items.",
 "Missing punctuation runs two items together."]),

q("B3-006", "B3", "Colon for explanation", 3,
"""The discovery surprised the archaeologists ______ the tools, previously thought to be 10,000 years old, turned out to be nearly three times older.""",
CQ, ["archaeologists, the tools", "archaeologists: the tools", "archaeologists the tools", "archaeologists, and, the tools"], "B",
"Two independent clauses, and the second explains *why* the archaeologists were surprised. A colon introduces that explanation.",
["Comma splice.",
 "Correct: colon introduces the explanation.",
 "Run-on.",
 "No comma after 'and'."]),

q("B3-007", "B3", "Semicolon misuse", 3,
"""Chess grandmaster Judit Polgár became the youngest player to earn the grandmaster title in 1991 ______ breaking a record that had been held by Bobby Fischer.""",
CQ, ["1991; breaking", "1991, breaking", "1991. Breaking", "1991 and breaking"], "B",
"'Breaking a record…' is a participial phrase, not an independent clause. It attaches with a comma.",
["A semicolon needs an independent clause after it.",
 "Correct: comma + participial phrase.",
 "Creates a fragment ('Breaking a record… Fischer.').",
 "'And breaking' needs a parallel '-ing' verb before it; 'became' is not parallel to 'breaking'."]),

q("B3-008", "B3", "Colon misuse", 2,
"""The newly discovered species of frog ______ bright orange skin, black spots, and unusually long toes.""",
CQ, ["has:", "has;", "has", "has,"], "C",
"'The newly discovered species of frog has' is not complete without its object. No punctuation goes between a verb and its object.",
["A colon needs a complete independent clause before it, and 'The frog has' is incomplete.",
 "Semicolon requires independent clauses on both sides.",
 "Correct: the verb flows directly into its object.",
 "No comma between a verb and its object."]),

q("B3-009", "B3", "Semicolon between clauses", 1,
"""Owls can rotate their heads up to 270 degrees ______ this ability compensates for eyes that cannot move in their sockets.""",
CQ, ["degrees,", "degrees;", "degrees", "degrees, and,"], "B",
"Two independent clauses. A semicolon joins them.",
["Comma splice.",
 "Correct.",
 "Run-on.",
 "No comma after 'and'."]),

q("B3-010", "B3", "Colon for explanation", 2,
"""After years of failed attempts, the inventor finally understood the problem ______ the battery overheated whenever the device ran for more than an hour.""",
CQ, ["problem,", "problem:", "problem", "problem, and"], "B",
"'The inventor finally understood the problem' is complete, and the next clause explains what the problem was. Colon.",
["Comma splice.",
 "Correct: colon introduces the explanation.",
 "Run-on.",
 "'And' presents the problem as a separate event rather than explaining it."]),

# -------- B4 NONESSENTIAL ELEMENTS --------
q("B4-001", "B4", "Matching commas", 1,
"""Toni Morrison ______ won the Nobel Prize in Literature in 1993.""",
CQ, ["the author of *Beloved*,", ", the author of *Beloved*", ", the author of *Beloved*,", "the author of *Beloved*"], "C",
"'The author of *Beloved*' is extra description of Toni Morrison, so it must be enclosed by commas on both sides.",
["Missing the opening comma.",
 "Missing the closing comma.",
 "Correct: commas on both sides of the nonessential phrase.",
 "Without commas, the phrase runs into the name, which is ungrammatical here."]),

q("B4-002", "B4", "Title before a name (no commas)", 1,
"""In 1983, ______ Sally Ride became the first American woman to travel to space.""",
CQ, ["astronaut,", "astronaut", "astronaut;", "astronaut —"], "B",
"'Astronaut' is a title placed directly before the name with no 'the' or 'a'. Titles like this take no commas.",
["No comma between a title and a name.",
 "Correct: 'astronaut Sally Ride'.",
 "No semicolon between a title and a name.",
 "No dash between a title and a name."],
tip="Title + name, no 'the' = no comma."),

q("B4-003", "B4", "Matching dashes", 2,
"""The Amazon River ______ which carries more water than the next seven largest rivers combined — empties into the Atlantic Ocean.""",
CQ, ["River,", "River —", "River", "River;"], "B",
"The nonessential clause closes with a dash, so it must open with a dash.",
["Mismatched: comma opens, dash closes.",
 "Correct: matching dashes.",
 "The clause needs an opening mark.",
 "A semicolon can't open a nonessential element."]),

q("B4-004", "B4", "Essential vs nonessential", 2,
"""The scientists ______ discovered the new species named it after the village that had helped them.""",
CQ, ["who", ", who", "who,", ", who,"], "A",
"'Who discovered the new species' identifies which scientists. It's essential, so no commas.",
["Correct: essential clause, no commas.",
 "A comma would separate the subject from its essential identifying clause.",
 "No comma after 'who'.",
 "Commas would make the clause nonessential and also split 'who' from its verb."]),

q("B4-005", "B4", "Matching commas", 2,
"""The Hubble Space Telescope, launched in 1990 ______ has captured images of galaxies billions of light-years away.""",
CQ, ["1990 —", "1990,", "1990;", "1990"], "B",
"The phrase 'launched in 1990' opened with a comma, so it must close with a comma.",
["Mismatched: comma opens, dash closes.",
 "Correct: matching commas.",
 "A semicolon separates the subject from its verb.",
 "The closing comma is missing."]),

q("B4-006", "B4", "Name with appositive", 3,
"""The bridge was designed by ______ Emily Warren Roebling, who supervised its construction after her husband fell ill.""",
CQ, ["engineer,", "engineer", "an engineer", "engineer —"], "B",
"'Engineer Emily Warren Roebling' uses 'engineer' as a title directly before the name, so no comma. (The rest of the sentence is already correctly punctuated.)",
["No comma between title and name.",
 "Correct.",
 "'An engineer Emily Warren Roebling' without commas is ungrammatical.",
 "No dash between a title and a name."]),

q("B4-007", "B4", "Matching parentheses", 3,
"""The Treaty of Westphalia (signed in 1648 by the major European powers ______ established principles of state sovereignty that still shape international law.""",
CQ, ["powers)", "powers),", "powers,", "powers"], "A",
"The parenthetical opened with '(' and must close with ')'. Then the subject 'The Treaty of Westphalia' connects directly to its verb 'established', with no comma.",
["Correct: closing parenthesis, no comma before the verb.",
 "The comma after ')' separates the subject from its verb.",
 "Mismatched: parenthesis opened, comma closes.",
 "The parenthesis is never closed."]),

q("B4-008", "B4", "Essential vs nonessential", 3,
"""Lake Baikal ______ holds about one-fifth of all the unfrozen fresh water on Earth's surface.""",
CQ, [", which is located in Siberia", ", which is located in Siberia,", "which is located in Siberia,", "which is located in Siberia"], "B",
"There is only one Lake Baikal, so 'which is located in Siberia' is extra information. It needs commas on both sides.",
["Missing the closing comma.",
 "Correct: commas enclose the nonessential clause.",
 "Missing the opening comma.",
 "A 'which' clause about a unique, named thing needs commas."]),

q("B4-009", "B4", "Matching dashes", 1,
"""The bee ______ the smallest bird in the world — weighs less than a dime.""",
CQ, ["hummingbird —", "hummingbird,", "hummingbird;", "hummingbird"], "A",
"'The smallest bird in the world' is extra information about the bee hummingbird. It closes with a dash, so it must open with a dash.",
["Correct: matching dashes enclose the nonessential phrase.",
 "Mismatched: comma opens, dash closes.",
 "A semicolon can't open a nonessential element and would separate the subject from its verb.",
 "The phrase needs an opening mark to match the closing dash."]),

q("B4-010", "B4", "Name with appositive", 2,
"""The first computer program is often credited to Ada Lovelace ______ who wrote an algorithm for Charles Babbage's proposed Analytical Engine in 1843.""",
CQ, ["Lovelace;", "Lovelace,", "Lovelace", "Lovelace:"], "B",
"'Who wrote…' adds information about a specific named person, making it nonessential. A comma introduces it at the end of the sentence.",
["Semicolon needs an independent clause after it.",
 "Correct: comma before a nonessential 'who' clause.",
 "A nonessential clause about a named person needs a comma.",
 "A colon is not used before a relative clause."]),

# -------- B5 PUNCTUATION TRAPS --------
q("B5-001", "B5", "Subject–verb separation", 1,
"""The students in the robotics club ______ a machine that can sort recycling by material.""",
CQ, ["built", "built,", ", built", "built:"], "A",
"'The students in the robotics club' is the subject; 'built' is the verb; 'a machine…' is the object. No punctuation separates them.",
["Correct.",
 "Comma between verb and object.",
 "Comma between subject and verb.",
 "Colon after a verb that needs an object."]),

q("B5-002", "B5", "No comma before 'that'", 1,
"""Researchers found ______ people who walk for 30 minutes a day sleep better than people who do not.""",
CQ, ["that", "that,", ", that", ": that"], "A",
"'Found that…' is a verb followed by its object clause. No punctuation between them.",
["Correct.",
 "No comma after 'that' when it introduces a clause.",
 "No comma before 'that'.",
 "No colon between a verb and its 'that' clause."]),

q("B5-003", "B5", "After 'such as'", 2,
"""The garden attracts many pollinators, such as ______ butterflies, and hummingbirds.""",
CQ, ["bees,", ": bees,", ", bees,", "bees"], "A",
"No punctuation follows 'such as'. The list then needs commas between items: 'bees, butterflies, and hummingbirds'.",
["Correct: no mark after 'such as', comma after the first list item.",
 "No colon after 'such as'.",
 "No comma after 'such as'.",
 "The list needs a comma after 'bees'."]),

q("B5-004", "B5", "Subject–verb separation", 2,
"""The rapid melting of glaciers in the Himalayan mountain range ______ water supplies for hundreds of millions of people downstream.""",
CQ, ["threatens,", ", threatens", "threatens", "— threatens"], "C",
"The long subject 'The rapid melting… range' connects directly to the verb 'threatens' and its object. No punctuation.",
["Comma between verb and object.",
 "Comma between subject and verb.",
 "Correct.",
 "A single dash separates subject and verb."]),

q("B5-005", "B5", "Integrated quotation", 2,
"""Critics described the young architect's first building as ______ citing its daring curved roof.""",
CQ, ["\"revolutionary,\"", ", \"revolutionary,\"", ": \"revolutionary\"", "\"revolutionary\""], "A",
"The quoted word is blended into the sentence ('described… as \"revolutionary\"'), so no comma before it. A comma after it separates the participial phrase 'citing…'.",
["Correct: no mark before the integrated quote; comma before 'citing'.",
 "No comma between 'as' and its object.",
 "No colon after 'as'.",
 "Missing the comma before the phrase 'citing…'."]),

q("B5-006", "B5", "Lists", 2,
"""The expedition's supplies included ropes, tents ______ six months of dried food.""",
CQ, ["tents, and", "tents and,", "tents; and", "tents, and,"], "A",
"A list of three items: ropes, tents, and six months of dried food. Commas separate the items; nothing follows 'and'.",
["Correct.",
 "Comma in the wrong place.",
 "A semicolon only separates list items that contain internal commas.",
 "Extra comma after 'and'."]),

q("B5-007", "B5", "Preposition–object", 3,
"""Unlike most of the other moons in our solar system, Titan, Saturn's largest moon, has a thick atmosphere composed mostly of ______ a feature that makes its surface difficult to observe.""",
CQ, ["nitrogen,", "nitrogen", ", nitrogen,", "nitrogen;"], "A",
"'Composed mostly of nitrogen' needs no punctuation between preposition and object. Then a comma separates the descriptive phrase 'a feature that…'.",
["Correct: no mark after 'of'; comma before the appositive phrase.",
 "Missing the comma before 'a feature…'.",
 "Comma between 'of' and its object.",
 "Semicolon needs an independent clause after it."]),

q("B5-008", "B5", "Subject–verb separation", 3,
"""What the team of historians uncovered in the archive's previously unopened boxes ______ that the factory had employed hundreds more workers than official records showed.""",
CQ, ["was evidence,", "was, evidence", "was evidence", ", was evidence"], "C",
"The subject is a whole clause: 'What the team… uncovered in… boxes'. Its verb is 'was', its complement is 'evidence', and 'that…' describes the evidence. No punctuation anywhere.",
["Comma before 'that'.",
 "Comma between verb and complement.",
 "Correct.",
 "Comma between subject and verb."]),

q("B5-009", "B5", "After 'including'", 3,
"""The festival celebrated the region's many musical traditions, including ______ and son jarocho.""",
CQ, ["mariachi, cumbia,", ": mariachi, cumbia", "mariachi cumbia,", ", mariachi, cumbia,"], "A",
"No punctuation after 'including'. The list of three items needs commas between items: 'mariachi, cumbia, and son jarocho'.",
["Correct: no mark after 'including'; commas between list items.",
 "No colon after 'including'.",
 "Missing the comma between 'mariachi' and 'cumbia', which runs two list items together.",
 "No comma after 'including'."]),

q("B5-010", "B5", "Verb–object separation", 1,
"""The museum's new guidebook explains ______ how the ancient pottery was made.""",
CQ, ["in detail", "in detail,", ", in detail", "in detail:"], "A",
"'Explains in detail how…' keeps the verb and its object clause connected; 'in detail' is a short phrase that needs no commas here.",
["Correct.",
 "Comma separates the verb phrase from its object.",
 "A single comma before 'in detail' separates the verb from its modifier awkwardly and leaves it unpaired.",
 "A colon after a phrase that isn't a complete sentence."]),
]
