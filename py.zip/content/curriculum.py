"""Course structure: official Digital SAT Reading & Writing domains, the
11 skill modules, and the lesson units inside them.

SEQUENCE is the order Daily Practice introduces units. It interleaves
reading and grammar so that every week touches several domains, and it
puts the highest-yield, most rule-based skills early.
"""

DOMAINS = [
    {"id": "II", "title": "Information and Ideas",
     "blurb": "Understand what texts and data say, and what they support."},
    {"id": "CS", "title": "Craft and Structure",
     "blurb": "How authors use words, build texts and talk to each other."},
    {"id": "EI", "title": "Expression of Ideas",
     "blurb": "Revise writing so it says what the writer intends."},
    {"id": "SEC", "title": "Standard English Conventions",
     "blurb": "Sentence structure, punctuation and grammar rules."},
]

MODULES = [
    {"id": "CID", "domain": "II", "title": "Central Ideas and Details", "units": ["CID"]},
    {"id": "COET", "domain": "II", "title": "Command of Evidence: Textual", "units": ["COET"]},
    {"id": "COEQ", "domain": "II", "title": "Command of Evidence: Quantitative", "units": ["COEQ"]},
    {"id": "INF", "domain": "II", "title": "Inferences", "units": ["INF"]},
    {"id": "WIC", "domain": "CS", "title": "Words in Context", "units": ["WIC"]},
    {"id": "TSP", "domain": "CS", "title": "Text Structure and Purpose", "units": ["TSP"]},
    {"id": "CTC", "domain": "CS", "title": "Cross-Text Connections", "units": ["CTC"]},
    {"id": "RS", "domain": "EI", "title": "Rhetorical Synthesis", "units": ["RS"]},
    {"id": "TRN", "domain": "EI", "title": "Transitions", "units": ["TRN"]},
    {"id": "BND", "domain": "SEC", "title": "Boundaries",
     "units": ["B1", "B2", "B3", "B4", "B5"]},
    {"id": "FSS", "domain": "SEC", "title": "Form, Structure and Sense",
     "units": ["F1", "F2", "F3", "F4", "F5", "F6"]},
]

SEQUENCE = [
    "TRN", "B1", "WIC", "F1", "CID", "B2", "RS", "F3", "COET", "B3",
    "INF", "F2", "TSP", "B4", "COEQ", "F5", "CTC", "F4", "B5", "F6",
]

# Spaced revision gaps (days) for units that have reached Mastered.
MASTERY_REVIEW_DAYS = [7, 14, 30, 60]

# Spaced repetition gaps (days) for Mistake Journal reviews.
MISTAKE_INTERVALS = [1, 3, 7, 14, 30, 60]

MISTAKE_CATEGORIES = [
    {"id": "knowledge", "label": "Knowledge gap",
     "desc": "I didn't understand the rule or concept."},
    {"id": "comprehension", "label": "Comprehension gap",
     "desc": "I misunderstood the passage."},
    {"id": "reasoning", "label": "Reasoning error",
     "desc": "I understood the passage but chose an unsupported answer."},
    {"id": "execution", "label": "Execution error",
     "desc": "I rushed, misread or made a careless slip."},
    {"id": "vocabulary", "label": "Vocabulary gap",
     "desc": "I didn't know an important word."},
]

OFFICIAL_LINKS = [
    {"title": "SAT Suite Question Bank (official, free)",
     "url": "https://satsuitequestionbank.collegeboard.org/"},
    {"title": "Bluebook full-length practice tests (official)",
     "url": "https://bluebook.collegeboard.org/students/download-bluebook"},
    {"title": "Khan Academy Digital SAT prep (official partner)",
     "url": "https://www.khanacademy.org/digital-sat"},
]
