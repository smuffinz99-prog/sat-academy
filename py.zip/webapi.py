"""The app's server logic, run inside the browser by Pyodide (the website version).

web.js calls handle() for each /api/... request the page makes. The same
Handler.api() code as the Mac/Windows server answers it, just without HTTP.
The Gemini key never comes here: web.js keeps it in the browser and calls
Google itself, using tutor_prepare() and tutor_save() for the conversation.
"""
import json
import os
import re
from urllib.parse import parse_qs, urlparse

os.environ.setdefault("SAT_DATA_DIR", "/data")
os.environ["SAT_WEB"] = "1"
os.environ["SAT_CONFIG"] = "/data/no-config.json"
for k in ("GEMINI_API_KEY", "ANTHROPIC_API_KEY"):
    os.environ.pop(k, None)

import server  # noqa: E402
from server import ENGINE, TUTOR_SYSTEM, build_tutor_context  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
try:
    with open(os.path.join(HERE, "media.json"), encoding="utf-8") as f:
        MEDIA = json.load(f)
except OSError:
    MEDIA = {}


def web_video_info(unit):
    m = MEDIA.get(unit)
    if not m:
        return None
    v = "?v=" + m["v"]      # a re-rendered video gets a new URL, so the browser doesn't show a stale copy
    return {"src": "videos/%s.mp4%s" % (unit, v), "poster": "videos/%s.poster.jpg%s" % (unit, v),
            "captions": "videos/%s.vtt%s" % (unit, v), "transcript": m.get("transcript", ""),
            "chapters": m.get("chapters", [])}


server.video_info = web_video_info


class WebHandler(server.Handler):
    """Handler.api() with the HTTP parts swapped out: it keeps the reply instead of sending it."""

    def __init__(self, body):
        self._body = body
        self.result, self.status = None, 200

    def send_json(self, obj, status=200):
        self.result, self.status = obj, status

    def read_json(self):
        return self._body if isinstance(self._body, dict) else {}


def handle(method, url, body, today):
    """One API call. Returns JSON text: {"status": 200, "body": ...}."""
    u = urlparse(url)
    h = WebHandler(json.loads(body) if body else {})
    try:
        with ENGINE.lock:
            h.api(method, u.path.strip("/"), parse_qs(u.query), today)
            ENGINE.db.commit()
    except KeyError as e:
        h.result, h.status = {"error": "not found: %s" % e}, 404
    except ValueError as e:
        h.result, h.status = {"error": str(e)}, 400
    if h.result is None:
        h.result, h.status = {"error": "not found"}, 404
    return json.dumps({"status": h.status, "body": h.result})


def export_backup():
    with ENGINE.lock:
        return json.dumps(ENGINE.export_all(), indent=1)


def _thread(t):
    return re.sub(r"[^\w-]", "", str(t or "main"))[:64] or "main"


def tutor_prepare(thread, message, image, ctx_json, today, instructions):
    """The Gemini request body (as JSON text) for one tutor message: rules, context and the chat so far."""
    ctx = json.loads(ctx_json or "{}")
    with ENGINE.lock:
        history = ENGINE.tutor_history(_thread(thread), limit=24)
        context_text = build_tutor_context(ctx, today)
    contents = []
    for h in history:
        role = "model" if h["role"] == "assistant" else "user"
        if contents and contents[-1]["role"] == role:
            contents[-1]["parts"][0]["text"] += "\n\n" + h["content"]
        else:
            contents.append({"role": role, "parts": [{"text": h["content"]}]})
    parts = []
    m = re.match(r"^data:(image/(?:png|jpeg|gif|webp));base64,(.+)$", image or "", re.S)
    if m:
        parts.append({"inlineData": {"mimeType": m.group(1), "data": m.group(2)}})
    parts.append({"text": message or "Please look at this screenshot and help me with it."})
    if contents and contents[-1]["role"] == "user":
        contents[-1]["parts"] += parts
    else:
        contents.append({"role": "user", "parts": parts})
    if contents[0]["role"] != "user":
        contents = contents[1:]
    system = TUTOR_SYSTEM
    if instructions:
        system += ("\n\nThe student added their own instructions for you. Follow them unless they conflict "
                   "with the rules above:\n" + str(instructions)[:4000])
    system += "\n\n" + context_text
    return json.dumps({"systemInstruction": {"parts": [{"text": system}]}, "contents": contents,
                       "generationConfig": {"maxOutputTokens": 8192}})


def tutor_save(thread, message, had_image, reply):
    t = _thread(thread)
    ENGINE.tutor_add(t, "user", (message or "") + (" [screenshot attached]" if had_image else ""))
    ENGINE.tutor_add(t, "assistant", reply)
