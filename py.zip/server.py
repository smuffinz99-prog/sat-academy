#!/usr/bin/env python3
"""SAT Reading & Writing Academy: local web server.

Run:  python3 server.py        then open http://localhost:8765 in Safari.
Uses only the Python standard library. Data lives in ./data/study.db.
"""
import datetime as dt
import json
import mimetypes
import os
import re
import sys
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

from content import CONTENT  # noqa: E402
from content.curriculum import MISTAKE_CATEGORIES, OFFICIAL_LINKS  # noqa: E402
from content.notes import NOTES  # noqa: E402
from content.short import SHORT  # noqa: E402
from engine import Engine, LESSONS, Q, full_question, public_question  # noqa: E402

STATIC = os.path.join(ROOT, "static")
DATA_DIR = os.environ.get("SAT_DATA_DIR", os.path.join(ROOT, "data"))
PORT = int(os.environ.get("SAT_PORT", "8765"))
HOST = os.environ.get("SAT_HOST", "127.0.0.1")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

ENGINE = Engine(DATA_DIR)


# ---------------------------------------------------------------- AI tutor
CONFIG_PATH = os.environ.get("SAT_CONFIG", os.path.join(ROOT, "config.json"))
MODELS = {
    "gemini": [{"id": "gemini-3.8-flash", "label": "Gemini 3.8 Flash (free tier, recommended)"},
               {"id": "gemini-3.5-flash-lite", "label": "Gemini 3.5 Flash-Lite (fastest, free tier)"}],
    "anthropic": [{"id": "claude-sonnet-5-5", "label": "Claude Sonnet 5.5"},
                  {"id": "claude-haiku-5-5", "label": "Claude Haiku 5.5 (faster, cheaper)"},
                  {"id": "claude-opus-5-5", "label": "Claude Opus 5.5 (most capable)"}],
}
PLACEHOLDER_KEYS = {"PASTE-YOUR-KEY-HERE", ""}
# Used only if the chosen Gemini model returns "not found" (e.g. retired): Google keeps these aliases current.
GEMINI_FALLBACK = ["gemini-flash-latest", "gemini-flash-lite-latest"]


def read_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def write_config(cfg):
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, CONFIG_PATH)


def tutor_config():
    cfg = read_config()
    gem = (os.environ.get("GEMINI_API_KEY") or cfg.get("gemini_api_key") or "").strip()
    ant = (os.environ.get("ANTHROPIC_API_KEY") or cfg.get("anthropic_api_key") or "").strip()
    gem = "" if gem in PLACEHOLDER_KEYS else gem
    ant = "" if ant in PLACEHOLDER_KEYS else ant
    provider = cfg.get("provider") or ("anthropic" if ant and not gem else "gemini")
    if provider == "gemini":
        key, model = gem, cfg.get("gemini_model") or MODELS["gemini"][0]["id"]
    else:
        key = ant
        model = os.environ.get("SAT_TUTOR_MODEL") or cfg.get("anthropic_model") or cfg.get("model") or MODELS["anthropic"][0]["id"]
    return {"provider": provider, "key": key, "model": model,
            "instructions": (cfg.get("tutor_instructions") or "").strip()[:4000]}


def tutor_settings_view():
    t = tutor_config()
    return {"provider": t["provider"], "model": t["model"], "hasKey": bool(t["key"]),
            "keyHint": ("…" + t["key"][-4:]) if t["key"] else "", "instructions": t["instructions"],
            "models": MODELS}


def save_tutor_settings(body):
    cfg = read_config()
    provider = body.get("provider") if body.get("provider") in MODELS else "gemini"
    cfg["provider"] = provider
    key = (body.get("apiKey") or "").strip()
    if key:
        cfg["gemini_api_key" if provider == "gemini" else "anthropic_api_key"] = key
    if body.get("clearKey"):
        cfg.pop("gemini_api_key" if provider == "gemini" else "anthropic_api_key", None)
    model = body.get("model")
    if model in [m["id"] for m in MODELS[provider]]:
        cfg["gemini_model" if provider == "gemini" else "anthropic_model"] = model
    if "instructions" in body:
        cfg["tutor_instructions"] = str(body.get("instructions") or "")[:4000]
    write_config(cfg)
    return tutor_settings_view()


TUTOR_SYSTEM = """You are a Digital SAT Reading and Writing tutor for one student who is aiming for an 800. Your job is to make them faster and more accurate at each question type by drilling the right APPROACH for that type, not just handing over answers.

HOW TO ANSWER
- Short by default: about 40-90 words. Answer the exact thing they asked in your first sentence. No greetings, no "great question", no restating the question, no closing summary.
- Method first. Every explanation runs through the course method for this question type (the numbered steps and mantra below), in the course's own words so it matches the student's notes. Say which step does the work, e.g. "Step 3, name the relationship: ...".
- Be concrete. Quote the few passage words that decide it, in quotation marks, and say what they signal.
- Plain language. Define any grammar term in a few words the first time you use it.
- Format for a quick read: short lines, **bold** only for the key idea, numbered steps only when walking through the method. No headings or tables unless asked.

FOLLOW-UPS (you can see the whole conversation; build on it, never restart)
- "Go deeper" / "explain more": up to about 200 words. Walk the method step by step on this exact question, then one line on the trap it sets.
- "Explain it differently" / "I don't get it": a genuinely NEW angle in under 120 words: an everyday analogy, a tiny made-up example, or a side-by-side with the tempting wrong choice. Don't reword your last answer.
- "Another hint": each hint goes one step further than the last without giving the answer away: first the type and the step to use, then the exact words that matter, then what the right choice has to do.
- "Why is my answer wrong?": name the exact flaw in their choice (wrong logic, too broad, wrong verb form...) in one or two sentences, then the rule that catches it next time.
- "Which step am I on?": say which step of the method they should do next and how to do it here.
- If they still seem confused, end with one short check question. Otherwise don't ask questions.

SPOILER RULES
- If the student has NOT found the right answer yet, never reveal it, never say which choice is right, and never eliminate the last wrong choices for them. Give the next step of the method, or point to the passage words that matter. If they have tried some choices, you may explain why THOSE choices fail, without hinting which remaining one is right. If they explicitly insist on the answer, tell them once that finding it is what builds the skill and give the strongest hint instead.
- Once they have found the right answer (or the context says the question is solved), discuss everything freely, including why each wrong choice is wrong.

PRACTICE QUESTIONS
- When asked for a similar question, write ONE original Digital-SAT-style question on the same skill: a short passage, one question, choices A-D, nothing else. Don't give the answer until they reply; then mark it with the method in a few lines.

SCREENSHOTS
- Identify the question type first, then teach that type's method. Follow the spoiler rules unless they say they've already answered.

OFF TOPIC
- For anything unrelated to SAT Reading and Writing, answer in a sentence or two and steer back."""


def build_tutor_context(ctx, today):
    parts = []
    prof = ENGINE.learner_profile(today)
    parts.append("STUDENT PROFILE\nTopic levels: " + "; ".join(prof["levels"]) +
                 "\nMistake categories logged so far: " + prof["mistakeCategories"])
    unit = (ctx or {}).get("unit")
    qid = (ctx or {}).get("questionId")
    if qid in Q and not unit:
        unit = Q[qid]["unit"]
    if unit in LESSONS:
        les, sh = LESSONS[unit], SHORT[unit]
        n = NOTES.get(unit, {})
        rules = "; ".join(r["name"] + (": " + r["text"] if r.get("text") else "") for r in sh["rules"])
        parts.append(
            "QUESTION TYPE THE STUDENT IS STUDYING: %s (%s; domain: %s)\n"
            "Course method (use these words):\n%s\nMantra: %s\nHow to spot it: %s\nKey rules: %s\nTraps: %s" % (
                les["title"], les["moduleTitle"], les["domainTitle"],
                "\n".join("%d. %s: %s" % (i + 1, a[0], a[1]) for i, a in enumerate(sh["attack"])),
                sh["mantra"], n.get("spot", ""), rules,
                "; ".join("%s (%s)" % (t[0], t[1]) for t in sh["traps"])))
    if ctx and ctx.get("where"):
        parts.append("WHERE THE STUDENT IS: " + str(ctx["where"])[:200])
    ex_id = (ctx or {}).get("exampleId")
    ex = next((e for es in CONTENT["worked"].values() for e in es if e["id"] == ex_id), None) if ex_id else None
    if ex:
        parts.append(
            "WORKED EXAMPLE ON SCREEN (a demonstration, so you may discuss the answer freely)\n"
            "Passage:\n%s\n%sQuestion: %s\nChoices:\n%s\nAnswer: %s\nSteps shown to the student:\n%s\nWhy each choice:\n%s" % (
                ex["passage"], ("Data: %s\n" % json.dumps(ex["data"])) if ex.get("data") else "", ex["question"],
                "\n".join("%s) %s" % ("ABCD"[i], c) for i, c in enumerate(ex["choices"])), ex["answer"],
                "\n".join("- " + st for st in ex["steps"]),
                "\n".join("%s) %s" % ("ABCD"[i], w) for i, w in enumerate(ex["why"]))))
    if qid in Q:
        q = Q[qid]
        les = LESSONS[q["unit"]]
        choices = "\n".join("%s) %s" % ("ABCD"[i], c) for i, c in enumerate(q["choices"]))
        block = "CURRENT QUESTION (%s; skill: %s; difficulty %d/3)\nPassage:\n%s\n" % (
            les["moduleTitle"], q["skill"], q["difficulty"], q["passage"])
        if q["data"]:
            block += "Data: %s\n" % json.dumps(q["data"])
        block += "Question: %s\nChoices:\n%s\n" % (q["question"], choices)
        tries = [t for t in (ctx.get("tries") or []) if t in ("A", "B", "C", "D")]
        sel = ctx.get("selected")
        solved = bool(ctx.get("solved") or (ctx.get("submitted") and not tries and sel == q["answer"]) or
                      (ctx.get("submitted") and ctx.get("solved") is None))
        if solved:
            block += ("STATUS: SOLVED. %s The correct answer is %s.\nCourse explanation: %s\nWhy each choice is right/wrong:\n%s" % (
                ("They tried %s before finding it." % ", ".join(tries)) if tries else "They got it on the first try." if sel == q["answer"] else
                ("Their pick was %s." % sel if sel else ""),
                q["answer"], q["explanation"],
                "\n".join("%s) %s" % ("ABCD"[i], w) for i, w in enumerate(q["why"]))))
        else:
            block += "STATUS: NOT SOLVED YET. Do not reveal the answer."
            if tries:
                block += (" They have already tried %s (wrong). You may explain why those fail:\n%s" % (
                    ", ".join(tries), "\n".join("%s) %s" % (t, q["why"]["ABCD".index(t)]) for t in tries)))
            if sel and sel not in tries:
                block += " They are currently leaning toward %s." % sel
            block += "\n(For your reference only, so hints are accurate: the answer is %s. Never state or imply it.)" % q["answer"]
        parts.append(block)
    return "\n\n".join(parts)


def call_tutor(thread_id, message, image, ctx, today):
    cfg = tutor_config()
    if not cfg["key"]:
        return {"ok": False, "error": "not_configured"}
    with ENGINE.lock:
        history = ENGINE.tutor_history(thread_id, limit=24)
        context_text = build_tutor_context(ctx, today)
    messages = []
    for h in history:
        role = "assistant" if h["role"] == "assistant" else "user"
        if messages and messages[-1]["role"] == role:
            messages[-1]["content"][0]["text"] += "\n\n" + h["content"]
        else:
            messages.append({"role": role, "content": [{"type": "text", "text": h["content"]}]})
    content = []
    if image:
        m = re.match(r"^data:(image/(?:png|jpeg|gif|webp));base64,(.+)$", image, re.S)
        if m:
            content.append({"type": "image", "source": {"type": "base64", "media_type": m.group(1), "data": m.group(2)}})
    content.append({"type": "text", "text": message or "Please look at this screenshot and help me with it."})
    if messages and messages[-1]["role"] == "user":
        messages[-1]["content"] += content
    else:
        messages.append({"role": "user", "content": content})
    if messages[0]["role"] != "user":
        messages = messages[1:]

    system = TUTOR_SYSTEM
    if cfg["instructions"]:
        system += ("\n\nThe student added their own instructions for you. Follow them unless they conflict "
                   "with the rules above:\n" + cfg["instructions"])
    system += "\n\n" + context_text
    res = model_call(cfg, system, messages)
    if not res["ok"]:
        return res
    ENGINE.tutor_add(thread_id, "user", (message or "") + (" [screenshot attached]" if image else ""))
    ENGINE.tutor_add(thread_id, "assistant", res["reply"])
    return res


def friendly_error(provider, code, detail):
    d = detail.lower()
    if code in (401, 403) or "api_key_invalid" in d or "api key not valid" in d or "invalid x-api-key" in d:
        return "That API key was rejected. Check it in Tutor setup (no spaces, the whole key)."
    if "unrestricted" in d or "restrict" in d:
        return "Google needs this key restricted to the Gemini API. In Google AI Studio, open the key's settings and restrict it, then try again."
    if code == 429 or "resource_exhausted" in d or "quota" in d:
        return "You've hit the tutor's rate limit. Wait a minute and try again."
    if code == 404 or "not found" in d:
        return "That model isn't available for your key. Pick another model in Tutor setup."
    return "The AI service returned an error (HTTP %s)." % code


def model_call(cfg, system, messages):
    """Send a conversation to the configured provider. messages use the
    Anthropic shape: [{role: user|assistant, content: [{type: text|image}]}]."""
    try:
        if cfg["provider"] == "gemini":
            contents = []
            for m in messages:
                parts = []
                for c in m["content"]:
                    if c["type"] == "text":
                        parts.append({"text": c["text"]})
                    elif c["type"] == "image":
                        parts.append({"inlineData": {"mimeType": c["source"]["media_type"], "data": c["source"]["data"]}})
                contents.append({"role": "model" if m["role"] == "assistant" else "user", "parts": parts})
            base = os.environ.get("SAT_GEMINI_API_URL", "https://generativelanguage.googleapis.com/v1beta")
            body = {"systemInstruction": {"parts": [{"text": system}]}, "contents": contents,
                    "generationConfig": {"maxOutputTokens": 8192}}   # Gemini 3.x ignores temperature (and will reject it)
            data = None
            for model in [cfg["model"]] + [m for m in GEMINI_FALLBACK if m != cfg["model"]]:
                req = urllib.request.Request("%s/models/%s:generateContent" % (base, model), data=json.dumps(body).encode(),
                                             method="POST", headers={"content-type": "application/json", "x-goog-api-key": cfg["key"]})
                try:
                    with urllib.request.urlopen(req, timeout=120) as r:
                        data = json.loads(r.read())
                    break
                except urllib.error.HTTPError as e:
                    if e.code != 404 or model == GEMINI_FALLBACK[-1]:
                        raise
                    # That model is retired or not offered to this key: try Google's rolling alias next.
            cands = data.get("candidates") or []
            if not cands:
                reason = (data.get("promptFeedback") or {}).get("blockReason", "no answer")
                return {"ok": False, "error": "api_error", "detail": "The tutor couldn't answer that (%s). Try rephrasing." % reason}
            parts = (cands[0].get("content") or {}).get("parts") or []
            text = "".join(p.get("text", "") for p in parts if not p.get("thought")).strip()
            if not text:
                return {"ok": False, "error": "api_error", "detail": "The tutor returned an empty answer (%s). Try again." %
                        cands[0].get("finishReason", "unknown")}
            return {"ok": True, "reply": text}
        body = json.dumps({"model": cfg["model"], "max_tokens": 1200, "system": system, "messages": messages}).encode()
        api_url = os.environ.get("SAT_TUTOR_API_URL", "https://api.anthropic.com/v1/messages")
        req = urllib.request.Request(api_url, data=body, method="POST", headers={
            "content-type": "application/json", "x-api-key": cfg["key"], "anthropic-version": "2023-06-01"})
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read())
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text").strip()
        return {"ok": True, "reply": text}
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:600]
        return {"ok": False, "error": "api_error", "detail": friendly_error(cfg["provider"], e.code, detail)}
    except Exception as e:  # network down, DNS, timeout
        return {"ok": False, "error": "network", "detail": "Couldn't reach the AI service. Check your internet connection. (%s)" % str(e)[:120]}


def test_tutor():
    cfg = tutor_config()
    if not cfg["key"]:
        return {"ok": False, "error": "not_configured", "detail": "Add an API key first."}
    return model_call(cfg, "You are a helpful assistant.",
                      [{"role": "user", "content": [{"type": "text", "text": "Reply with exactly these words: Tutor connected."}]}])


def video_info(unit):
    base = os.path.join(STATIC, "videos", unit)
    if not os.path.exists(base + ".mp4"):
        return None
    v = "?v=%d" % int(os.path.getmtime(base + ".mp4"))   # a new video gets a new URL, so no stale cache
    return {"src": "/videos/%s.mp4%s" % (unit, v),
            "poster": "/videos/%s.poster.jpg%s" % (unit, v) if os.path.exists(base + ".poster.jpg") else None,
            "captions": "/videos/%s.vtt%s" % (unit, v) if os.path.exists(base + ".vtt") else None,
            "transcript": open(base + ".vtt", encoding="utf-8").read() if os.path.exists(base + ".vtt") else "",
            "chapters": read_json(base + ".chapters.json", [])}


def read_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


# ---------------------------------------------------------------- HTTP
class Handler(BaseHTTPRequestHandler):
    server_version = "SATAcademy/1.0"

    def log_message(self, fmt, *args):
        if os.environ.get("SAT_QUIET"):
            return
        sys.stderr.write("%s %s\n" % (dt.datetime.now().strftime("%H:%M:%S"), fmt % args))

    def today(self):
        d = self.headers.get("X-Local-Date", "")
        if DATE_RE.match(d):
            try:
                dt.date.fromisoformat(d)
                return d
            except ValueError:
                pass
        return dt.date.today().isoformat()

    def send_json(self, obj, status=200):
        body = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 25 * 1024 * 1024:
            raise ValueError("Request too large")
        raw = self.rfile.read(n) if n else b"{}"
        return json.loads(raw or b"{}")

    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def do_DELETE(self):
        self.route("DELETE")

    def do_HEAD(self):
        url = urlparse(self.path)
        if url.path.startswith("/api/"):
            return self.send_json({}, 405)
        self.static(url.path)

    def route(self, method):
        url = urlparse(self.path)
        path, qs = url.path, parse_qs(url.query)
        try:
            if path.startswith("/api/"):
                today = self.today()
                ENGINE.daily_backup(today)
                if path in ("/api/tutor/ask", "/api/tutor/test"):   # slow network calls: don't hold the DB lock
                    return self.api(method, path[5:], qs, today)
                with ENGINE.lock:
                    return self.api(method, path[5:], qs, today)
            if method != "GET":
                return self.send_json({"error": "not found"}, 404)
            return self.static(path)
        except KeyError as e:
            return self.send_json({"error": "not found: %s" % e}, 404)
        except ValueError as e:
            return self.send_json({"error": str(e)}, 400)
        except (BrokenPipeError, ConnectionResetError):
            return   # the browser went away (normal when a video is skipped or a page closed)
        except Exception as e:  # keep the server alive whatever happens
            import traceback
            traceback.print_exc()
            try:
                return self.send_json({"error": "server error: %s" % e}, 500)
            except (BrokenPipeError, ConnectionResetError):
                return

    def static(self, path):
        if path in ("", "/"):
            path = "/index.html"
        full = os.path.normpath(os.path.join(STATIC, path.lstrip("/")))
        if not full.startswith(STATIC + os.sep) or not os.path.isfile(full):
            if path.startswith(("/videos/", "/fonts/")):
                return self.send_json({"error": "not found"}, 404)
            full = os.path.join(STATIC, "index.html")
        ext = os.path.splitext(full)[1].lower()
        ctype = {".vtt": "text/vtt", ".ttf": "font/ttf", ".mp4": "video/mp4", ".js": "application/javascript",
                 ".css": "text/css", ".html": "text/html", ".jpg": "image/jpeg"}.get(ext) or \
            mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype == "application/javascript":
            ctype += "; charset=utf-8"
        size = os.path.getsize(full)
        start, end = 0, size - 1
        rng = self.headers.get("Range")
        m = re.match(r"bytes=(\d*)-(\d*)$", rng or "")
        partial = bool(m) and (m.group(1) or m.group(2))
        if partial:
            if m.group(1):
                start = int(m.group(1))
                end = min(int(m.group(2)), size - 1) if m.group(2) else size - 1
            else:
                start = max(0, size - int(m.group(2)))
            if start > end or start >= size:
                self.send_response(416)
                self.send_header("Content-Range", "bytes */%d" % size)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
        length = end - start + 1
        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Cache-Control", "no-cache" if ext in (".html", ".js", ".css") else "max-age=3600")
        if partial:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.send_header("Content-Length", str(length))
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(full, "rb") as f:
            f.seek(start)
            left = length
            while left > 0:
                chunk = f.read(min(1 << 16, left))
                if not chunk:
                    break
                try:
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    return   # the browser cancelled (normal when seeking video)
                left -= len(chunk)

    def api(self, method, path, qs, today):
        E = ENGINE
        parts = path.strip("/").split("/")
        p0 = parts[0]

        if method == "GET" and p0 == "home":
            st = E.today_status(today)
            E.db.commit()
            return self.send_json({"today": today, "status": st, "upcoming": E.upcoming_reviews(today),
                                   "tutor": bool(tutor_config()["key"]), "minutes": E.default_minutes()})

        if method == "GET" and p0 == "notes":
            taught = set(E.introduced_units())
            return self.send_json({"units": [{"unit": u, "taught": u in taught} for u in CONTENT["sequence"]]})

        if method == "GET" and p0 == "plan":
            minutes = int(qs.get("minutes", [E.default_minutes()])[0])
            return self.send_json({"minutes": minutes, "days": E.forecast(today, minutes, 7),
                                   "course": E.course_outlook(today)})

        if method == "POST" and p0 == "settings" and parts[1:] == ["minutes"]:
            E.set_default_minutes(self.read_json().get("minutes", 30))
            return self.send_json({"minutes": E.default_minutes()})

        if method == "GET" and p0 == "config":
            return self.send_json({"categories": MISTAKE_CATEGORIES, "links": OFFICIAL_LINKS,
                                   "tutorConfigured": bool(tutor_config()["key"]),
                                   "short": {u: {"tagline": v["tagline"], "mantra": v["mantra"]} for u, v in SHORT.items()},
                                   "notes": {u: dict(n, mantra=SHORT[u]["mantra"]) for u, n in NOTES.items()},
                                   "units": {u: {"title": l["title"], "moduleTitle": l["moduleTitle"], "domain": l["domain"],
                                                 "domainTitle": l["domainTitle"]}
                                             for u, l in LESSONS.items()},
                                   "sequence": CONTENT["sequence"], "modules": CONTENT["modules"],
                                   "domains": CONTENT["domains"]})

        if p0 == "session":
            if method == "POST" and parts[1:] == ["start"]:
                body = self.read_json()
                minutes = body.get("minutes") or E.default_minutes()
                E.set_default_minutes(minutes)
                sid = E.start_ahead(today, minutes) if body.get("ahead") else E.start_today(today, minutes)
                if not sid:
                    return self.send_json({"error": "Nothing to start"}, 409)
                return self.send_json(E.session_view(sid))
            sid = int(parts[1])
            if method == "GET":
                v = E.session_view(sid)
                return self.send_json(v) if v else self.send_json({"error": "no session"}, 404)
            body = self.read_json()
            if parts[2:] == ["advance"]:
                return self.send_json(E.advance(sid, body.get("stage", 0), body.get("index", 0)))
            if parts[2:] == ["complete"]:
                return self.send_json(E.complete_session(sid, today))

        if method == "GET" and p0 == "questions":
            ids = [i for i in (qs.get("ids", [""])[0]).split(",") if i]
            return self.send_json([public_question(i) for i in ids if i in Q])

        if method == "GET" and p0 == "worked":
            unit = parts[1]
            return self.send_json(CONTENT["worked"].get(unit, []))

        if method == "POST" and p0 == "answer":
            b = self.read_json()
            res = E.record_answer(b["questionId"], b.get("selected"), b.get("context", "practice"), today,
                                  session_id=b.get("sessionId"), assisted=b.get("assisted", False))
            return self.send_json(res)

        if method == "POST" and p0 == "retry":
            b = self.read_json()
            return self.send_json(E.record_retry(b["questionId"], b.get("selected"), session_id=b.get("sessionId"),
                                                 first=b.get("first"), tries=b.get("tries")))

        if method == "GET" and p0 == "reveal":
            # Full explanation for a question the student already answered earlier (journal, resume).
            d = full_question(parts[1])
            d["inJournal"] = bool(E.one("SELECT 1 FROM mistakes WHERE question_id=?", (parts[1],)))
            return self.send_json(d)

        if p0 == "mistakes":
            if method == "GET" and len(parts) == 1:
                unit = qs.get("unit", [None])[0] or None
                status = qs.get("status", ["all"])[0]
                return self.send_json({"mistakes": E.list_mistakes(today, unit, status),
                                       "due": len(E.due_mistakes(today)), "upcoming": E.upcoming_reviews(today, 14)})
            if method == "POST" and parts[1] in ("flag", "add"):
                b = self.read_json()
                return self.send_json({"ok": True, "mistake": E.add_mistake(b["questionId"], b.get("selected"), today)})
            if method == "POST" and parts[1] == "add-many":
                for it in self.read_json().get("items", []):
                    if it.get("questionId") in Q:
                        E.add_mistake(it["questionId"], it.get("selected"), today)
                return self.send_json({"ok": True})
            if method == "POST" and len(parts) == 3 and parts[2] == "category":
                E.set_category(parts[1], self.read_json().get("category"))
                return self.send_json({"ok": True})
            if method == "DELETE" and len(parts) == 2:
                E.remove_mistake(parts[1])
                return self.send_json({"ok": True})

        if p0 == "masterclass":
            if method == "GET" and len(parts) == 1:
                return self.send_json(E.masterclass(today))
            unit = parts[1]
            if unit not in LESSONS:
                raise KeyError(unit)
            if method == "GET" and len(parts) == 2:
                d = E.unit_detail(unit, today)
                d["video"] = video_info(unit)
                return self.send_json(d)
            if method == "GET" and parts[2] == "set":
                return self.send_json({"questions": E.masterclass_set(unit, qs.get("kind", ["guided"])[0])})
            if method == "POST" and parts[2] == "section":
                return self.send_json(E.mark_section(unit, self.read_json().get("section"), today))

        if method == "GET" and p0 == "drill":
            unit = qs.get("unit", ["mixed"])[0]
            n = min(int(qs.get("n", ["10"])[0]), 30)
            return self.send_json({"questions": E.drill(unit, n, today)})

        if p0 == "settings" and parts[1:] == ["tutor"]:
            if method == "GET":
                return self.send_json(tutor_settings_view())
            if method == "POST":
                return self.send_json(save_tutor_settings(self.read_json()))

        if p0 == "tutor":
            if method == "GET" and parts[1:] == ["status"]:
                cfg = tutor_config()
                return self.send_json({"configured": bool(cfg["key"]), "model": cfg["model"], "provider": cfg["provider"]})
            if method == "POST" and parts[1:] == ["test"]:
                return self.send_json(test_tutor())
            if method == "GET" and len(parts) == 3 and parts[1] == "thread":
                return self.send_json({"messages": E.tutor_history(parts[2], limit=200)})
            if method == "POST" and parts[1:] == ["ask"]:
                b = self.read_json()
                thread = re.sub(r"[^\w-]", "", str(b.get("threadId") or "main"))[:64] or "main"
                return self.send_json(call_tutor(thread, (b.get("message") or "").strip()[:6000],
                                                 b.get("image"), b.get("context") or {}, today))

        if method == "GET" and p0 == "backup":
            data = json.dumps(E.export_all(), indent=1).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Disposition", 'attachment; filename="sat-academy-backup-%s.json"' % today)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if method == "POST" and p0 == "restore":
            E.import_all(self.read_json())
            return self.send_json({"ok": True})

        return self.send_json({"error": "not found"}, 404)


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):
        if isinstance(sys.exc_info()[1], (BrokenPipeError, ConnectionResetError)):
            return   # a cancelled download isn't worth a traceback in the launcher window
        super().handle_error(request, client_address)


def main():
    httpd = Server((HOST, PORT), Handler)
    print("SAT Reading & Writing Academy is running.")
    print("Open http://localhost:%d in your browser. Press Ctrl+C to stop." % PORT)
    print("Study data: %s" % os.path.join(DATA_DIR, "study.db"))
    t = tutor_config()
    print("AI tutor: %s" % (("%s, %s" % (t["provider"], t["model"])) if t["key"] else "not set up yet (open AI Tutor in the app)"))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped. Your progress is saved.")


if __name__ == "__main__":
    main()
